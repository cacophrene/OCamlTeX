(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let dialog = lazy ( 
  let dlg = GWindow.file_chooser_dialog
    ~action:`OPEN
    ~parent:GUI.Main.window
    ~destroy_with_parent:true
    ~title:(Lang.get "dialog-open")
    ~position:`CENTER_ON_PARENT () in
  dlg#add_button_stock `CANCEL `CANCEL;
  dlg#add_select_button_stock `OPEN `OPEN;
  dlg#add_filter GUI.Main.latex_filter;
  dlg )

let show ~dir =
  let dialog = Lazy.force dialog in
  ignore (dialog#set_current_folder dir);
  let res = if dialog#run () = `OPEN then dialog#get_filenames else [] in
  dialog#misc#hide ();
  res
