(* oCamlTeX.ml *)

let _ =
  (* Plugins. *)
  Plugin.init ();
  (* Now it's time to create the GUI. *)
  GUI.Main.init ();
  (* Needed to compile. *)
  Actions.init ();
  Preferences.Main.init ();
  Dialog.Main.init ();
  Project.Main.init ();
  GUI.Main.window#show ();
  let tm2 = Unix.gettimeofday () in
  Printf.printf "(OCamlTeX) Loading time: %.3f s.\n%!" (tm2 -. App.tm1);
  GMain.main ()
