(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf
type id = string

let initialized = ref false

let lang : (string, string) Hashtbl.t = Hashtbl.create 20

let add = Hashtbl.add lang

let get id = 
  if !initialized then (
    try Hashtbl.find lang id with _ -> Print.warning id "ID \"%s\" not found" id
  ) else Print.warning id "ID request before initialization"

let format id fmt = sprintf fmt (get id)

module Builder =
  struct
    let rev_concat l = String.concat "-" (List.rev l)

    let rec parse_lang buf = function
      | `Assc ("Item", `Str id, `Str tr) -> add (rev_concat (id :: buf)) tr
      | _ -> assert false
  end

let init () =
  let name = AppPrefs.get "language" ^ ".lang" in
  let file = Filename.concat App.Dir.languages name in
  try
    List.iter (Builder.parse_lang []) (Sexpr.from_file file);
    initialized := true
  with _ -> Print.failure 4 "Language file %S not found" file
