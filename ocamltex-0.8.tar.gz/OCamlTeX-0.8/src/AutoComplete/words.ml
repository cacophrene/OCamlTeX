(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

type bag = { 
  buffer : GSourceView2.source_buffer; 
  mutable active : bool 
} 

(* Dictionary. *)
let dictionary : Trie.UTF_8.t Lazy.t = 
   lazy (
    let dic = AppPrefs.get "language" ^ ".dic" in
    let file = Filename.concat App.Dir.dictionaries dic in
    try
      let ich = open_in file in
      let dic = input_value ich in
      close_in ich;
      dic
    with _ -> eprintf "(OCamlTeX) Warning: Dictionary %S not found.\n%!" file;
      Trie.UTF_8.empty
  )

module Tools =
  struct
    let strip ?(chars = " \n\r\t") s =
      let n = String.length s in
      let rec loop i j =
        if i < n then (
          let i' = i + Obj.magic (String.contains chars s.[i])
          and j' = j - Obj.magic (String.contains chars s.[j]) in
          if i = i' && j = j' then String.sub s i (j - i + 1) else loop i' j'
        ) else ""
      in loop 0 (n - 1)
      
    let is_alpha str =
      Array.fold_left (fun res uch -> 
        res && Glib.Unichar.isalpha uch
      ) true (Glib.Utf8.to_unistring str)

    let get_prefix bag =
      let stop = bag.buffer#get_iter `INSERT in
      if stop#ends_word then (
        let start = stop#backward_word_start in
        Some (strip (bag.buffer#get_text ~start ~stop ()))
      ) else None
  end

(* Hide proposal. *)
let hide bag =
  bag.buffer#delete_selection ();
  bag.active <- false

(* Validate proposal. *)
let validate bag =
(*let start, stop = bag.buffer#selection_bounds in
  List.iter (fun tag -> bag.buffer#remove_tag tag start stop) tags;*)
  let iter = bag.buffer#get_iter `INSERT in
  bag.buffer#select_range iter iter;
  bag.active <- false

let choose_action bag t =
  if bag.active then (
    match GdkEvent.Key.keyval t with
      | 0xFF08 (* Touche 'Retour'   *) -> hide bag; false
      | 0xFF0D (* Touche 'Entrée'   *) -> validate bag; true
      | 0xFF50 (* Touche 'Home'     *)
      | 0xFF1B (* Touche 'Échap'    *) 
      | 0xFF51 (* Touche 'Gauche'   *)
      | 0xFF52 (* Touche 'Haut'     *)
      | 0xFF53 (* Touche 'Droite'   *) 
      | 0xFF54 (* Touche 'Bas'      *)
      | 0xFF55 (* Touche 'PageUp'   *)
      | 0xFF56 (* Touche 'PageDown' *)
      | 0xFF57 (* Touche 'Fin'      *)
      | 0xFF58 (* Touche 'Début'    *) -> hide bag; true
      | _      (* Autres touches    *) -> false
  ) else false

let from str pos =
  let len = Glib.Utf8.length str in
  Glib.Utf8.from_unistring (Array.sub (Glib.Utf8.to_unistring str ) pos (len - pos))

let suggest bag _ _ = 
  match Tools.get_prefix bag with
  | None -> ()
  | Some pfx -> let pos = Glib.Utf8.length pfx in
    match Trie.UTF_8.complete pfx (Lazy.force dictionary) with
    | None -> ()
    | Some str -> let suf = from str pos in
      bag.buffer#insert suf;
      let here = bag.buffer#get_iter `INSERT in
      bag.buffer#select_range here (here#backward_chars (Glib.Utf8.length suf))

let run (source : GSourceView2.source_view) =
  let buffer = source#source_buffer in 
  let bag = { buffer = buffer; active = true } in
  let sig1 = source#event#connect#key_press ~callback:(choose_action bag) in
  let sig2 = buffer#connect#after#insert_text ~callback:(suggest bag) in
  sig1, sig2
