(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

let dialog =
  let dlg = GWindow.dialog
    ~icon:App.icon
    ~allow_grow:false
    ~title:(App.name ^ " warning")
    ~position:`CENTER_ON_PARENT 
    ~width:500 () in
  dlg#add_button_stock `OK `OK;
  dlg#set_border_width 10;
  dlg#vbox#set_spacing 10;
  dlg

let hbox = GPack.hbox 
  ~spacing:10
  ~packing:(dialog#vbox#pack ~expand:false) ()

let _ = GMisc.image 
  ~stock:`DIALOG_WARNING 
  ~icon_size:`DIALOG 
  ~packing:(hbox#pack ~expand:false) ()

let label = 
  let lbl = GMisc.label 
    ~xalign:0.
    ~justify:`FILL
    ~packing:(hbox#pack ~expand:false) () in
  lbl#set_use_markup true;
  lbl

let text =
  let scroll = GBin.scrolled_window
    ~hpolicy:`ALWAYS
    ~vpolicy:`ALWAYS
    ~shadow_type:`ETCHED_IN
    ~height:200
    ~packing:dialog#vbox#add () in
  let view = GText.view ~editable:false ~packing:scroll#add () in
  view#set_cursor_visible false;
  view#misc#modify_font_by_name "Monospace 10";
  view

let show ~id ~exn =
  label#set_label "<big><b>An error has occurred.</b></big>\n     \
    <i>Copy/paste backtrace (see below) in your bug report.</i>\n     \
    NB: This may be a plugin error. Please try to reproduce this \n     \
    unexpected behavior using OCamlTeX <tt>--no-plugin</tt> option.";
  ksprintf text#buffer#set_text 
    "# Software: %s\n# Function ID: %S\n# Exception: %s\n# Backtrace:\n%s"
    App.title id (Printexc.to_string exn) (Printexc.get_backtrace ());
  dialog#run ();
  dialog#misc#hide ()
