(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

type id = string

type t = { func : 'a. ('a -> unit) }

let htbl : (string, t) Hashtbl.t = Hashtbl.create 7

(* We use some magic because f is generally not polymorphic. *)
let add id f = 
  Hashtbl.add htbl id { func = (fun x -> f (Obj.magic x)) }; f

let mem = Hashtbl.mem htbl

let run id () =
  try
    let t = Hashtbl.find htbl id in
    begin try t.func () with exn -> Bug.show ~id ~exn end
  with Not_found -> Print.warning () "ID %S not found" id

let run_with_arg id x () = 
  try (Hashtbl.find htbl id).func x with
    | Not_found -> Print.warning () "ID %S not found" id
