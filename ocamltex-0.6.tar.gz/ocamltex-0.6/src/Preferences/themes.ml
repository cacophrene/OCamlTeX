(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let tab_label = 
  begin GMisc.label 
    ~text:(Lang.get "prefs-themes-tab-label") ()
  end #coerce

let vbox = GPack.vbox ~border_width:10 ~spacing:10 ()
let packing = vbox#pack ~expand:false
let container = vbox#coerce

let _ = GMisc.label
  ~xalign:0.
  ~markup:(Printf.sprintf "<b>%s</b>" (Lang.get "prefs-themes-fonts"))
  ~packing ()

let fonts = GButton.font_button
  ~packing:(Tools.hbox_with_indent ~packing ())#add ()

let _ = GMisc.label
  ~xalign:0.
  ~markup:(Printf.sprintf "<b>%s</b>" (Lang.get "prefs-themes-colors"))
  ~packing ()

module Data =
  struct
    let cols = new GTree.column_list
    let name = cols#add Gobject.Data.string
    let desc = cols#add Gobject.Data.string
    let store = GTree.list_store cols
  end

module View =
  struct
    let name = GTree.cell_renderer_text [`WEIGHT `BOLD]
    let desc = GTree.cell_renderer_text [`XPAD 5]
    let vcol =
      let vcol = GTree.view_column () in
      List.iter2 (fun cell data ->
        vcol#pack cell;
        vcol#add_attribute cell "text" data
      ) [name; desc] [Data.name; Data.desc];
      vcol
  end

let scroll = GBin.scrolled_window
  ~hpolicy:`AUTOMATIC
  ~vpolicy:`AUTOMATIC
  ~shadow_type:`ETCHED_IN
  ~packing:(Tools.hbox_with_indent ~packing:vbox#add ())#add ()

let view =
  let view = GTree.view
    ~model:Data.store
    ~rules_hint:true
    ~headers_visible:false
    ~packing:scroll#add () in
  view#append_column View.vcol;
  view

let bbox = GPack.button_box `HORIZONTAL ~layout:`END ~packing ()

let manager = GSourceView2.source_style_scheme_manager ~default:true

let load () =
  Data.store#clear ();
  List.iter (fun id ->
    match manager#style_scheme id with
    | Some scheme -> let row = Data.store#append () in
      Data.store#set ~row ~column:Data.name scheme#name;
      Data.store#set ~row ~column:Data.desc scheme#description
    | _ -> assert false (* it should never happen *)
  ) (List.sort String.compare manager#style_scheme_ids)

let reload =
  let btn = GButton.button
    ~stock:`REFRESH
    ~packing:bbox#add () in
  btn#connect#clicked (fun () -> manager#force_rescan (); load ());
  btn

let import () =
  load ();
  fonts#set_font_name (AppPrefs.get "editor-font")

let export () =
  AppPrefs.set "editor-font" fonts#font_name
