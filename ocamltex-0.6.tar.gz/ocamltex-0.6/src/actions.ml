(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let quit = GUI.Main.window#destroy

let toggle_fullscreen =
  let switch = ref false in
  fun () ->
    switch := not !switch;
    if !switch then GUI.Main.window#fullscreen ()
    else GUI.Main.window#unfullscreen ()

let toggle_side_pane =
  let switch = ref false in
  fun () ->
    switch := not !switch;
    if !switch then GUI.Main.hpaned#pack1 ~shrink:false 
      GUI.SidePane.notebook#coerce    
    else GUI.Main.hpaned#remove GUI.Main.hpaned#child1

let toggle_bottom_pane =
  let switch = ref false in
  fun () ->
    switch := not !switch;
    if !switch then GUI.Main.vpaned#pack2 ~shrink:false 
      GUI.BottomPane.notebook#coerce    
    else GUI.Main.vpaned#remove GUI.Main.vpaned#child2

let latex_insert t =
  GUI.Main.source#source_buffer#insert (LaTeX.Main.to_string t)

let init () =
  FunTable.add "quit" quit;
  FunTable.add "toggle-fullscreen" toggle_fullscreen;
  FunTable.add "toggle-side-pane" toggle_side_pane;
  FunTable.add "toggle-bottom-pane" toggle_bottom_pane;
  FunTable.add "latex-insert" latex_insert
