(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

let tm1 = Unix.gettimeofday ()

let _ =
  Printexc.record_backtrace true;
  GMain.init ()

module Dir =
  struct
    let data = "data"
    let dictionaries = Filename.concat data "dictionaries"
    let gui = Filename.concat data "gui"
    let languages = Filename.concat data "languages"
    let latex = Filename.concat data "latex"
    let plugins = Filename.concat data "plugins"
    let templates = Filename.concat data "templates"
    let symbols = Filename.concat data "symbols"
  end

let get_pixbuf name = 
  let file = Filename.concat Dir.data name in
  try GdkPixbuf.from_file file with
  | Glib.GError _ -> Log.failure 2 "Missing file %S" file

(* Main infos. *)
let name = "OCamlTeX"
let version = "0.93"
let title = sprintf "%s %s" name version
let icon = get_pixbuf "icon.png"
let logo = get_pixbuf "logo.png"

(* About dialog infos. *)
let license = Filename.concat Dir.data "ocamltex-license"
let authors = [("Edouard Evangelisti", "cacophrene@gmail.com")]
let copyright = "Copyright (C) 2009 Edouard Evangelisti"
let website = "https://sourceforge.net/projects/ocamltex2/"

(* Configuration files. *)
module File =
  struct
    let latex = Filename.concat Dir.latex "main"
    let prefs = Filename.concat Dir.data "ocamltex-prefs"
  end
