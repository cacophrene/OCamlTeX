(* oCamlTeX.ml *)

let _ =
  (* Plugins. *)
  Plugin.init ();
  (* Interface. *)
  GUI.Main.init ();
  (* Initialization. *)
  Wizard.Main.init ();
  Actions.Main.init ();
  Preferences.Main.init ();
  Dialog.Main.init ();
  Project.Main.init ();
  let tm2 = Unix.gettimeofday () in
  Log.message "Loading time is %.3f s" (tm2 -. App.tm1);
  GUI.Main.window#show ();
  GMain.main ()
