(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

type dat = {
  mutable file : string;
  mutable is_saved : bool;
  mutable is_blank : bool
}

type tab = { label : GMisc.label; image : GMisc.image }
type page = { widget : GObj.widget; source : GSourceView2.source_view }

type gtk = { 
  tab : tab; 
  page : page; 
  rref : GTree.row_reference;
  mutable undo : GtkSignal.id list;
  mutable redo : GtkSignal.id list;
}

type t = { dat : dat; gtk : gtk } 

let diff t1 t2 = t1.gtk.page.widget#get_oid <> t2.gtk.page.widget#get_oid

module Get =
  struct
    let dir t = Filename.dirname t.dat.file
    let name t = Filename.basename t.dat.file
    let file t = t.dat.file
    let source t = t.gtk.page.source
    let buffer t = t.gtk.page.source#source_buffer
    let contents t = t.gtk.page.source#source_buffer#get_text ()
    let icon t = t.gtk.tab.image#stock
    let focus t = t.gtk.page.source#misc#grab_focus ()
    let widget t = t.gtk.page.widget
  end

(* History items *)
let undo_items = lazy (GUI.Main.get "undo")
let redo_items = lazy (GUI.Main.get "redo")

let connect (f : GObj.widget -> unit -> unit) ~items =
  List.map (function
    | `ToolButton btn -> btn#connect#clicked ~callback:(f btn#coerce)
    | `ImageItem btn  -> btn#connect#activate ~callback:(f btn#coerce)
    | _ -> assert false
  ) (Lazy.force items)

let set_sensitive state items =
  List.iter (function
    | `ToolButton btn -> btn#misc#set_sensitive state
    | `ImageItem btn  -> btn#misc#set_sensitive state
    | _ -> ()
  ) (Lazy.force items)

let disconnect ~ids ~items =
  try
    List.iter2 (fun id -> function
      | `ToolButton btn -> btn#misc#disconnect id
      | `ImageItem btn  -> btn#misc#disconnect id
      | _ -> assert false
    ) ids (Lazy.force items)
  with Invalid_argument _ -> ()

module Storage =
  struct
    let htbl = Hashtbl.create 7
    let add widget = Hashtbl.add htbl widget#get_oid
    let mem widget = Hashtbl.mem htbl widget#get_oid
    let rem widget = Hashtbl.remove htbl widget#get_oid
    let get widget = Hashtbl.find htbl widget#get_oid
  end

let update_title t =
  let f = GUI.Main.window#set_title in
  begin
    if t.dat.is_saved then ksprintf f "%s (%s) - %s" (Get.name t) (Get.dir t)
    else ksprintf f "%s - %s" (Get.name t)
  end App.title

let get_from_oid = Hashtbl.find Storage.htbl
let get_from_widget widget = Hashtbl.find Storage.htbl widget#get_oid
let get_page t = GUI.Main.opened_files#page_num t.gtk.page.widget
let get_source t = t.gtk.page.source
let get_buffer t = t.gtk.page.source#source_buffer
let get_file t = t.dat.file
let count () = Hashtbl.length Storage.htbl

let current = ref (Obj.magic 0)
let get_current () = !current

let set_current t1 =
  let t2 = !current in
  if Obj.magic t2 = 0 || diff t1 t2 then begin
    current := t1;
    GUI.SidePane.Project.select t1.gtk.rref;
    GUI.Main.opened_files#goto_page (get_page t1);
    update_title t1;
    disconnect ~ids:t1.gtk.undo ~items:undo_items;
    disconnect ~ids:t1.gtk.redo ~items:redo_items;
    let buffer = get_buffer t1 in
    (*set_sensitive buffer#can_undo undo_items;
    set_sensitive buffer#can_redo redo_items;*)
    t1.gtk.undo <- connect (fun widget () ->
      let state = buffer#can_undo in
      widget#misc#set_sensitive state;
      if state then buffer#undo ()
    ) ~items:undo_items;
    t1.gtk.redo <- connect (fun widget () ->
      let state = buffer#can_redo in
      widget#misc#set_sensitive state;
      if state then buffer#redo ()
    ) ~items:redo_items
  end

let is_blank t = t.dat.is_blank
let is_saved t = t.dat.is_saved

module Set =
  struct
    let file t x = t.dat.file <- x
    let saved t x = t.dat.is_saved <- x
    let contents t = t.gtk.page.source#source_buffer#set_text
  end

module Update =
  struct
    let label t = t.gtk.tab.label#set_text 
      (Filename.basename t.dat.file)
    let image t = t.gtk.tab.image#set_stock 
      (if t.dat.is_saved then `FILE else `FLOPPY)
  end

module Aux =
  struct
    let uniq =
      let doc = Lang.get "document" in
      fun () ->
        let rec loop i =
          let name = Printf.sprintf "%s-%d.tex" doc i in
          let bool = Hashtbl.fold (fun _ t bln -> 
            bln || t.dat.file = name
          ) Storage.htbl false in
          if bool then loop (i + 1) else name
        in loop 1
    let read file =
      let ich = open_in file in
      let len = in_channel_length ich in
      let str = String.create len in
      really_input ich str 0 len;
      close_in ich;
      str
    let write file (buf : GSourceView2.source_buffer) =
      let och = open_out file in
      output_string och (buf#get_text ());
      close_out och
  end

let create =
  FunTable.add "new" (fun () ->
    let file = Aux.uniq () in
    let source, widget = Display.source () in
    let _ = AutoComplete.Code.add source in
    let tab_label, label, image = Display.tab_label `FLOPPY file in
    let t = {
      dat = { file = file; is_saved = false; is_blank = true };
      gtk = {
        tab = { label = label; image = image };
        page = { widget = widget; source = source };
        rref = GUI.SidePane.Project.append `FILE file ~oid:widget#get_oid;
        undo = []; redo = [] }
    } in
    (*let buffer = source#source_buffer in
    buffer#connect#changed (FunTable.run_with_arg "validate" buffer);
    buffer#connect#can_undo (fun x -> set_sensitive x undo_items);
    buffer#connect#can_redo (fun x -> set_sensitive x redo_items);*)
    Storage.add widget t;
    set_current t;
    let n = GUI.Main.opened_files#append_page ~tab_label widget in
    GUI.Main.opened_files#goto_page n;
    Get.focus t
  )

let save_as t =
  match Dialog.SaveAs.show ~file:(Get.file t) with
  | None -> () (* Action has been cancelled. *)
  | Some file -> 
    Set.file t file; Set.saved t true;
    Update.label t; Update.image t;
    Aux.write file (Get.buffer t);
    update_title t

let save t =
  if t.dat.is_saved then (
    if Sys.file_exists t.dat.file then (
      Set.saved t true; Update.image t;
      Aux.write t.dat.file (Get.buffer t)
    ) else save_as t
  ) else save_as t

let close t =
  match t.dat.is_saved with
  | true
  | false when is_blank t -> let widget = t.gtk.page.widget in
    GUI.Main.opened_files#remove_page (GUI.Main.opened_files#page_num widget);
    GUI.SidePane.Project.remove t.gtk.rref;
    Storage.rem widget
  | _ -> ()

let load =
  FunTable.add "open" (fun () ->
    List.iter (fun file ->
      if is_blank !current then close !current;
      let source, widget = Display.source () in
      let _ = AutoComplete.Code.add source in
      let name = Filename.basename file in
      let tab_label, label, image = Display.tab_label `FILE name in
      let t = {
        dat = { file = file; is_saved = true; is_blank = false };
        gtk = {
          tab = { label = label; image = image };
          page = { widget = widget; source = source };
          rref = GUI.SidePane.Project.append `FILE name ~oid:widget#get_oid;
          undo = []; redo = [] }
      } in
      let buffer = source#source_buffer in
      (*buffer#connect#changed (FunTable.run_with_arg "validate" buffer);
      buffer#connect#can_undo (fun x -> set_sensitive x undo_items);
      buffer#connect#can_redo (fun x -> set_sensitive x redo_items);*)
      buffer#set_text (Aux.read file);
      Storage.add widget t;
      set_current t;
      let n = GUI.Main.opened_files#append_page ~tab_label widget in
      GUI.Main.opened_files#goto_page n;
      Get.focus t
    ) (Dialog.Open.show ~dir:".")
  )

let iter f = Hashtbl.iter (fun _ -> f) Storage.htbl
