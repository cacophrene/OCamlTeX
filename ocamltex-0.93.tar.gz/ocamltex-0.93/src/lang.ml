(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf
type id = string

let lang = Hashtbl.create 20

let add = Hashtbl.add lang

let get id = 
  try Hashtbl.find lang id with
  | Not_found -> Print.warning id "No translation available for ID %S" id

let format id fmt = sprintf fmt (get id)

module Builder =
  struct
    let parse_lang = function
      | `Assc ("Item", `Str id, `Str transl) -> Hashtbl.add lang id transl
      | _ -> Print.warning () "Syntax error in language file"
  end

let init_aux () =
  let name = AppPrefs.get "language" ^ ".lang" in
  let file = Filename.concat App.Dir.languages name in
  try
    List.iter Builder.parse_lang (Sexpr.from_file file);
  with _ -> Print.failure 4 "Language file %S not found" file


module type LANG =
  sig
    val get_name : unit -> string
  end

module Make = functor (Lang : LANG) ->
  struct
    let htbl = Hashtbl.create 7

    let register file =
      List.iter (function
        | `Assc ("Item", `Str x, `Str y) -> Hashtbl.add htbl x y 
        | _ -> Print.failure 2 "Syntax error in file %S" file
      ) (Sexpr.from_file file)

    let init () =
      let name = Lang.get_name () in
      let file = Filename.concat App.Dir.languages name in
      try register file with 
      | Sys_error _ -> Print.failure 4 "File %S not found" name
  end

module Msg =
  struct
    include Make (
      struct 
        let get_name () = AppPrefs.get "language" ^ "-msg.lang"
      end )

    let get id fmt =
      try Scanf.format_from_string (Hashtbl.find htbl id) fmt with
      | Not_found -> Print.warning fmt "Language ID %S not found" id
      | Scanf.Scan_failure _ -> Print.warning fmt "ID %S does not match %S" id 
        (Obj.magic fmt) 
  end

let init () =
  Msg.init ();
  init_aux ()
