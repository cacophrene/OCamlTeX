(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let notebook = GPack.notebook ~tab_pos:`RIGHT ()

let display_tab =
  let activate = function 
    | `CheckItem check -> check#set_active true 
    | _ -> () in
  fun n () ->
    notebook#goto_page n;
    try ignore (Main.vpaned#child2) with _ ->
      List.iter activate (Main.get "toggle-bottom-pane")

module type TAB_DATA = sig val label_id : string end

module Make = functor (TDat : TAB_DATA) ->
  struct
    let tab_label =
      let hbox = GPack.hbox ~spacing:3 () in
      GMisc.image 
        ~stock:`EDIT 
        ~icon_size:`MENU 
        ~packing:(hbox#pack ~expand:false)  ();
      GMisc.label 
        ~text:(Lang.get TDat.label_id) 
        ~xalign:0. 
        ~packing:hbox#add ();
      hbox#coerce
    let container, display = 
      let vbox = GPack.vbox () in
      let n = notebook#append_page ~tab_label vbox#coerce in
      vbox, display_tab n

    module Data =
      struct
        let cols = new GTree.column_list
        let icon = cols#add GtkStock.conv
        let text = cols#add Gobject.Data.string
        let store = GTree.list_store cols
      end

    let clear = Data.store#clear
    let append x y =
      let row = Data.store#append () in
      Data.store#set ~row ~column:Data.icon x;
      Data.store#set ~row ~column:Data.text y

    module View =
      struct
        let icon = GTree.cell_renderer_pixbuf []
        let text = GTree.cell_renderer_text [`XPAD 5]
        let vcol =
          let vcol = GTree.view_column () in
          vcol#pack ~expand:false icon;
          vcol#pack text;
          vcol#add_attribute icon "stock_id" Data.icon;
          vcol#add_attribute text "markup" Data.text;
          vcol
      end

    let scroll = GBin.scrolled_window
      ~hpolicy:`ALWAYS
      ~vpolicy:`ALWAYS
      ~packing:container#add ()
    let view =
      let view = GTree.view
        ~model:Data.store
        ~rules_hint:true
        ~headers_visible:false
        ~packing:scroll#add () in
      view#append_column View.vcol;
      view
  end

module Log = Make (
  struct
    let label_id = "bottom-pane-compilation"
  end
)

module Validation = Make (
  struct
    let label_id = "bottom-pane-validation"
  end
)
