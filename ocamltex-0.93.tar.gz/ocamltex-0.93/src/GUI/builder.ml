(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

type combo = {
  combo : GEdit.combo_box;
  store : GTree.list_store;
  latex : LaTeX.Main.t GTree.column;
  texts : string GTree.column;
  icons : GtkStock.id GTree.column
}

type _combo = {
  _combo : GEdit.combo_box;
  _store : GTree.list_store;
  _name : string GTree.column;
  _file : string GTree.column;
} 

type item = [
  | `Combo      of combo
  | `Menu       of GMenu.menu
  | `Button     of GButton.button
  | `Browser    of Widgets.texdoc
  | `Notebook   of GPack.notebook
  | `Toolbar    of GButton.toolbar
  | `Menubar    of GMenu.menu_shell
  | `ToolButton of GButton.tool_button
  | `Check      of GButton.toggle_button
  | `ImageItem  of GMenu.image_menu_item
  | `CheckItem  of GMenu.check_menu_item
  | `MenuButton of GButton.menu_tool_button
]

(* Some global variables. They are all updated before being used, so don't
 * worry about these ugly Obj.magic calls. *)
let add = ref (Obj.magic ())
let accels = ref (Obj.magic ())
let window : GWindow.window ref = ref (Obj.magic ())


module Assoc =
  struct
    let get_int id t =
      try match List.assoc id t with
        | `Int n -> n
        | _ -> 0
      with Not_found -> 0

    let get_string id t =
      match List.assoc id t with
      | `Str n -> n
      | _ -> raise Not_found
  end

module Opt =
  struct
    let may_override cur id f opt =
      try Some (f (Assoc.get_string id opt)) with Not_found -> cur

    let get_string id l = 
      try 
        match List.assoc id l with 
        | `Str x -> Some x
        | _ -> None
      with Not_found -> None
  end

module Aux =
  struct
    let substitute pat id =
      let buf = Buffer.create 16 in
      Buffer.add_substitute buf (function "id" -> id | _-> "?") pat;
      `STOCK (Buffer.contents buf)
  end

module RibbonBlock =
  struct
    let iter f rnum cnum l =
      let rec loop = function
        | (_, _, []) -> ()
        | (r, _, _) when r = rnum -> ()
        | (r, c, l) when c = cnum -> loop (r + 1, 0, l)
        | (r, c, x :: t) -> f r c x; loop (r, c + 1, t)
      in loop (1, 0, l)
  end

module RibbonItem =
  struct
    let get_size opt =
      try 
        match List.assoc "size" opt with
        | `Str "BUTTON" -> `BUTTON
        | `Str "MENU" -> `SMALL_TOOLBAR
        | _ -> `SMALL_TOOLBAR
      with Not_found -> `SMALL_TOOLBAR
    let get_text id opt =
      try 
        match List.assoc "show_label" opt with
        | `Bln true -> Some (Lang.get id)
        | _ -> None
      with Not_found -> None 
  end

(* This module provides functions to find, format and register accelerators. *)
module Accel =
  struct
    let format =
      let buf = Buffer.create 16 and pat = Str.regexp "+" in
      let add = Buffer.add_string buf in
      fun str ->
        Buffer.clear buf;
        List.iter (fun str -> add (
          match str with 
          |"Ctrl" -> "<control>"
          | "Shift" -> "<shift>"
          | _ -> str
        )) (Str.split pat str);
        Buffer.contents buf
    let may opt =
      try 
        match List.assoc "accel" opt with
        | `Str str -> Some (format str)
        | _ -> None
      with Not_found -> None
    let add =
      let flags = [`VISIBLE] in
      fun (item : #GMenu.menu_item_skel) opt ->
        match may opt with
        | Some str -> let key, modi = GtkData.AccelGroup.parse str in
          item#add_accelerator ~group:!accels ~modi ~flags key
        | _ -> ()
  end

(* This module provides functions to find and load icons. *)
module Icon =
  struct
    let may opt =
      try
        match List.assoc "icon" opt with
        | `Str x -> Some (`STOCK x)
        | _ -> None
      with Not_found -> None
  end

(* This module provides functions to manipulate combo boxes. *)
module Combo =
  struct
    (* Combo box builder. *)
    let make ~packing () =
      let cols = new GTree.column_list in
      let latex = cols#add Gobject.Data.caml in
      let texts = cols#add Gobject.Data.string in
      let icons = cols#add GtkStock.conv in
      let store = GTree.list_store cols in
      let combo = GEdit.combo_box ~width:200 ~model:store ~packing () in
      let cell_icons = GTree.cell_renderer_pixbuf [] in
      let cell_texts = GTree.cell_renderer_text [`XPAD 5] in
      combo#pack cell_icons;
      combo#add_attribute cell_icons "stock_id" icons;
      combo#pack cell_texts;
      combo#add_attribute cell_texts "markup" texts;
      { combo = combo; store = store; latex = latex; texts = texts; icons = icons }

    (* Feeding combo box. *)
    let feed combo id =
      Array.iter (fun t ->
        let row = combo.store#append () in
        combo.store#set ~row ~column:combo.latex t;
        combo.store#set ~row ~column:combo.icons (LaTeX.Main.get_stock t);
        combo.store#set ~row ~column:combo.texts (LaTeX.Main.to_markup t)
      ) (LaTeX.Main.get_group id);
      combo.combo#set_active 0

    let insert combo () =
      match combo.combo#active_iter with
      | Some row -> let t = combo.store#get ~row ~column:combo.latex in
        FunTable.run_with_arg "latex-insert" t ()
      | _ -> ()
  end

module PluginTools =
  struct
    let feed item =
      List.iter (fun name ->
        let item = GMenu.menu_item
          ~label:(Lang.get (Plugin.ID.title name))
          ~packing:item#add () in
        item#connect#activate (FunTable.run (Plugin.ID.main name)); ()
      ) (Plugin.get_list ())
  end

module TemplatesTools =
  struct
    let feed item =
      List.iter (fun file ->
        let item = GMenu.menu_item ~packing:item#add () in
        let name = String.capitalize (Filename.chop_extension file) in
        ignore (GMisc.label
          ~markup:(sprintf "<b>%s</b> - %s" name file)
          ~packing:item#add ());
        item#connect#activate (FunTable.run_with_arg "load-template" file); ()
      ) (Templates.get_list ())

    let make_combo ~packing () =
      let cols = new GTree.column_list in
      let name = cols#add Gobject.Data.string in
      let file = cols#add Gobject.Data.string in
      let store = GTree.list_store cols in
      let combo = GEdit.combo_box ~width:200 ~model:store ~packing () in
      let cell_name = GTree.cell_renderer_text [`WEIGHT `BOLD] in
      let cell_file = GTree.cell_renderer_text [] in
      combo#pack cell_name;
      combo#add_attribute cell_name "text" name;
      combo#pack cell_file;
      combo#add_attribute cell_file "text" file;
      { _combo = combo; _store = store; _name = name; _file = file }

    let feed_combo combo =
      List.iter (fun file ->
        let row = combo._store#append () in
        let name = String.capitalize (Filename.chop_extension file) in
        combo._store#set ~row ~column:combo._name name;
        combo._store#set ~row ~column:combo._file file
      ) (Templates.get_list ());
      combo._combo#set_active 0
  end

(* This module let us know whether a check menu item is active or not. *)
module Check =
  struct
    let is_active opt =
      try
        match List.assoc "init" opt with
        | `Bln b -> b
        | _ -> false
      with Not_found -> false
  end

module IconPattern =
  struct
    let var pat id =
      let buf = Buffer.create 16 in
      Buffer.add_substitute buf (function "id" -> id | _-> "?") pat;
      `STOCK (Buffer.contents buf)
  end

module LaTeXSubMenu =
  struct
    let build ~packing id =
      Array.iter (fun t ->
        let id = LaTeX.Main.get_id t in
        let item = GMenu.image_menu_item ~packing () in
        ignore (GMisc.label 
          ~xalign:0.
          ~markup:(Lang.get id ^ " - " ^ LaTeX.Main.to_markup t)
          ~packing:item#add ());
        item#connect#activate (FunTable.run_with_arg "latex-insert" t);
        !add id (`ImageItem item)
      ) (LaTeX.Main.get_group id)
  end

let set_stock packing stock = 
  GMisc.image ~stock ~icon_size:`MENU ~packing (); () 

(* Toolbar and menubar builder. *)
let rec bar ?icon_pattern:pat ~packing = function
  | `Node ("Ribbon", `Str id, opt, contents) ->
    let item = GPack.notebook 
      ~border_width:5
      ~scrollable:true 
      ~homogeneous_tabs:true
      ~packing () in
    !add id (`Notebook item);
    let icon_pattern = Opt.may_override pat "icon_pattern" Aux.substitute opt in
    List.iter (ribbon_tab ?icon_pattern ~packing:item#append_page) contents
  | `Node ("Toolbar", `Str id, opt, contents) ->
    let item = GButton.toolbar
      ~orientation:`HORIZONTAL
      ~style:`ICONS
      ~packing:(GBin.handle_box ~packing ())#add () in
    !add id (`Toolbar item);
    let icon_pattern = Opt.may_override pat "icon_pattern" Aux.substitute opt in
    List.iter (toolitem ?icon_pattern ~packing:item#insert) contents
  | `Node ("Menubar", `Str id, _, contents) ->
    let item = GMenu.menu_bar ~packing () in
    !add id (`Menubar item);
    List.iter (menu ~packing:item#add) contents;
  | _ -> eprintf "(OCamlTeX) Warning: Unknown bar.\n%!"

(* Menu items. 
 * ITEM               WIDGET                  DEFINITION
 * (Templates)        GtkMenu                 List of available templates.
 * (Plugins)          GtkMenu                 List of available plugins.
 * (Menu "id": ...)   GtkMenu                 Menu.
*)
and menu ~packing = function
  | `Flag "Templates" ->
    let label = GMenu.menu_item 
      ~label:(Lang.get "templates") 
      ~use_mnemonic:true
      ~packing ()
    in TemplatesTools.feed (GMenu.menu ~packing:label#set_submenu ())
  | `Flag "Plugins" ->
    let label = GMenu.menu_item 
      ~label:(Lang.get "plugins") 
      ~use_mnemonic:true
      ~packing ()
    in PluginTools.feed (GMenu.menu ~packing:label#set_submenu ())
  | `Node ("Menu", `Str id, opt, contents) ->
    let label = GMenu.menu_item 
      ~label:(Lang.get id) 
      ~use_mnemonic:true ~packing () in
    let item = GMenu.menu ~packing:label#set_submenu () in
    !add id (`Menu item);
    List.iter (menuitem 
      ?icon_pattern:(Opt.may_override None "icon_pattern" Aux.substitute opt) 
      ~packing:item#add) contents
  | _ -> eprintf "(OCamlTeX) Warning: Unknown menubar item was discarded.\n%!"

(* Toolbar items.
 * ITEM               WIDGET                  DEFINITION
 * (Separator)        GtkSeparatorToolItem    Small vertical bar between items.
 * (Button "id")      GtkToolButton           Tool button.
 * (LaTeX "\\foo")    GtkToolButton           LaTeX command \foo.
 * (LaTeX "group")    GtkComboBox             LaTeX group of commands.
 * (Palette "group")  GtkWindow               Palette of LaTeX symbols.
 * (Plugins)          GtkMenuToolButton       List of available plugins.
 * (Browser)          GtkEntry                LaTeX documentation browser.  
 *)
and toolitem ?icon_pattern:pat ~packing = function
  | `Flag "Separator" -> ignore (GButton.separator_tool_item ~packing ())
  | `Leaf ("Button", `Str id, opt) ->  
    let stock = match Opt.get_string "icon" opt with
      | Some id -> Some (`STOCK id) 
      | None -> Gaux.may_map (fun f -> f id) pat in
    let item = GButton.tool_button ?stock ~packing () in
    item#misc#set_tooltip_text (Lang.get id);
    item#connect#clicked ~callback:(FunTable.run id);
    !add id (`ToolButton item)
  | `Leaf ("LaTeX", `Str id, opt) ->
    (* LaTeX items are inserted as tool buttons. *)
    if LaTeX.Main.mem_item id then begin
      let t = LaTeX.Main.get_item id in
      let stock = match Opt.get_string "icon" opt with
        | Some str -> `STOCK str
        | _ -> LaTeX.Main.get_stock t in
      let item = GButton.tool_button ~stock ~packing () in
      item#misc#set_tooltip_markup (LaTeX.Main.to_markup t);
      item#connect#clicked ~callback:(FunTable.run_with_arg "latex-insert" t);
      !add id (`ToolButton item)
    (* LaTeX groups are inserted as combo boxes. *)
    end else begin
      let item = GButton.tool_item ~packing () in
      let combo = Combo.make ~packing:item#add () in
      Combo.feed combo id;
      combo.combo#connect#changed (Combo.insert combo);
      !add id (`Combo combo)
    end
  | `Leaf ("Palette", `Str id, _) ->
    let group = LaTeX.Main.get_group id in
    let n = Array.length group in
    if n > 0 then begin
      let wnd = GWindow.window
        ~kind:`POPUP
        ~modal:true
        ~type_hint:`DOCK 
        ~position:`MOUSE ~width:220 ~height:150 () in
      let scroll = GBin.scrolled_window 
        ~hpolicy:`AUTOMATIC 
        ~vpolicy:`ALWAYS
        ~packing:wnd#add () in
      let hide _ = wnd#misc#hide (); false in 
      !window#event#connect#expose hide;
      !window#event#connect#window_state hide;
      !window#event#connect#focus_out hide;
      wnd#event#connect#key_release (fun t ->
        if GdkEvent.Key.keyval t = 65307 then (wnd#misc#hide (); true) 
        else false);
      let table = GPack.table 
        ~rows:(n / 7)
        ~columns:7
        ~packing:scroll#add_with_viewport () in
      Array.iteri (fun i t ->
        let left = i mod 7 and top = i / 7 in
        let btn = GButton.button ~packing:(table#attach ~left ~top) () in
        btn#misc#set_tooltip_markup (LaTeX.Main.to_markup t);
        btn#misc#set_can_default false;
        btn#connect#clicked (FunTable.run_with_arg "latex-insert" t);
        btn#connect#clicked wnd#misc#hide;
        let stock = LaTeX.Main.get_stock t in
        ignore (GMisc.image ~stock ~icon_size:`MENU ~packing:btn#set_image ())
      ) group;
      let item = GButton.tool_button 
        ~stock:(LaTeX.Main.get_stock group.(0)) 
        ~packing () in
      item#misc#set_tooltip_text (Lang.get id);
      item#connect#clicked wnd#show;
      !add id (`ToolButton item)
    end
  | `Flag "Plugins" ->
    let menu = GMenu.menu () in
    PluginTools.feed menu;
    let item = GButton.menu_tool_button ~menu ~stock:`PROPERTIES ~packing
      ~use_underline:true () in
    item#connect#clicked (FunTable.run_with_arg "preferences" (Some 4));
    !add "Plugins" (`MenuButton item)
  | `Flag "Browser" ->
    let item = new Widgets.texdoc
      ~packing:(GButton.tool_item ~packing ())#add
    in !add "browser" (`Browser item)
  | _ -> eprintf "(OCamlTeX) Warning: Unknown toolitem was discarded.\n%!"

(* Menuitem builder. Separators and tearoffs are not saved. *)
and menuitem ?icon_pattern ~packing = function
  | `Flag "Tearoff" -> ignore (GMenu.tearoff_item ~packing ())   
  | `Flag "Separator" -> ignore (GMenu.separator_item ~packing ())
  | `Leaf ("Image", `Str id, opt) ->
    let item = GMenu.image_menu_item
      ~label:(Lang.get id)
      ~packing () in
    let g = set_stock item#set_image in
    begin match Icon.may opt with 
      | Some id -> g id
      | _ -> Option.may (fun f -> g (f id)) icon_pattern
    end;
    item#connect#activate ~callback:(FunTable.run id);
    Accel.add item opt;
    !add id (`ImageItem item)
  | `Leaf ("Check", `Str id, opt) ->
    let item = GMenu.check_menu_item
      ~label:(Lang.get id)
      ~packing () in
    item#connect#toggled ~callback:(FunTable.run id);
    item#set_active (Check.is_active opt);
    Accel.add item opt;
    !add id (`CheckItem item)
  | `Flag ("Plugins") as mnu -> menu ~packing mnu
  | `Flag ("Templates") as mnu -> menu ~packing mnu
  | `Node ("Menu", `Str _, _, _) as mnu -> menu ~packing mnu 
  | `Leaf ("LaTeX", `Str id, _) -> LaTeXSubMenu.build ~packing id
  | _ -> eprintf "(OCamlTeX) Warning: Unknown menuitem.\n%!"

and ribbon_tab ?icon_pattern:pat ~packing:f = function
  | `Node ("Tab", `Str id, opt, contents) ->
    let tab_label = GMisc.label 
      ~width:120 
      ~use_underline:true 
      ~markup:(Lang.get id) () in
    let container = GPack.hbox ~border_width:5 ~spacing:5 () in
    f ~tab_label:tab_label#coerce container#coerce;
    List.iter (
      ribbon_block 
        ~toplevel:true
        ?icon_pattern:(Opt.may_override pat "icon_pattern" Aux.substitute opt)
        ~packing:(fun x -> container#pack ~expand:false x)
    ) contents
  | _ -> assert false

and ribbon_block ~toplevel ?icon_pattern:pat ~packing = function
  | `Flag "Separator" -> ignore (GMisc.separator `VERTICAL ~packing ())
  | `Node ("Block", `Str id, opt, contents) ->
    let rows = max 2 ((Assoc.get_int "rows" opt) + 1)
    and columns = max 1 (Assoc.get_int "cols" opt) in
    let packing = 
      if toplevel then
        begin GBin.handle_box
          ~border_width:5
          ~shadow_type:`NONE ~packing ()
        end #add
      else packing in
    let table = GPack.table ~rows ~columns 
      ~row_spacings:5 ~col_spacings:5 ~packing () in
    if toplevel then ignore (GMisc.label
      ~use_underline:true 
      ~markup:(Lang.format id "<span size='small' color='#808080'><b>%s</b></span>")
      ~packing:(table#attach ~left:0 ~right:columns ~top:0) ());
    RibbonBlock.iter (fun r c item -> 
      ribbon_item 
        ?icon_pattern:(Opt.may_override pat "icon_pattern" Aux.substitute opt)
        ~packing:(table#attach ~left:c ~top:r) item
    ) rows columns contents
  | _ -> assert false

and ribbon_item ?icon_pattern:pat ~packing = function
  | `Node ("Block", _, opt, _) as block ->
    let right = match Assoc.get_int "right" opt with
      | 0 -> None
      | n -> Some n 
    and bottom = match Assoc.get_int "bottom" opt with
      | 0 -> None
      | n -> Some n in
    ribbon_block 
      ~toplevel:false 
      ?icon_pattern:(Opt.may_override pat "icon_pattern" Aux.substitute opt)
      ~packing:(packing ?right ?bottom) block
  | `Leaf ("LaTeX", `Str id, _) ->
    if LaTeX.Main.mem_item id then begin
      let t = LaTeX.Main.get_item id in
      let stock = LaTeX.Main.get_stock t in
      let item = GButton.button ~packing () in
      GMisc.image ~stock ~icon_size:`SMALL_TOOLBAR ~packing:item#set_image ();
      item#misc#set_tooltip_markup (LaTeX.Main.to_markup t);
      item#connect#clicked ~callback:(FunTable.run_with_arg "latex-insert" t);
      !add id (`Button item)
    end else begin
      let combo = Combo.make ~packing () in
      Combo.feed combo id;
      combo.combo#connect#changed (Combo.insert combo);
      !add id (`Combo combo)
    end
  | `Leaf ("Image", `Str id, opt) ->    
    let stock = match Icon.may opt with
      | None -> (match pat with Some f -> Some (f id) | _ -> None)
      | some -> some in
    let item = GButton.button
      ?label:(RibbonItem.get_text id opt) 
      ~packing () in
    item#set_image (GMisc.image 
      ?stock 
      ~icon_size:(RibbonItem.get_size opt) ()
    )#coerce;
    item#misc#set_tooltip_text (Lang.get id);
    item#connect#clicked ~callback:(FunTable.run id);
    !add id (`Button item)
  | `Leaf ("Check", `Str id, opt) ->
    let item = GButton.check_button
      ~label:(Lang.get id)
      ~packing () in
    item#connect#toggled ~callback:(FunTable.run id);
    item#set_active (Check.is_active opt);
    !add id (`Check item)
  | `Flag "Templates" ->
    let combo = TemplatesTools.make_combo ~packing () in
    TemplatesTools.feed_combo combo;
    combo._combo#connect#changed (fun () ->
      match combo._combo#active_iter with
      | Some row -> ()
      | _ -> ()); ()
  | `Flag "Browser" ->
    let item = new Widgets.texdoc ~packing in
    !add "browser" (`Browser item)
  | `Flag "Separator" -> ignore (GMisc.separator `VERTICAL ~packing ())
  | `Node ("Toolbar", _, _, _) as item -> bar ?icon_pattern:pat ~packing item 
  | _ -> assert false


(* GUI Builder. *)
let from_config ~accels:group ~packing ~storing:f ~parent:wnd = 
  add := f;
  accels := group;
  window := wnd;
  try
    let file = Filename.concat App.Dir.gui (AppPrefs.get "gui-file") in
    List.iter (bar ~packing) (Sexpr.from_file file)
  with exn -> 
    eprintf "(OCamlTeX) Error: GUI loading failure.\nError: %s%!"
      (Printexc.to_string exn); exit 2
