(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

type t = Builder.latex_item

let is_command t = not t.Builder.tex_kind
let is_environment t = t.Builder.tex_kind

(* Getters. *)
let require_mathmode t = t.Builder.constr_mathmode
let require_preamble t = t.Builder.constr_preamble
let require_package t = 
  match t.Builder.constr_usepackg with
  | [] -> None
  | x :: _ -> Some x
let require_classes t = t.Builder.constr_docclass
let define_mathmode t = t.Builder.define_mathmode
let define_verbatim t = t.Builder.define_verbatim

let get_id t = t.Builder.tex_name
let get_stock t = t.Builder.stock_id

(* Markup conversion. *)
module Markup =
  struct
    let string_of_args buf =
      List.iter (function
        | `Arg str -> bprintf buf "{<i>%s</i>}" str
        | `Opt str -> bprintf buf "[<i>%s</i>]" str
      )
    let of_environment buf env =
      bprintf buf "<b>\\begin</b>{%s}" env.Builder.tex_name;
      string_of_args buf env.Builder.tex_args
    let of_command buf cmd =
      bprintf buf "<b>\\%s</b>" cmd.Builder.tex_name;
      string_of_args buf cmd.Builder.tex_args
    let of_item t = 
      let buf = Buffer.create 16 in
      Buffer.add_string buf "<tt><small>";
      (if t.Builder.tex_kind then of_environment else of_command) buf t;
      Buffer.add_string buf "</small></tt>";
      Buffer.contents buf
  end

module Insert =
  struct
    let string_of_args buf =
      List.iter (function
        | `Arg _ -> Buffer.add_string buf "{}"
        | `Opt _ -> Buffer.add_string buf "[]"
      )
    let of_environment n buf env =
      bprintf buf "\\begin{%s}" env.Builder.tex_name;
      string_of_args buf env.Builder.tex_args;
      bprintf buf "\n\n%s\\end{%s}" (String.make n ' ') env.Builder.tex_name
    let of_command buf cmd =
      bprintf buf "\\%s" cmd.Builder.tex_name;
      string_of_args buf cmd.Builder.tex_args
    let of_item n t = 
      let buf = Buffer.create 16 in
      (if t.Builder.tex_kind then of_environment n else of_command) buf t;
      Buffer.contents buf
  end

(* String conversion. *)
module String =
  struct
    let string_of_args buf =
      List.iter (function
        | `Arg _ -> Buffer.add_string buf "{}"
        | `Opt _ -> Buffer.add_string buf "[]"
      )
    let of_item t = 
      let buf = Buffer.create 16 in
      bprintf buf "\\%s" t.Builder.tex_name;
      string_of_args buf t.Builder.tex_args;
      Buffer.contents buf
  end

let to_string = String.of_item
let to_markup = Markup.of_item
let to_insert = Insert.of_item

let backchars t =
  begin match List.length (t.Builder.tex_args) with
    | 0 -> 0
    | n -> n lsl 1 - if t.Builder.tex_kind then 0 else 1
  end + if t.Builder.tex_kind then Glib.Utf8.length t.Builder.tex_name + 7 
  else 0

(* Storing. *)
module Storing =
  struct
    let trie = ref Trie.ASCII.empty
    let main = Hashtbl.create 7 
    let groups = Hashtbl.create 7
    let symbols = Hashtbl.create 7
  end

let from_trie_id = Hashtbl.find Storing.main

let get_prefix x = 
  try Some (Trie.ASCII.sub x !Storing.trie) with Not_found -> None

let mem_item = Hashtbl.mem Storing.main
let mem_group = Hashtbl.mem Storing.groups
let mem_symbols = Hashtbl.mem Storing.symbols

let get_item id = Hashtbl.find Storing.main id

let get_group id = 
  try Hashtbl.find Storing.groups id with
  | Not_found -> Print.warning [||] "Unkown LaTeX group %S.\n%!" id

let get_symbols id = 
  try Hashtbl.find Storing.symbols id with
  | Not_found -> Print.warning [||] "Unkown symbol table %S.\n%!" id

let get_symbol_tables () =
  Hashtbl.fold (fun x y l -> (x, y) :: l) Storing.symbols []

let init () = 
  let main_storing t = Hashtbl.add Storing.main (to_string t) t
  and trie_storing t = Storing.trie := Trie.ASCII.add (to_string t) !Storing.trie
  and group_storing = Hashtbl.add Storing.groups
  and symbol_storing = Hashtbl.add Storing.symbols in
  Builder.from_config ~main_storing ~trie_storing ~group_storing ~symbol_storing
