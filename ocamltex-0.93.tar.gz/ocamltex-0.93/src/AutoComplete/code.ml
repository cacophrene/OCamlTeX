(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type data = {
  col_icon : GtkStock.id GTree.column;    (* LaTeX item stock id. *)
  col_text : string GTree.column;         (* LaTeX item markup.   *)
  col_item : LaTeX.Main.t GTree.column;   (* LaTeX item.          *)
  store : GTree.list_store;               (* List store.          *)
}

type area = {
  frame : GObj.widget;                    (* Popup frame.         *)
  scroll : GBin.scrolled_window;          (* Scrolled window.     *)
  view : GTree.view                       (* List view.           *)
}

type t = { 
  data : data; 
  vcol : GTree.view_column; 
  area : area;
  source : GSourceView2.source_view;
  buffer : GSourceView2.source_buffer
}

(* Some getters to hide the implementation in the code below. *)
let col_icon t = t.data.col_icon
let col_text t = t.data.col_text
let col_item t = t.data.col_item
let view_col t = t.vcol
let store t = t.data.store
let source t = t.source
let buffer t = t.buffer
let frame t = t.area.frame
let view t = t.area.view

(* Code completion popup window. *)
module Popup =
  struct
    (* Show popup with suggestions. *)
    let show =
      let arrow = Gdk.Cursor.create `ARROW in
      fun t (x, y) ->
        let child = frame t in
        (source t)#move_child ~child ~x ~y;
        child#misc#show ();
        Gdk.Window.set_cursor (view t)#misc#window arrow
    (* Hide popup and clear contents. 
     * The unused second argument and the boolean returned value 
     * are both needed by button_press and scroll events. *)
    let hide t _ =
      (frame t)#misc#hide ();
      false
  end

(* Get selected iter. *)
let get_selected_iter t =
  match (view t)#selection#get_selected_rows with
  | path :: _ -> (store t)#get_iter path
  | [] -> 
    match (store t)#get_iter_first with
    | Some iter -> iter
    | _ -> Print.failure 8 "Code completion list view is empty"

(* Try to determine the best popup coordinates. *)
let best_coord t =
  let r1 = (source t)#get_iter_location ((buffer t)#get_iter `INSERT)
  and r2 = (source t)#visible_rect in
  if Gdk.Rectangle.width r2 > 300 && Gdk.Rectangle.height r2 > 100 then (
    let x = Gdk.Rectangle.x r1 - Gdk.Rectangle.x r2 
    and y = Gdk.Rectangle.y r1 - Gdk.Rectangle.y r2 + 14 in
    Some ((x - if x + 280 >= Gdk.Rectangle.width  r2 then 280 else 0),
    (y - if y + 100 >= Gdk.Rectangle.height r2 then 114 else 0))
  ) else None

(* Add suggestions and show popup. *)
let suggest t trie =
  let store = store t in
  store#clear ();
  Trie.ASCII.iteri (fun i id ->
    let item = LaTeX.Main.from_trie_id id in
    let row = store#append () in
    store#set ~row ~column:(col_item t) item;
    store#set ~row ~column:(col_icon t) (LaTeX.Main.get_stock item);
    store#set ~row ~column:(col_text t) (LaTeX.Main.to_markup item);
    if i = 0 then (view t)#selection#select_iter row
  ) trie;
  Option.may (Popup.show t) (best_coord t)

(* Try to determine whether the current input is a LaTeX item. *)
let check_input =
  let pat = Str.regexp_case_fold "\\\\[a-z]+" in
  fun t () ->
    let stop = (buffer t)#get_iter `INSERT in
    if stop#ends_word then (
      let start = stop#backward_word_start#backward_char in
      let str = (buffer t)#get_text ~start ~stop () in
      if Str.string_match pat str 0 then 
      match LaTeX.Main.get_prefix str with
      | Some trie when Trie.ASCII.length trie > 0 -> suggest t trie
      | _ -> ignore (Popup.hide t ())
    ) else if (frame t)#misc#visible then ignore (Popup.hide t ())

(* Display selected LaTeX item, then hide popup. *)
let finalize t _ =
  let row = get_selected_iter t in
  let stop = (buffer t)#get_iter `INSERT in
  let start = stop#backward_word_start#backward_char in
  (buffer t)#delete ~start ~stop;
  let cmd = (store t)#get ~row ~column:(col_item t) in
  FunTable.run_with_arg "latex-insert" cmd ();
  Popup.hide t ()

(* Choose action when a key is pressed. *)
let select_action t ev =
  if (frame t)#misc#visible then (
    let here = (store t)#get_path (get_selected_iter t) in
    (*Printf.printf "keyval: %X\n%!" (GdkEvent.Key.keyval ev);*)
    match GdkEvent.Key.keyval ev with
      | 0xFF52 (* Up arrow *) -> GTree.Path.prev here;
        (view t)#set_cursor here (view_col t); true
      | 0xFF54 (* Down arrow *) -> GTree.Path.next here;
        (view t)#set_cursor here (view_col t); true
      | 0xFF0D | 0xFF8D (* Entry *) -> not (finalize t ())
      | 0xFF1B | 0xFF08 | 0xFF9A | 0xFF9B | 0xFF95
      | 0xFF96 | 0xFF98 | 0xFF51 | 0xFF53 -> Popup.hide t ()
      | _ -> false
  ) else false

(* Tree view data. *)
let get_data () =
  let cols = new GTree.column_list in
  let col_icon = cols#add GtkStock.conv
  and col_text = cols#add Gobject.Data.string
  and col_item = cols#add Gobject.Data.caml
  and store = GTree.list_store cols in
  { col_icon = col_icon; col_text = col_text; col_item = col_item; store = store }

(* Tree view cell renderers and columns. *)
let get_view data =
  let cell_icon = GTree.cell_renderer_pixbuf []
  and cell_text = GTree.cell_renderer_text [`XPAD 5] in
  let vcol = GTree.view_column () in
  vcol#pack ~expand:false cell_icon;
  vcol#add_attribute cell_icon "stock_id" data.col_icon;
  vcol#pack cell_text;
  vcol#add_attribute cell_text "markup" data.col_text;
  vcol

(* Tree view and scrolled window. *)
let get_area data vcol =
  let scroll = GBin.scrolled_window
    ~width:280 ~height:80
    ~hpolicy:`NEVER
    ~vpolicy:`ALWAYS
    ~shadow_type:`ETCHED_IN ~show:false () in
  let view = GTree.view 
    ~model:data.store
    ~headers_visible:false
    ~rules_hint:true 
    ~packing:scroll#add () in
  view#append_column vcol;
  view#set_hover_selection true;
  { frame = scroll#coerce; scroll = scroll; view = view }

(* Main function. *)
let add (source : GSourceView2.source_view) =
  let data = get_data () in
  let vcol = get_view data in
  let area = get_area data vcol in
  source#add_child_in_window ~child:area.frame ~which_window:`TEXT ~x:0 ~y:0;
  let buffer = source#source_buffer in
  let t = { data = data; vcol = vcol; area = area; source = source; buffer = buffer } in
  buffer#connect#changed (check_input t);
  (view t)#event#connect#button_release (finalize t);
  let connect = source#event#connect in
  connect#key_press (select_action t);
  connect#button_press (Popup.hide t);
  connect#scroll (Popup.hide t);
  t
