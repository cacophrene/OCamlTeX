(* OCamlTeX - Compilation script *)

open Ocamlbuild_pack
open Ocamlbuild_plugin

let _ =
  dispatch begin function 
    | After_options ->
      let dirs = ["-I"; "+lablgtk2"] in
      Options.ocaml_libs := ["lablgtk"; "lablgtksourceview2"; "str"; "unix"; 
        "dynlink"];
      Options.ocaml_cflags := dirs @ ["-w"; "s"; "-g"];
      Options.ocaml_lflags := dirs @ ["-g"];
      flag ["ocaml"; "doc"] (S [A "-I"; A "+lablgtk2"])
    | _ -> ()
  end
