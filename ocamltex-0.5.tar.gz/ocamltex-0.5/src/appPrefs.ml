(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

let pref = Hashtbl.create 7

let add = Hashtbl.add pref

let get id = 
  try Hashtbl.find pref id with
  | Not_found ->
    eprintf "(OCamlTeX) Warning: Unknown ID %S.\n%!" id;
    id

let get_bool id = 
  try bool_of_string (Hashtbl.find pref id) with
    | Not_found ->
      eprintf "(OCamlTeX) Warning: Unknown ID %S.\n%!" id;
      false
    | Invalid_argument "bool_of_string" -> 
      eprintf "(OCamlTeX) Warning: ID %S does not store a boolean.\n%!" id;
      false

let set ~id x = Hashtbl.replace pref id x

let parse_prefs = function
  | `Assc ("Set", `Str id, dat) -> add id dat
  | _ -> eprintf "(OCamlTeX) Warning: Unknown preference.\n%!"

let init () = List.iter parse_prefs (Sexpr.from_file "config/ocamltex-prefs")

module SaveAtExit =
  struct
    let header = "(* OCamlTeX - Preferences File.\n \
      * Caution: This file is part of OCamlTeX and thus should be edited \
        carefully.\n *)\n\n"
    let compare_couples (x, _) (y, _) = String.compare x y
    let export =
      let export () =
        let l = Hashtbl.fold (fun key x l -> (key, x) :: l) pref [] in
        let l = List.sort compare_couples l in
        let och = open_out "config/ocamltex-prefs" in
        Printf.fprintf och "%s" header;
        let key, dat = List.split l in
        List.iter2 (Printf.fprintf och "(Set \"%s\" = \"%s\")\n") key dat;
        close_out och
      in at_exit export; export
  end
