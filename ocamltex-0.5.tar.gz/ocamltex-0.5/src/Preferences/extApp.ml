(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let tab_label = 
  begin GMisc.label 
    ~text:(Lang.get "prefs-ext-apps") ()
  end #coerce

let vbox = GPack.vbox ~border_width:10 ~spacing:10 ()
let packing = vbox#pack ~expand:false
let container = vbox#coerce

let _ = GMisc.label
  ~xalign:0.
  ~markup:(Printf.sprintf "<b>%s</b>" (Lang.get "prefs-doc-viewers"))
  ~packing ()

let hbox = Tools.hbox_with_indent ~packing ()

let table = GPack.table
  ~rows:5
  ~columns:2
  ~row_spacings:10
  ~col_spacings:10
  ~packing:hbox#add ()

let make_viewer id top =
  ignore (GMisc.label
    ~xalign:0.
    ~text:(Lang.get id) 
    ~packing:(table#attach ~left:0 ~top) ());
  GEdit.entry 
    ~packing:(table#attach ~left:1 ~top ~expand:`X) ()

let dvi_viewer  = make_viewer "prefs-dvi-viewer"  0
let pdf_viewer  = make_viewer "prefs-pdf-viewer"  1
let ps_viewer   = make_viewer "prefs-ps-viewer"   2
let html_viewer = make_viewer "prefs-html-viewer" 3
let text_viewer = make_viewer "prefs-text-viewer" 4

let import () =
  dvi_viewer#set_text  (AppPrefs.get "dvi-viewer");
  pdf_viewer#set_text  (AppPrefs.get "pdf-viewer");
  ps_viewer#set_text   (AppPrefs.get "ps-viewer");
  html_viewer#set_text (AppPrefs.get "html-viewer");
  text_viewer#set_text (AppPrefs.get "text-viewer")

let export () =
  AppPrefs.set "dvi-viewer"  dvi_viewer#text;
  AppPrefs.set "pdf-viewer"  pdf_viewer#text;
  AppPrefs.set "ps-viewer"   ps_viewer#text;
  AppPrefs.set "html-viewer" html_viewer#text;
  AppPrefs.set "text-viewer" text_viewer#text;
