(* oCamlTeX.ml *)

let _ =
  (* Registering functions. *)
  Plugin.init ();
  Actions.init ();
  Project.Main.init ();
  (* Menubar and toolbar building. All functions have been previously
   * registered to ensure correct initialization. *)
  GUI.Main.init ();
  (* Cleanup needed here! *)
  Preferences.Main.init ();
  Dialog.Main.init ();
  GUI.Main.window#show ();
  GMain.main ()
