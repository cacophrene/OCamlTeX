(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type arg = [ `Arg of string | `Opt of string | `Par of string ]

type flag = [
  | `Stock
  | `Preamble
  | `MathMode 
  | `Verbatim
  | `UsePackg of string
]

type latex_item = {
  tex_kind : bool;
  tex_name : string;
  tex_args : arg list;
  tex_flag : flag list
}

let add_gen = ref (Obj.magic ())
let add_grp = ref (Obj.magic ())
let add_sym = ref (Obj.magic ())

(* Get flag list from option list. *)
let flag_list =
  let rec loop acc = function
    | [] -> acc
    | ("mathmode", `Bln true) :: t -> loop (`MathMode :: acc) t
    | ("verbatim", `Bln true) :: t -> loop (`Verbatim :: acc) t
    | ("preamble", `Bln true) :: t -> loop (`Preamble :: acc) t
    | ("usepackg", `Str pckg) :: t -> loop (`UsePackg pckg :: acc) t
    | ("icon", `Str path) :: t -> Symbols.add path; loop (`Stock :: acc) t
    | _ :: t -> loop acc t
  in loop []

let get_bool id opt =
  try
    match List.assoc id opt with 
    | `Bln bln -> bln
    | _ -> false
  with Not_found -> false

let rev_concat l = String.concat "-" (List.rev l)

(* LaTeX groups, commands and environments. *)
let rec parse_latex l =
  let rec loop buf = function
    | [] -> []
    | `Node ("Group", `Str id, opt, contents) :: t ->
      let buf' = id :: buf in 
      let l = loop buf' contents in
      let id = rev_concat buf' and tbl = Array.of_list l in
      if get_bool "symbols" opt then !add_sym id tbl;
      !add_grp id tbl;
      l @ loop buf t
    | `Node (str, `Str id, opt, args) :: t ->
      let cmd = {
        tex_kind = str = "Environment"; 
        tex_name = id;
        tex_args = parse_args args;
        tex_flag = flag_list opt
      } in !add_gen (rev_concat (id :: buf)) cmd;
      cmd :: loop buf t
    | `Leaf (str, `Str id, opt) :: t ->
      let cmd = {
        tex_kind = str = "Environment"; 
        tex_name = id;
        tex_args = [];
        tex_flag = flag_list opt
      } in !add_gen (rev_concat (id :: buf)) cmd;
      cmd :: loop buf t
    | _ :: t -> loop buf t 
  in ignore (loop [] l)

(* LaTeX arguments. *)
and parse_args = function
  | [] -> []
  | `Leaf ("Arg", `Str id, _) :: t -> `Arg id :: parse_args t
  | `Leaf ("Opt", `Str id, _) :: t -> `Opt id :: parse_args t
  | `Leaf ("Par", `Str id, _) :: t -> `Par id :: parse_args t
  | _ -> invalid_arg "LaTeX.Builder.parse_args"

let from_config ~main_storing:f ~group_storing:g ~symbol_storing:h =
  add_gen := f; add_grp := g; add_sym := h;
  parse_latex (Sexpr.from_file "config/ocamltex-latex")
