(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

let get_full_env () =
  Array.append (Unix.environment ())
  [| sprintf "TEXDOCVIEW_ps=%s %%s"   (AppPrefs.get "ps-viewer"  );
     sprintf "TEXDOCVIEW_dvi=%s %%s"  (AppPrefs.get "dvi-viewer" );
     sprintf "TEXDOCVIEW_pdf=%s %%s"  (AppPrefs.get "pdf-viewer" );
     sprintf "TEXDOCVIEW_html=%s %%s" (AppPrefs.get "html-viewer");
     sprintf "TEXDOCVIEW_text=%s %%s" (AppPrefs.get "text-viewer"); |]

class texdoc ~packing =
  object (self)
    val hbox = 
      let item = GButton.tool_item ~packing () in
      GPack.hbox ~spacing:5 ~packing:item#add ()
    val stock = GMisc.image ~stock:`HELP ()
    val entry = GEdit.entry ()

    initializer
      entry#event#connect#key_release self#may_show_doc;
      List.iter hbox#add [stock#coerce; entry#coerce]
 
   method private may_show_doc t =
      if GdkEvent.Key.keyval t = 65293 then
        Shell.run_env "texdoc" [|entry#text|] (get_full_env ());
      false
    method entry = entry
  end
