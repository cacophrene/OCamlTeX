(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let notebook = GPack.notebook ()

module Projects =
  struct
    let tab_label =
      let hbox = GPack.hbox ~spacing:5 () in
      ignore (GMisc.image ~stock:`EDIT ~icon_size:`MENU ~packing:hbox#add ());
      ignore (GMisc.label
        ~text:(Lang.get "GUI.Sidebar.Projects.tab_label")
        ~packing:hbox#add ());
      hbox#coerce

    let vbox = GPack.vbox 
      ~spacing:5 
      ~border_width:5 ()
    let container = vbox#coerce
    
    let scroll = GBin.scrolled_window
      ~hpolicy:`AUTOMATIC
      ~vpolicy:`AUTOMATIC
      ~shadow_type:`ETCHED_IN
      ~packing:vbox#add ()
  end

module Symbols =
  struct
    let tab_label =
      let hbox = GPack.hbox ~spacing:5 () in
      ignore (GMisc.image ~stock:`EDIT ~icon_size:`MENU ~packing:hbox#add ());
      ignore (GMisc.label
        ~text:(Lang.get "GUI.Sidebar.Symbols.tab_label")
        ~packing:hbox#add ());
      hbox#coerce

    let table_of_array t =
      let n = Array.length t in
      let table = GPack.table 
        ~rows:(n / 5 + if n mod 5 = 0 then 0 else 1)
        ~columns:5
        ~row_spacings:10
        ~col_spacings:10
        ~border_width:10
        ~homogeneous:true () in
      let sym = Lang.get "symbol" in
      Array.iteri (fun i t ->
        let btn = GButton.button ~relief:`NONE () in
        btn#connect#clicked (FunTable.run_with_arg "latex-insert" t);
        btn#misc#set_can_focus false;
        btn#set_image (GMisc.image 
          ~stock:(LaTeX.Main.get_stock t) 
          ~icon_size:`BUTTON ()
        )#coerce;
        Printf.ksprintf btn#misc#set_tooltip_markup "%s : %s" 
          sym (LaTeX.Main.to_markup t);
        table#attach ~left:(i mod 5) ~top:(i / 5) btn#coerce;
      ) t;
      table

    let tables, strings =
      let htbl = Hashtbl.create 7 in
      let rec loop acc = function
        | [] -> (htbl, List.sort String.compare acc)
        | (id, t) :: l -> let translation = Lang.get id in 
          Hashtbl.add htbl translation (table_of_array t);
          loop (translation :: acc) l
      in loop [] (LaTeX.Main.get_symbol_tables ())

    let vbox = GPack.vbox 
      ~spacing:5 
      ~border_width:5 ()
    let container = vbox#coerce
    
    let all = GEdit.combo_box_text
      ~strings
      ~use_markup:true
      ~packing:(vbox#pack ~expand:false) ()

    let store = fst (snd all)
    let column = snd (snd all)

    let scroll = GBin.scrolled_window
      ~hpolicy:`ALWAYS
      ~vpolicy:`ALWAYS
      ~packing:vbox#add ()

    let display combo () =
      match combo#active_iter with
      | None -> ()
      | Some row -> 
        let name = store#get ~row ~column in
        let table = Hashtbl.find tables name in
        List.iter scroll#remove scroll#children;
        begin match table#misc#parent with 
          | Some _ -> table#misc#unparent ()
          | _ -> ()
        end;
        scroll#add_with_viewport table#coerce

    let combo = 
      let combo = fst all in
      combo#connect#changed (display combo);
      combo#set_active 0;
      combo
  end

(* Tabs registration. *)
let _ =
  List.iter2 (fun tab_label x -> notebook#append_page ~tab_label x; ())
    [ Projects.tab_label; Symbols.tab_label ] 
    [ Projects.container; Symbols.container ]
