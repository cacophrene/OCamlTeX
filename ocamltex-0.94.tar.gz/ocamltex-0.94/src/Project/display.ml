(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Core.AppPrefs

let get_scroll () = 
  GBin.scrolled_window
    ~hpolicy:`ALWAYS
    ~vpolicy:`ALWAYS
    ~border_width:5
    ~shadow_type:`ETCHED_IN ()

let get_source ~packing = 
  let src = GSourceView2.source_view
    ~draw_spaces:(if get_bool "draw-spaces" then [`NEWLINE; `SPACE] else [])
    ~auto_indent:true
    ~highlight_current_line:(get_bool "highlight-current-line")
    ~indent_on_tab:true
    ~indent_width:2
    ~insert_spaces_instead_of_tabs:true
    ~right_margin_position:(get_int "right-margin-position")
    ~show_line_numbers:(get_bool "show-line-numbers")
    ~show_right_margin:(get_bool "show-right-margin")
    ~packing () in
  src#event#connect#key_press (fun t -> 
    FunTable.run_with_arg ~def:false "suppr" t ());
  src#misc#modify_font_by_name (get "editor-font");
  let buf = src#source_buffer in
  src#connect#move_cursor (fun _ _ ~extend:_ ->
    let here = buf#get_iter `INSERT in
    Printf.ksprintf GUI.Main.lnum#set_label "Lig %d" here#line
  );
  buf#set_highlight_syntax (get_bool "highlight-syntax");
  buf#set_language GUI.Main.latex;
  let id = get "style-scheme" in
  buf#set_style_scheme (GUI.Main.scheme_manager#style_scheme id);
  src

let source () =
  let scroll = get_scroll () in
  let source = get_source ~packing:scroll#add in
  source, scroll#coerce

let tab_label ~stock text =
  let hbox = GPack.hbox ~spacing:5 () in
  let packing = hbox#pack ~expand:false in
  let image = GMisc.image ~stock ~icon_size:`MENU ~packing () in
  let label = GMisc.label ~text ~packing () in
  (hbox#coerce, label, image)
