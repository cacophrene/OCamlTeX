(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let quit = FunTable.add "quit" GUI.Main.window#destroy

let toggle_fullscreen =
  let f =
    let switch = ref false in
    fun () ->
      switch := not !switch;
      if !switch then GUI.Main.window#fullscreen ()
      else GUI.Main.window#unfullscreen ()
  in FunTable.add "toggle-fullscreen" f

let toggle_side_pane =
  let f =
    let switch = ref false in
    fun () ->
      switch := not !switch;
      if !switch then GUI.Main.hpaned#pack1 ~shrink:false 
        GUI.SidePane.notebook#coerce    
      else GUI.Main.hpaned#remove GUI.Main.hpaned#child1;
  in FunTable.add "toggle-side-pane" f

let toggle_bottom_pane =
  let f =
    let switch = ref false in
    fun () ->
      switch := not !switch;
      if !switch then GUI.Main.vpaned#pack2 ~shrink:false 
        GUI.BottomPane.notebook#coerce    
      else GUI.Main.vpaned#remove GUI.Main.vpaned#child2;
  in FunTable.add "toggle-bottom-pane" f

let switch_page =
  FunTable.add "switch-page" begin fun n ->
    let x = GUI.Main.opened_files#get_nth_page n in
    Project.File.set_current (Project.File.get_from_widget x);
    Project.File.update_title (Project.File.get_current ())
  end

let doc_changed =
  let module X = GUI.SidePane.Project.Data in
  FunTable.add "doc-changed" (fun sel ->
    match sel#get_selected_rows with
      | [] -> ()
      | x :: _ -> let row = X.store#get_iter x in
        let n = X.store#get ~row ~column:X.oid in
        Project.File.set_current (Project.File.get_from_oid n)
  )

let go_back = FunTable.add "go-back" GUI.Main.opened_files#previous_page
let go_forward = FunTable.add "go-forward" GUI.Main.opened_files#next_page
