(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Project.File

let save_all = FunTable.add "save-all" (fun () -> iter save)
let save = FunTable.add "save" (fun () -> save (get_current ()))
let save_as = FunTable.add "save-as" (fun () -> save_as (get_current ()))

let close_all = FunTable.add "close-all" (fun () -> iter close)
let close = FunTable.add "close" (fun () -> close (get_current ()))

let load_template =
  FunTable.add "load-template" (fun name ->
    create ();
    let t = get_current () in
    match Core.Templates.get_contents name with
    | Some text -> Set.contents t text
    | _ -> () (* Unknown template file. *)
  )

let build =
  FunTable.add "build" (fun () ->
    let t = get_current () in
    let file = get_file t in
    if is_saved t then Build.run ~file
  )

let validate =
  FunTable.add "validate" (fun () ->
    Wizard.Main.validate (get_buffer (get_current ()))
  )
