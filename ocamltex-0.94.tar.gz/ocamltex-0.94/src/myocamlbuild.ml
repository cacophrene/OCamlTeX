(* OCamlTeX - Compilation script *)

open Ocamlbuild_pack
open Ocamlbuild_plugin

let libs = ["lablgtk"; "lablgtksourceview2"; "str"; "unix"; "dynlink"]

let _ =
  dispatch (function 
    | After_options ->
      Options.ocaml_libs := libs;
      Options.ocaml_cflags := ["-I"; "+lablgtk2"; "-g"; "-w"; "sx"];
      Options.ocaml_lflags := ["-I"; "+lablgtk2"; "-g"]
    | _ -> ()
  )
