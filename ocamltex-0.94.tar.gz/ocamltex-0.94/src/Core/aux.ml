(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let strip =
  let isspace = String.contains "\n\r\t " in
  fun str ->
    let rec loop i j =
      if j > i then (
        let i' = i + if isspace str.[i] then 1 else 0
        and j' = j - if isspace str.[j] then 1 else 0 in
        if i = i' && j = j' then String.sub str i (j - i + 1)
        else loop i' j'
      ) else String.sub str i (j - i + 1)
    in loop 0 (String.length str - 1)

let rev_concat l = String.concat "-" (List.rev l)

let is_installed x = Printf.ksprintf Sys.command "which %s > /dev/null" x = 0
