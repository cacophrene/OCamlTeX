(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

let aux fmt id () = sprintf fmt (Core.AppPrefs.get id)

module type LANG = sig val get_name : unit -> string end

module Make = functor (Lang : LANG) ->
  struct
    let htbl = Hashtbl.create 7
    let register file =
      List.iter (function
        | `Assc ("Item", `Str x, `Str y) -> Hashtbl.add htbl x y 
        | _ -> Core.Print.failure 2 "Syntax error in file %S" file
      ) (Sexpr.from_file file)
    let get id = try Hashtbl.find htbl id with Not_found -> id
    let format id fmt = sprintf fmt (get id)
    let init () =
      let name = Lang.get_name () in
      let file = Filename.concat Core.App.Dir.languages name in
      try register file with 
      | Sys_error _ -> Core.Print.failure 4 "File %S not found" name
  end

module Msg =
  struct
    include Make(struct let get_name = aux "%s-msg.lang" "language" end)
    let get id fmt =
      try Scanf.format_from_string (Hashtbl.find htbl id) fmt with
      | Not_found -> Core.Print.warning fmt "Language ID %S not found" id
      | Scanf.Scan_failure _ -> Core.Print.warning fmt "ID %S does not match \
        %S" id (Obj.magic fmt) 
  end

include Make(struct let get_name = aux "%s.lang" "language" end)

let init () = init (); Msg.init ()
