(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type latex_argument = [ 
  | `Arg of string
  | `Opt of string
  | `Overlay of string
]

type latex_constraints = {
  require_mathmode : bool;
  require_preamble : bool;
  require_packages : string list;
  require_docclass : string list;
}

type latex_properties = {
  enclose_verbatim : bool;
  enclose_mathmode : bool;
}

type item = {
  item_kind : bool;
  item_name : string;
  item_args : latex_argument list;
  item_icon : GtkStock.id;
  item_cons : latex_constraints;
  item_prop : latex_properties;
}

type state = {
  complete : bool;                    (* Enable/disable autocompletion. *)
  mathmode : bool;                    (* Require mathmode.              *)
  mathmdon : bool;                    (* Enable/disable mathmode.       *)
  preamble : bool;                    (* Require preamble.              *)
  verbatim : bool;                    (* Enable/disable verbatim mode.  *)
  packages : string list;             (* List of required packages.     *)
  docclass : string list;             (* Document classes.              *)
  namespace : string list;            (* Complexe LaTeX item namespace. *)
  patterns : (string -> string) list; (* Pattern builder functions.     *)
}

module IconPattern =
  struct
    let var pat id =
      let buf = Buffer.create 16 in
      Buffer.add_substitute buf (function "id" -> id | _-> "?") pat;
      Buffer.contents buf

    let get opt =
      let rec loop = function
        | [] -> None 
        | ("icon_pattern", `Str pat) :: _ -> Some (var pat)
        | _ :: t -> loop t
      in loop opt
  end

module PAux =
  struct
    let rec may_bool ?(def = false) id opt =
      try match List.assoc id opt with 
        | `Bln x -> x 
        | _ -> def 
      with Not_found -> def

    let append x = function
      | [] -> [x]
      | l -> x :: l

    let get_args x =
      let rec loop bln = function
        | [] -> [[]]
        | `Flag "Overlay" :: t ->
          let arg = `Overlay (Lang.get "overlay") in
          List.map (append arg) (loop true t)
        | `Leaf ("Arg", `Str id, []) :: t -> 
          let arg = `Arg (Lang.get id) in 
          List.map (append arg) (loop true t) 
        | `Leaf ("Opt", `Str id, []) :: t -> 
          let opt = `Opt (Lang.get id) in
          let l1 = if bln then List.map (append opt) (loop true t) else []
          and l2 = loop false t in
          l1 @ l2
        | _ :: t -> Core.Print.warning (loop bln) "Unknown LaTeX argument" t
      in loop true x

    let rec get_icon id patterns = function
      | ("icon", `Str str) :: _ -> Symbols.add str
      | _ :: t -> get_icon id patterns t
      | [] -> match patterns with
        | [] -> `FILE
        | f :: _ -> Symbols.add (f id)

    let may_list x =
      let rec loop res = function
        | [] -> List.sort String.compare res
        | (y, `Str cls) :: t when x = y -> loop (cls :: res) t
        | (y, `Lst cls) :: t when x = y -> loop (concat res cls) t
        | _ :: t -> loop res t
      and concat res = function
        | [] -> res
        | `Str x :: t -> concat (x :: res) t
        | _ :: t -> concat res t
      in loop
  end

let init_state = { complete = true; mathmode = false; mathmdon = false;
  preamble = false; verbatim = false; packages = []; namespace = []; 
  patterns = []; docclass = [] }

let update id opt state = {
  complete = PAux.may_bool ~def:state.complete "auto_complete" opt;
  mathmode = PAux.may_bool ~def:state.mathmode "mathmode" opt;
  mathmdon = PAux.may_bool ~def:state.mathmdon "define_mathmode" opt;
  preamble = PAux.may_bool ~def:state.preamble "preamble" opt;
  verbatim = PAux.may_bool ~def:state.verbatim "verbatim" opt;
  docclass = PAux.may_list "doc_class" state.docclass opt;
  packages = PAux.may_list "usepackage" state.packages opt;
  namespace = id :: state.namespace;
  patterns = match IconPattern.get opt with 
    | Some x -> x :: state.patterns
    | _ -> state.patterns
 }

let rec parse_latex mstr tstr gstr sstr l =
  let rec loop acc state = function
    | [] -> acc
    (* Group. *)
    | `Node ("Group", `Str id, opt, contents) :: t ->
      let res = parse_group sstr gstr state id opt contents in
      loop (res @ acc) state t
    (* Included file. *)
    | `Leaf ("Include", `Str id, opt) :: t ->
      let contents = Sexpr.from_file (Filename.concat Core.App.Dir.latex id) in
      let res = parse_group sstr gstr state id opt contents in
      loop (res @ acc) state t
    (* LaTeX item with arguments. *)
    | `Node (str, `Str id, opt, args) :: t ->
      let cmd = build_item state mstr tstr str id opt args in
      loop (cmd @ acc) state t
    (* LaTeX item without arguments. *)
    | `Leaf (str, `Str id, opt) :: t ->
      let cmd = build_item state mstr tstr str id opt [] in
      loop (cmd @ acc) state t
    | _ :: t -> loop acc state t 
  and parse_group sstr gstr state id opt contents =
    let state' = update id opt state in
    let res = loop [] state' contents in
    let key = Core.Aux.rev_concat state'.namespace
    and tbl = Array.of_list (List.rev res) in
    if PAux.may_bool "symbols" opt then sstr key tbl;
    gstr key tbl;
    res
  and build_item state mstr tstr str id opt args =
    let item = {
      item_kind = (str = "Environment");
      item_name = id;
      item_args = [];
      item_icon = PAux.get_icon id state.patterns opt;
      item_cons = {
        require_mathmode = PAux.may_bool ~def:state.mathmode "mathmode" opt;
        require_preamble = PAux.may_bool ~def:state.preamble "preamble" opt;
        require_packages = PAux.may_list "usepackage" state.packages opt;
        require_docclass = PAux.may_list "doc_class" state.docclass opt };
      item_prop = {
        enclose_verbatim = PAux.may_bool ~def:state.verbatim "verbatim" opt;
        enclose_mathmode = PAux.may_bool ~def:state.mathmdon "define_mathmode" 
          opt }
    } in
    let items = match PAux.get_args args with
      | [] -> [item]
      | lst -> List.map (fun args -> { item with item_args = args }) lst in
    if state.complete then List.iter tstr items;
    List.iter mstr items;
    items
  in ignore (loop [] init_state l)

let from_config 
  ~main_storing:mstr 
  ~trie_storing:tstr 
  ~group_storing:gstr 
  ~symbol_storing:sstr =
    let l = try Sexpr.from_file Core.App.File.latex with 
      | _ -> Core.Print.failure 2 "Invalid LaTeX file %S" Core.App.File.latex
    in parse_latex mstr tstr gstr sstr l
