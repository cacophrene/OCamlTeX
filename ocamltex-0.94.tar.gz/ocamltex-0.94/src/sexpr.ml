(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type value = [
  | `Int of int
  | `Chr of char
  | `Bln of bool
  | `Flo of float 
  | `Str of string
  | `Lst of value list
]

type opt = (string * value) list

type t = [
  | `Flag of string
  | `Assc of string * value * value 
  | `Leaf of string * value * opt
  | `Node of string * value * opt * t list
]

let rec string_of_value = function
  | `Bln x -> string_of_bool x
  | `Int x -> string_of_int x
  | `Chr x -> String.make 1 x
  | `Flo x -> string_of_float x
  | `Str x -> "\"" ^ x ^ "\""
  | `Lst x -> let buf = Buffer.create 16 in
    Buffer.add_char buf '[';
    List.iter (fun x ->
      if Buffer.length buf > 0 then Buffer.add_char buf ' ';
      Buffer.add_string buf (string_of_value x)
    ) x;
    Buffer.add_char buf ']';
    Buffer.contents buf

let assoc_str str opt =
  try 
    match List.assoc str opt with
    | `Str x -> Some x
    | _ -> None
  with Not_found -> None

let assoc_bln str opt =
  try 
    match List.assoc str opt with
    | `Bln x -> Some x
    | _ -> None
  with Not_found -> None

let assoc_int str opt =
  try 
    match List.assoc str opt with
    | `Int x -> Some x
    | _ -> None
  with Not_found -> None

open Genlex

let tokenize = make_lexer ["("; ")"; "["; "]"; ":"; "~"; "="]

let rec sexpr f = parser
  | [< 'Kwd "("; x = f; 'Kwd ")"; t = sexpr f >] -> x :: t
  | [< >] -> []

let rec direc f = parser
  | [< 'Kwd "~"; x = f; t = direc f >] -> x :: t
  | [< >] -> []

let rec parse_dat = parser
  | [< 'Ident x; s >] -> 
    begin match s with parser
      | [< v = parse_val; opt = direc parse_opt; s >] ->
        begin match s with parser
          | [< 'Kwd "="; dat = parse_val >] -> `Assc (x, v, dat)
          | [< 'Kwd ":"; l = sexpr parse_dat >] -> `Node (x, v, opt, l)
          | [< >] -> `Leaf (x, v, opt)
        end
      | [< >] -> `Flag x
    end
  | [< >] -> invalid_arg "Identifier expected"

and parse_opt = parser
  | [< 'Ident str; 'Kwd ":"; value = parse_val >] -> (str, value)
  | [< >] -> invalid_arg "Identifier expected"

and parse_val = parser
  | [< 'Ident "true" >] -> `Bln true
  | [< 'Ident "false" >] -> `Bln false
  | [< 'Int x >] -> `Int x
  | [< 'Float x >] -> `Flo x
  | [< 'String x >] -> `Str x
  | [< 'Char x >] -> `Chr x
  | [< 'Kwd "["; t  = parse_list >] -> `Lst t

and parse_list = parser
  | [< 'Kwd "]" >] -> []
  | [< x = parse_val; t = parse_list >] -> x :: t
  | [< >] -> invalid_arg "Unterminated list"
  
let from_file file =
  let ich = open_in file in
  let res = sexpr parse_dat (tokenize (Stream.of_channel ich)) in
  close_in ich;
  res
