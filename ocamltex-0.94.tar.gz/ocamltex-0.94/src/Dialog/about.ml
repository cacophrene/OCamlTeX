(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let license = lazy (
  let ich = open_in Core.App.license in
  let len = in_channel_length ich in
  let buf = Buffer.create len in
  Buffer.add_channel buf ich len;
  close_in ich;
  Buffer.contents buf)

let authors =
  List.map (fun (name, mailto) ->
    Printf.sprintf "%s (<%s>)" name mailto
  ) Core.App.authors

let dialog = lazy (
  GWindow.about_dialog
    ~name:Core.App.name
    ~authors
    ~comments:(Lang.get "about-dialog-comments")
    ~copyright:Core.App.copyright
    ~license:(Lazy.force license)
    ~logo:Core.App.logo
    ~title:Core.App.title
    ~website:Core.App.website
    ~website_label:(Lang.get "ocamltex-on-sourceforge")
    ~parent:GUI.Main.window
    ~destroy_with_parent:true
    ~position:`CENTER_ON_PARENT ()
  )

let show =
  FunTable.add "about" (fun () ->
    let dialog = Lazy.force dialog in
    let _ = dialog#run () in
    dialog#misc#hide ()
  )
