(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let tab_label = 
  begin GMisc.label 
    ~text:(Lang.get "plugins") ()
  end #coerce

let vbox = GPack.vbox ~border_width:10 ~spacing:10 ()
let packing = vbox#pack ~expand:false
let container = vbox#coerce

let _ = GMisc.label
  ~xalign:0.
  ~markup:(Lang.format "plugin-list" "<b>%s</b>")
  ~packing ()

let hbox = Tools.hbox_with_indent ~packing:vbox#add ()

module Data =
  struct
    let cols = new GTree.column_list
    let icon = cols#add GtkStock.conv
    let name = cols#add Gobject.Data.caml
    let text = cols#add Gobject.Data.string
    let store = GTree.list_store cols
  end

module View =
  struct
    let icon = GTree.cell_renderer_pixbuf [`XPAD 10]
    let text = GTree.cell_renderer_text []
    let accel = GTree.cell_renderer_accel []
    let col1 =
      let vcol = GTree.view_column () in
      vcol#pack ~expand:false icon;
      vcol#add_attribute icon "stock_id" Data.icon;
      vcol#pack text;
      vcol#add_attribute text "markup" Data.text;
      vcol
  end

let vbox = GPack.vbox ~spacing:10 ~packing:hbox#add ()

let scroll = GBin.scrolled_window
  ~hpolicy:`ALWAYS
  ~vpolicy:`ALWAYS
  ~shadow_type:`ETCHED_IN
  ~packing:vbox#add ()

let plugin_list =
  let view = GTree.view
    ~model:Data.store
    ~headers_visible:false 
    ~rules_hint:true
    ~packing:scroll#add () in
  view#append_column View.col1;
  view

let bbox = GPack.button_box `HORIZONTAL
  ~layout:`EDGE
  ~spacing:10
  ~packing:(vbox#pack ~expand:false) ()

let get_plugin () =
  match plugin_list#selection#get_selected_rows with
  | [] -> None
  | path :: _ -> let row = Data.store#get_iter path in
    Some (Data.store#get ~row ~column:Data.name)

let make_button ~id ~stock f = 
  let btn = GButton.button
    ~label:(Lang.get id)
    ~use_mnemonic:true
    ~packing:bbox#add () in
  btn#set_image (GMisc.image ~stock ())#coerce;
  btn#connect#clicked (fun () -> Gaux.may f (get_plugin ()));
  btn

let about = make_button 
  ~id:"plugin-about" 
  ~stock:`ABOUT Core.Plugin.Action.show_about
let configure = make_button 
  ~id:"plugin-configure" 
  ~stock:`PREFERENCES Core.Plugin.Action.show_configure

let set_button_state () =
  match get_plugin () with
  | Some t ->
    configure#misc#set_sensitive (FunTable.mem (Core.Plugin.ID.configure t));
    about#misc#set_sensitive (FunTable.mem (Core.Plugin.ID.about t))
  | _ -> ()

let _ = plugin_list#selection#connect#changed set_button_state

let import () =
  Data.store#clear ();
  Array.iteri (fun i name ->
    let row = Data.store#append () in
    Data.store#set ~row ~column:Data.name name;
    Data.store#set ~row ~column:Data.icon `OPEN;
    Data.store#set ~row ~column:Data.text 
      (Printf.sprintf "<b>%s</b>\n%s"
        (Lang.get (Core.Plugin.ID.title name))
        (Lang.get (Core.Plugin.ID.description name))
      )
  ) (Array.of_list (Core.Plugin.get_list ()))

let reload =
  let btn = GButton.button
    ~label:(Lang.get "force-reload")
    ~use_mnemonic:true
    ~packing:bbox#add () in
  btn#set_image (GMisc.image ~stock:`REFRESH ())#coerce;
  btn#connect#clicked (fun () -> Core.Plugin.init (); import ());
  btn

let export () = ()
