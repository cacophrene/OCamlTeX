(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

type item = [
  | `GtkMenu            of GMenu.menu
  | `Browser            of Widgets.texdoc
  | `GtkToolbar         of GButton.toolbar
  | `GtkMenubar         of GMenu.menu_shell
  | `GtkToolButton      of GButton.tool_button
  | `GtkImageMenuItem   of GMenu.image_menu_item
  | `GtkCheckMenuItem   of GMenu.check_menu_item
  | `GtkMenuToolButton  of GButton.menu_tool_button
]

type 'a bag = {
  packing : 'a -> unit;
  pattern : (string -> GtkStock.id) list;
  parent  : GWindow.window;
  store   : string -> item -> unit;
  accels  : Gtk.accel_group
}

let substitute pat id =
  let buf = Buffer.create 16 in
  Buffer.add_substitute buf (function "id" -> id | _-> "?") pat;
  `STOCK (Buffer.contents buf)

let may_concat bag opt =
  match Sexpr.assoc_str "icon_pattern" opt with
  | Some pat -> substitute pat :: bag.pattern
  | _ -> bag.pattern

let get_state opt = Gaux.default false ~opt:(Sexpr.assoc_bln "init" opt)

let set_stock id bag opt packing =
  let get_image stock = 
    ignore (GMisc.image 
      ~stock ~icon_size:`MENU 
      ~packing ()) in
  match Sexpr.assoc_str "icon" opt with
  | Some id -> get_image (`STOCK id)
  | _ -> match bag.pattern with
    | f :: _ -> get_image (f id)
    | _ -> ()

module Feed =
  struct
    let plugin_menu item =
      List.iter (fun name ->
        let id = Core.Plugin.ID.main name in
        let item = GMenu.menu_item
          ~label:(Lang.get (Core.Plugin.ID.title name))
          ~packing:item#add () in
        ignore (item#connect#activate (FunTable.run id));
      ) (Core.Plugin.get_list ())

    let template_menu =
      let load_template = FunTable.run_with_arg "load-template" in
      fun item ->
        List.iter (fun file ->
          let item = GMenu.menu_item ~packing:item#add () in
          let name = String.capitalize (Filename.chop_extension file) in
          ignore (GMisc.label
            ~markup:(sprintf "<b>%s</b> - %s" name file)
            ~packing:item#add ());
         ignore (item#connect#activate (load_template file))
        ) (Core.Templates.get_list ())

    let latex_menu bag id =
      Array.iter (fun t ->
        let id = LaTeX.Main.get_name t in
        let item = GMenu.image_menu_item ~packing:bag.packing () in
        ignore (GMisc.label 
          ~xalign:0.
          ~markup:(Lang.format id "%s - %s" (LaTeX.Main.to_markup t))
          ~packing:item#add ());
        item#connect#activate (FunTable.run_with_arg "latex-insert" t);
        bag.store id (`GtkImageMenuItem item)
      ) (LaTeX.Main.get_group id)
  end

module Accel =
  struct
    let format =
      let pat = Str.regexp "+" in
      fun str ->
        let l' = List.map (function
          | "Ctrl"  -> "<control>"
          | "Shift" -> "<shift>"
          | str     -> str
        ) (Str.split pat str) in
        String.concat "" l'

    let may opt = Gaux.may_map format (Sexpr.assoc_str "accel" opt)

    let add =
      let flags = [`VISIBLE] in
      fun bag (item : #GMenu.menu_item_skel) opt ->
        match may opt with
        | Some str -> let key, modi = GtkData.AccelGroup.parse str in
          item#add_accelerator ~group:bag.accels ~modi ~flags key
        | _ -> ()
  end

let rec bar bag = function
  | `Node ("Toolbar", `Str id, opt, contents) ->
    let item = GButton.toolbar
      ~orientation:`HORIZONTAL
      ~style:`ICONS
      ~packing:(GBin.handle_box ~packing:bag.packing ())#add () in
    bag.store id (`GtkToolbar item);
    let bag' = {bag with packing = item#insert; pattern = may_concat bag opt} in 
    List.iter (toolitem bag') contents
  | `Node ("Menubar", `Str id, opt, contents) ->
    let item = GMenu.menu_bar ~packing:bag.packing () in
    bag.store id (`GtkMenubar item);
    let bag' = {bag with packing = item#add; pattern = may_concat bag opt} in
    List.iter (menu bag') contents;
  | _ -> Core.Print.warning () "Unknown toplevel item"

and menu bag = function
  | `Flag "Templates" ->
    let label = GMenu.menu_item 
      ~label:(Lang.get "templates") 
      ~use_mnemonic:true
      ~packing:bag.packing ()
    in Feed.template_menu (GMenu.menu ~packing:label#set_submenu ())
  | `Flag "Plugins" ->
    let label = GMenu.menu_item 
      ~label:(Lang.get "plugins") 
      ~use_mnemonic:true
      ~packing:bag.packing ()
    in Feed.plugin_menu (GMenu.menu ~packing:label#set_submenu ())
  | `Node ("Menu", `Str id, opt, contents) ->
    let label = GMenu.menu_item 
      ~label:(Lang.get id) 
      ~use_mnemonic:true 
      ~packing:bag.packing () in
    let item = GMenu.menu ~packing:label#set_submenu () in
    bag.store id (`GtkMenu item);
    let bag' = {bag with packing = item#add; pattern = may_concat bag opt} in
    List.iter (menuitem bag') contents
  | _ -> Core.Print.warning () "Unknown menubar item"

and toolitem bag = function
  | `Flag "Separator" -> 
    ignore (GButton.separator_tool_item ~packing:bag.packing ())
  | `Leaf ("Button", `Str id, opt) ->
    let stock = match Sexpr.assoc_str "icon" opt with
      | Some id -> Some (`STOCK id) 
      | None -> match bag.pattern with [] -> None | f :: _ -> Some (f id) in 
    let item = GButton.tool_button ?stock ~packing:bag.packing () in
    item#misc#set_tooltip_text (Lang.get id);
    item#connect#clicked ~callback:(FunTable.run id);
    bag.store id (`GtkToolButton item)
  | `Leaf ("LaTeX", `Str id, opt) ->
    (* LaTeX items are inserted as tool buttons. *)
    if LaTeX.Main.mem_item id then begin
      let t = LaTeX.Main.get_item id in
      let stock = match Sexpr.assoc_str "icon" opt with
        | Some str -> `STOCK str
        | _ -> LaTeX.Main.get_icon t in
      let item = GButton.tool_button ~stock ~packing:bag.packing () in
      item#misc#set_tooltip_markup (LaTeX.Main.to_markup t);
      item#connect#clicked ~callback:(FunTable.run_with_arg "latex-insert" t);
      bag.store id (`GtkToolButton item)
    (* LaTeX groups are inserted as GtkMenuToolButton. *)
    end else begin
      let menu = GMenu.menu () in
      let tbl = LaTeX.Main.get_group id in
      let cmd = ref tbl.(0) in
      let btn = GButton.menu_tool_button ~menu ~packing:bag.packing () in
      let ins = FunTable.run_with_arg "latex-insert" in
      btn#connect#clicked (fun () -> ins !cmd ());
      let lbl = GMisc.label ~xalign:0.
        ~markup:(LaTeX.Main.to_markup tbl.(0)) 
        ~packing:btn#set_label_widget () in
      Array.iter (fun t ->
        let item = GMenu.menu_item ~packing:menu#append () in
        ignore (GMisc.label 
          ~xalign:0. 
          ~markup:(LaTeX.Main.to_markup t) 
          ~packing:item#add ());
        ignore (item#connect#activate (fun () ->
          cmd := t; ins t ();
          lbl#set_label (LaTeX.Main.to_markup t)))
      ) tbl
    end
  | `Leaf ("Palette", `Str id, _) ->
    let group = LaTeX.Main.get_group id in
    let n = Array.length group in
    if n > 0 then begin
      let wnd = GWindow.window
        ~kind:`POPUP
        ~modal:true
        ~type_hint:`DOCK 
        ~position:`MOUSE ~width:220 ~height:150 () in
      let scroll = GBin.scrolled_window 
        ~hpolicy:`AUTOMATIC 
        ~vpolicy:`ALWAYS
        ~packing:wnd#add () in
      let hide _ = wnd#misc#hide (); false in 
      bag.parent#event#connect#expose hide;
      bag.parent#event#connect#window_state hide;
      bag.parent#event#connect#focus_out hide;
      wnd#event#connect#key_release (fun t ->
        if GdkEvent.Key.keyval t = 65307 then (wnd#misc#hide (); true) 
        else false);
      let table = GPack.table 
        ~rows:(n / 7)
        ~columns:7
        ~packing:scroll#add_with_viewport () in
      Array.iteri (fun i t ->
        let left = i mod 7 and top = i / 7 in
        let btn = GButton.button ~packing:(table#attach ~left ~top) () in
        btn#misc#set_tooltip_markup (LaTeX.Main.to_markup t);
        btn#misc#set_can_default false;
        btn#connect#clicked (FunTable.run_with_arg "latex-insert" t);
        btn#connect#clicked wnd#misc#hide;
        let stock = LaTeX.Main.get_icon t in
        ignore (GMisc.image ~stock ~icon_size:`MENU ~packing:btn#set_image ())
      ) group;
      let item = GButton.tool_button 
        ~stock:(LaTeX.Main.get_icon group.(0)) 
        ~packing:bag.packing () in
      item#misc#set_tooltip_text (Lang.get id);
      item#connect#clicked wnd#show;
      bag.store id (`GtkToolButton item)
    end
  | `Flag "Plugins" ->
    let menu = GMenu.menu () in
    Feed.plugin_menu menu;
    let item = GButton.menu_tool_button 
      ~menu 
      ~stock:`PROPERTIES 
      ~packing:bag.packing
      ~use_underline:true () in
    item#connect#clicked (FunTable.run_with_arg "preferences" (Some 4));
    bag.store "Plugins" (`GtkMenuToolButton item)
  | `Flag "Browser" ->
    let item = new Widgets.texdoc
      ~packing:(GButton.tool_item ~packing:bag.packing ())#add
    in bag.store "browser" (`Browser item)
  | _ -> Core.Print.warning () "Unknown toolitem"

and menuitem bag = function
  | `Flag "Plugins" as x -> menu bag x
  | `Flag "Templates" as x -> menu bag x
  | `Node ("Menu", `Str _, _, _) as x -> menu bag x
  | `Leaf ("LaTeX", `Str id, _) -> Feed.latex_menu bag id
  | `Flag "Tearoff" -> ignore (GMenu.tearoff_item ~packing:bag.packing ())   
  | `Flag "Separator" -> ignore (GMenu.separator_item ~packing:bag.packing ())
  | `Leaf ("Image", `Str id, opt) ->
    let item = GMenu.image_menu_item
      ~label:(Lang.get id)
      ~packing:bag.packing () in
    set_stock id bag opt item#set_image;
    item#connect#activate ~callback:(FunTable.run id);
    Accel.add bag item opt;
    bag.store id (`GtkImageMenuItem item)
  | `Leaf ("Check", `Str id, opt) ->
    let item = GMenu.check_menu_item
      ~label:(Lang.get id)
      ~packing:bag.packing () in
    item#connect#toggled ~callback:(FunTable.run id);
    item#set_active (get_state opt);
    Accel.add bag item opt;
    bag.store id (`GtkCheckMenuItem item)
  | _ -> Core.Print.warning () "Unknown menuitem"

let from_config ~accels ~packing ~storing ~parent =
  let bag = {packing = packing; pattern = []; parent = parent; 
    store = storing; accels = accels} in
  try
    let file = Filename.concat Core.App.Dir.gui (Core.AppPrefs.get "gui-file") in
    List.iter (bar bag) (Sexpr.from_file file)
  with exn -> Core.Print.failure 2 "Bad GUI file"
