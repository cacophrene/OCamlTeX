(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let get_env () = 
  let tbl = [|
    Core.AppPrefs.format "ps-viewer" "TEXDOCVIEW_ps=%s %%s";
    Core.AppPrefs.format "dvi-viewer" "TEXDOCVIEW_dvi=%s %%s";
    Core.AppPrefs.format "pdf-viewer" "TEXDOCVIEW_pdf=%s %%s";
    Core.AppPrefs.format "html-viewer" "TEXDOCVIEW_html=%s %%s";
    Core.AppPrefs.format "text-viewer" "TEXDOCVIEW_text=%s %%s";
  |] in Array.append (Unix.environment ()) tbl

let run doc =
  Unix.create_process_env "texdoc" [|"texdoc"; doc|] (get_env ())
    Unix.stdin Unix.stdout Unix.stderr

class texdoc ~packing =
  object (self)
    val hbox = GPack.hbox ~spacing:5 ~packing ()
    val stock = GMisc.image ~stock:`HELP ()
    val entry = GEdit.entry ()

    initializer
      entry#event#connect#key_release self#may_show_doc;
      List.iter hbox#add [stock#coerce; entry#coerce]
 
   method private may_show_doc t =
      begin match GdkEvent.Key.keyval t with
        | 65293 | 65421 -> ignore (run entry#text)
        | _ -> ()
      end;
      false
    method entry = entry
  end
