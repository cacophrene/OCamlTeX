(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type pos = {lnum: int; cnum: int}
type env = {sb: int; se: int}

let ini = {sb = 0; se = 0}

type token = [
  | `MathOn  of pos       (* Début du mode mathémtique ($ ou \[).   *)
  | `MathOff of pos       (* Fin du mode mathémtique ($ ou \]).     *)
  | `Begin   of pos       (* Début d'un environnement mathématique. *)
  | `End     of pos       (* Fin d'un environnement mathématique.   *)
  | `Data    of string    (* Nom de l'environnement mathématique.   *)
]

let latex_begin = [|'b'; 'e'; 'g'; 'i'; 'n'; '{'|]
let latex_end = [|'e'; 'n'; 'd'; '{'|]

let rec main flag pos s =
  let pos' = {pos with cnum = pos.cnum + 1} in
  match s with parser
  | [< ''\n' >] -> main flag {lnum = pos.lnum + 1; cnum = 0} s
  | [< ''\192'..'\223'; '_ >] -> main flag pos' s
  | [< ''\224'..'\239'; '_; '_ >] -> main flag pos' s
  | [< ''\240'..'\247'; '_; '_; '_ >] -> main flag pos' s
  | [< >] ->
    let f = match flag with
      | `Math     -> display_math
      | `Buff     -> get_ident (Buffer.create 7)
      | `Loop env -> tokenize env
      | `Data buf -> get_ident buf
    in f pos' s

and tokenize env pos = parser
  | [< ''\\'; s >] ->
    begin match s with parser
      | [< ''['; s >] -> let pos' = {pos with cnum = pos.cnum + 1} in
        `MathOn {pos with cnum = pos.cnum - 1} :: main `Math pos' s
      | [< >] -> main (`Loop ini) pos s
    end
  | [< ''$'; s >] -> `MathOn {pos with cnum = pos.cnum - 1} :: main `Math pos s
  | [< 'chr; s >] ->
    if env.se = 0 && Char.compare chr latex_begin.(env.sb) = 0 then (
      if env.sb < 5 then main (`Loop {sb = env.sb + 1; se = 0}) pos s 
      else `Begin {pos with cnum = pos.cnum - 7} :: main `Buff pos s
    ) else if env.sb = 0 && Char.compare chr latex_end.(env.se) = 0 then (
      if env.se < 3 then main (`Loop {sb = 0; se = env.se + 1}) pos s 
      else `End {pos with cnum = pos.cnum + 1} :: main `Buff pos s
    ) else main (`Loop ini) pos s
  | [< >] -> []

and get_ident buf pos s =
  let opt = match s with parser
    | [< ''a'..'z' as chr >] -> Some (Some chr)
    | [< ''A'..'Z' as chr >] -> Some (Some chr)
    | [< ''*' >] -> Some (Some '*')
    | [< ''}' >] -> Some None
    | [< >] -> None in
  match opt with
  | Some (Some chr) -> Buffer.add_char buf chr; main (`Data buf) pos s
  | Some _ -> `Data (Buffer.contents buf) :: main (`Loop ini) pos s
  | _ -> main (`Loop ini) pos s

and display_math pos = parser
  | [< ''$'; s >] -> `MathOff pos :: main (`Loop ini) pos s
  | [< ''\\'; s >] ->
    begin match s with parser 
      | [< '']'; s >] -> let pos' = {pos with cnum = pos.cnum + 1} in
        `MathOff pos' :: main (`Loop ini) pos' s
      | [< >] -> main `Math pos s
    end
  | [< '_; s >] -> main `Math pos s
  | [< >] -> []

let of_string n str =
  main (`Loop ini) {lnum = n; cnum = 0} (Stream.of_string str)

let extract (buf : GSourceView2.source_buffer) n =
  let here = buf#get_iter `INSERT in
  let m = here#line in
  let start = here#backward_lines n in
  let stop = here#forward_lines n in
  (max 0 (m - n), buf#get_text ~start ~stop ())

let get_valid_token buf tokens =
  let here = buf#get_iter `INSERT in
  let lnum = here#line and cnum = here#line_offset in
  let rec loop mem = function
    | `MathOn p1 :: `MathOff p2 :: t -> 
      if (p1.lnum < lnum || p1.lnum = lnum && p1.cnum <= cnum) && 
         (p2.lnum > lnum || p2.lnum = lnum && p2.cnum >= cnum) && mem = None
      then Some (p1, p2) else loop mem t
    | `Begin p1 :: `Data s1 :: t ->
      begin try
        let tex = Printf.ksprintf LaTeX.Main.get_item "\\%s" s1 in
        if LaTeX.Main.enclose_mathmode tex && (p1.lnum < lnum || p1.lnum = lnum 
        && p1.cnum <= cnum) && mem = None then loop (Some (p1, s1)) t 
        else loop mem t
      with _ -> loop mem t end
    | `End p2 :: `Data s2 :: t ->
      begin match mem with
      | None -> loop mem t
      | Some (p1, s1) -> let p2 = {p2 with cnum = p2.cnum + String.length s2} in
        if String.compare s1 s2 = 0 then ( 
          if (p2.lnum > lnum || p2.lnum = lnum && p2.cnum >= cnum) 
          then Some (p1, p2) else loop None t
        ) else loop mem t
      end
    | _ :: t -> loop mem t
    | _ -> None
  in loop None tokens

let get_formula (buf : GSourceView2.source_buffer) x y =
  let start = buf#get_iter_at_char ~line:x.lnum x.cnum
  and stop = buf#get_iter_at_char ~line:y.lnum y.cnum in
  buf#get_text ~start ~stop ()

let run ?(size = 8) (buf : GSourceView2.source_buffer) =
  let num, str = extract buf size in
  match get_valid_token buf (of_string num str) with
  | Some (x, y) -> Some (get_formula buf x y)
  | None -> None
