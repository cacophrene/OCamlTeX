(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

(* TODO: 
 * - Check that dvipng is installed on the system. 
 * - Add some options to control the output.
 *)

open Printf

let file = "ocamltex-formula"

let preamble = "\\documentclass{article}\n\\usepackage[utf8]{inputenc}\n\
  \\usepackage{amsmath}\\usepackage{amsfonts}\\usepackage{amssymb}\n\
  \\pagestyle{empty}\n"

let from_string ~latex =
  if Core.Aux.is_installed "dvipng" then (
    let och = ksprintf open_out "%s.tex" file in
    fprintf och "%s\\begin{document}\n%s\n\\end{document}" preamble latex;
    close_out och;
    ksprintf Sys.command "latex -interaction=nonstopmode %s.tex \
      > /dev/null" file;
    ksprintf Sys.command "dvipng -bg Transparent -D 150 -T tight -q -o %s.png \
      %s.dvi > /dev/null" file file;
    try Some (GdkPixbuf.from_file (file ^ ".png")) with _ -> None
  ) else None

let clean_up () = ignore (ksprintf Sys.command "rm %s.*" file)
