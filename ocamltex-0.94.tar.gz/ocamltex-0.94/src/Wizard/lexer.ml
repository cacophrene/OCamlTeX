(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

(* État de l'analyseur lexical. *)
type state = {
  line : int;
  math : bool
}

let rec tokenize state = parser
  | [< 'chr when String.contains "_^" chr ; s >] ->
    `MathChar (chr, state.line) :: tokenize state s
  | [< ''\\'; s >] ->
    begin match s with parser
      | [< ''[' >] -> `MathMode true :: tokenize {state with math = true} s
      | [< '']' >] -> `MathMode false :: tokenize {state with math = false} s
      | [< (id, (state', args)) = get_command state; s >] -> 
        let token = `Token { Types.line = state.line; id = id; args = args } in
        token :: tokenize state' s
      | [< 'chr when String.contains "\\_^$" chr >] -> tokenize state s
    end
  | [< ''$'; s >] -> let math = not state.math in 
    `MathMode math :: tokenize {state with math = math} s
  | [< ''%'; s >] -> skip_comment s;
    tokenize {state with line = state.line + 1} s
  | [< ''\n'; s >] -> tokenize {state with line = state.line + 1} s
  | [< '_; s >] -> tokenize state s
  | [< >] -> []

and get_command state s =
  let id = get_id s in
  let rec loop state = parser
    | [< ''\n' >] -> loop {state with line = state.line + 1} s
    | [< ''[' >] -> let x = `Opt (until_rbrack s) in 
      let state, t = loop state s in state, x :: t
    | [< ''{' >] -> let x = `Arg (until_rbrace s) in 
      let state, t = loop state s in state, x :: t
    | [< ''<' >] -> let x = `Spe (until_geq s) in 
      let state, t = loop state s in state, x :: t
    | [< >] -> state, []
  in (id, loop state s)

and get_id s =
  let buf = Buffer.create 16 in 
  let rec loop = parser
    | [< ''a'..'z' as chr >] -> Buffer.add_char buf chr; loop s
    | [< ''A'..'Z' as chr >] -> Buffer.add_char buf chr; loop s
    | [< >] -> Buffer.contents buf
  in loop s

and until_rbrack s =
  let buf = Buffer.create 16 in 
  let rec loop = function
    | 0 -> (fun _ -> Buffer.contents buf)
    | n -> (parser
      | [< ''[' >] -> Buffer.add_char buf '['; loop (n + 1) s
      | [< '']' >] -> if n > 1 then Buffer.add_char buf ']'; loop (n - 1) s
      | [< 'chr >] -> Buffer.add_char buf chr; loop n s
      | [< >] -> raise Exit)
  in loop 1 s

and until_rbrace s =
  let buf = Buffer.create 16 in 
  let rec loop = function
    | 0 -> (fun _ -> Buffer.contents buf)
    | n -> (parser
      | [< ''{' >] -> Buffer.add_char buf '{'; loop (n + 1) s
      | [< ''}' >] -> if n > 1 then Buffer.add_char buf '}'; loop (n - 1) s
      | [< 'chr >] -> Buffer.add_char buf chr; loop n s
      | [< >] -> raise Exit)
  in loop 1 s

and until_geq s =
  let buf = Buffer.create 16 in 
  let rec loop = function
    | 0 -> (fun _ -> Buffer.contents buf)
    | n -> (parser
      | [< ''<' >] -> Buffer.add_char buf '<'; loop (n + 1) s
      | [< ''>' >] -> if n > 1 then Buffer.add_char buf '>'; loop (n - 1) s
      | [< 'chr >] -> Buffer.add_char buf chr; loop n s
      | [< >] -> raise Exit)
  in loop 1 s

and skip_comment = parser
  | [< ''\n' >] -> ()
  | [< '_; s >] -> skip_comment s

let run s = tokenize { line = 1; math = false} s


(* ---------- *)

let from_string str = 
  try run (Stream.of_string str) with _ -> []

let from_file file =
  let aux () =
    let ich = open_in file in
    let lex = run (Stream.of_channel ich) in
    close_in ich;
    lex
  in try aux () with _ -> []
