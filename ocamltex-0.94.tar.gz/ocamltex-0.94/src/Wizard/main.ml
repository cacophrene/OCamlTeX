(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let init () = ()

let validate (buf : GSourceView2.source_buffer) =
  let log = Parser.check (Lexer.from_string (buf#get_text ())) in
  GUI.BottomPane.Validation.clear ();
  match log with
  | [] -> ()
  | _ ->
    List.iter (fun (stock, str) ->
      let str' = Printf.sprintf "<tt>%s</tt>" str in
      GUI.BottomPane.Validation.append stock str') log;
    GUI.BottomPane.Validation.display ()

(* test
let _ = FunTable.add "validate" validate*)


(*
type toc =
  | Part of int * string
  | File of int * string
  | Chapter of int * string
  | Section of int * string
  | Subsection of int * string

let get_table_of_contents ?(full_title = false) l =
  let aux x = match x.Types.args with
    | [`Arg str] -> str
    | [`Opt s1; `Arg s2] -> if full_title then s2 else s1
    | _ -> invalid_arg "get_table_of_contents" in
  let rec loop = function
    | [] -> []
    | { Types.id = "part" } as x :: t -> Part (x.Types.line, aux x) :: loop t
    | { Types.id = "include" } as x :: t -> File (x.Types.line, aux x) :: loop t
    | { Types.id = "chapter" } as x :: t -> Chapter (x.Types.line, aux x) :: loop t
    | { Types.id = "section" } as x :: t -> Section (x.Types.line, aux x) :: loop t
    | { Types.id = "subsection" } as x :: t -> Subsection (x.Types.line, aux x) :: loop t
    | _ :: t -> loop t
  in loop l*)
