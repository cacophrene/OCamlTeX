(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

module Aux =
  struct
    let split_csv = Str.split (Str.regexp "[\n\t\r ]*,[\n\t\r ]*")
  end

module SSet = Set.Make(String)

(* LaTeX packages. *)
let get_packages t =
  let rec loop set = function
    | []
    | `Token { Types.id = "begin"; args = [`Arg "document"] } :: _ -> set
    | `Token { Types.id = "usepackage"; 
        args = [`Arg str] } :: t
    | `Token { Types.id = "usepackage"; 
        args = [`Opt _; `Arg str] } :: t -> loop (SSet.add str set) t
    | _ :: t -> loop set t
  in loop SSet.empty t

(* LaTeX cross-references. *)
let get_crossref t =
  List.fold_left (fun set elt ->
    match elt with
    | `Token { Types.id = "label"; args = [`Arg str] } -> SSet.add str set
    | _ -> set
  ) SSet.empty t

(* LaTeX included files. *)
let get_included_files t =
  List.fold_left (fun set elt ->
    match elt with
    | `Token { Types.id = "include";
        args = [`Arg str] } -> SSet.add (str ^ ".tex") set
    | _ -> set
  ) SSet.empty t

(* LaTeX input encoding. *)
let rec get_encoding = function
  | [] -> None
  | `Token { Types.id = "usepackage"; 
      args = [`Opt str; `Arg "inputenc"] } :: _ -> Some str
  | _ :: t -> get_encoding t

(* LaTeX languages (loaded with Babel package). *)
let rec get_languages = function
  | [] -> []
  | `Token { Types.id = "usepackage"; 
      args = [`Opt str; `Arg "babel"] } :: _ -> Aux.split_csv str
  | _ :: t -> get_languages t

(* Document class. *)
let rec get_document_class = function
  | [] -> None
  | `Token { Types.id = "documentclass"; args = [`Arg cls] } :: _
  | `Token { Types.id = "documentclass"; args = [`Opt _; `Arg cls] } :: _ ->
    Some cls
  | _ :: t -> get_document_class t

(* Document class options. *)
let rec get_document_options = function
  | [] -> []
  | `Token { Types.id = "documentclass"; 
      args = [`Opt str; `Arg _] } :: _ -> Aux.split_csv str
  | _ :: t -> get_document_options t

(* Look for loaded package. *)
let has_package id = 
  List.exists (function
    | `Token { Types.id = "usepackage"; args = [`Arg x] }
    | `Token { Types.id = "usepackage"; args = [`Opt _; `Arg x] } -> x = id
    | _ -> false
  )

(* ----- LaTeX syntax analysis tool ----- *)

type state = {
  preamble : bool;
  mathmode : bool;
  verbatim : bool;
  math_env : string;
  verb_env : string;
}

let init = {
  preamble = true; 
  mathmode = false; 
  verbatim = false;
  math_env = "";
  verb_env = "" }

module Check =
  struct
    module LazyFun =
      struct
        let get id f = lazy (sprintf (Lang.Msg.get id f))
        let mathmode = get "mathmode-required" "%s%d"
        let usepackg = get "package-needed" "%s%d%s"
        let preamble = get "preamble-only" "%s%d"
        let pictures = get "missing-picture" "%s%d"
        let docclass = get "document-class" "%s%d%s"
        let mathchar = get "math-character" "%c%d"
      end

    let of_list = function
      | [] -> ""
      | x :: t -> let buf = Buffer.create 16 in
        bprintf buf "<b>%s</b>" x;
        List.iter (bprintf buf ", <b>%s</b>") t;
        Buffer.contents buf

    let usepackg set state t n acc =
      match LaTeX.Main.require_packages t with
      | lst when not (List.for_all (fun pkg -> SSet.mem pkg set) lst) ->
        let str = of_list lst in
        let msg = Lazy.force LazyFun.usepackg (LaTeX.Main.to_markup t) n str in
        (`DIALOG_WARNING, msg) :: acc
      | _ -> acc

    let mathmode state t line acc =
      if not state.mathmode && LaTeX.Main.require_mathmode t then
        let msg = Lazy.force LazyFun.mathmode (LaTeX.Main.to_markup t) line in
        (`DIALOG_WARNING, msg) :: acc
      else acc

    let preamble state t line acc =
      if not state.preamble && LaTeX.Main.require_preamble t then
        let msg = Lazy.force LazyFun.preamble (LaTeX.Main.to_markup t) line in
        (`DIALOG_WARNING, msg) :: acc
      else acc

    let docclass opt state t line acc =
      let cls = match opt with None -> "" | Some cls -> cls in
      match LaTeX.Main.require_docclass t with
      | [] -> acc
      | lst when List.mem cls lst -> acc
      | lst -> let markup = LaTeX.Main.to_markup t in
        let msg = Lazy.force LazyFun.docclass markup line (of_list lst) in
        (`DIALOG_WARNING, msg) :: acc

    let run pkgSet cls state t line = 
      List.fold_right (function
        | `CheckMathMode -> mathmode state t line
        | `CheckPreamble -> preamble state t line
        | `CheckDocClass -> docclass cls state t line
        | `CheckUsePackg -> usepackg pkgSet state t line
        | _ -> (fun x -> x)
      ) [`CheckUsePackg; `CheckMathMode; `CheckPreamble; `CheckDocClass]
  end

let get_latex id1 id2 args =
  let buf = Buffer.create 16 in
  bprintf buf "\\%s" (if id1 = "begin" then id2 else id1);
  List.iter (function
    | `Arg _ -> Buffer.add_string buf "{}"
    | `Opt _ -> Buffer.add_string buf "[]"
    | `Spe _ -> Buffer.add_string buf "<>"
  ) args;
  Buffer.contents buf

let check lex =
  let pkgSet = get_packages lex and cls = get_document_class lex in
  let rec loop state res = function
    | [] -> List.rev res
    (* End of environment. *)
    | `Token { Types.id = "end"; args = `Arg str :: _ } :: l -> 
      let state' = 
        if state.math_env = str then 
          {state with math_env = ""; mathmode = false} 
        else if state.verb_env = str then
          {state with verb_env = ""; verbatim = false} 
        else state 
      in loop state' res l
    (* Verbatim mode. *)
    | _ :: t when state.verbatim -> loop state res t
    | `MathChar (chr, line) :: t ->
      let res' = 
        if not state.mathmode then
          (`DIALOG_WARNING, Lazy.force Check.LazyFun.mathchar chr line) :: res
        else res
      in loop state res' t
    (* Lexical-level math mode (with $...$ and \[...\] notations). *)
    | `MathMode x :: l -> 
      loop {state with mathmode = x} res l 
    (* \begin{document} ends preamble. *)
    | `Token { Types.id = "begin"; args = [`Arg "document"] } :: l ->
      loop {state with preamble = false} res l
    (* Environements can begins math or verbatim modes. *)
    | `Token { Types.id = "begin"; line = n; args = `Arg id :: x } :: l ->
      let item = get_latex "begin" id x in
      if LaTeX.Main.mem_item item then (
        let t = LaTeX.Main.get_item item in
        let state' = 
          if LaTeX.Main.enclose_mathmode t then 
            { state with math_env = id; mathmode = true } 
          else if LaTeX.Main.enclose_verbatim t then
            { state with verb_env = id; verbatim = true } 
          else state
        in loop state' (Check.run pkgSet cls state t n res) l
      ) else loop state res l
    (* Pictures *)
    | `Token ({ Types.id = "includegraphics"; 
        line = n; args = [`Arg file] } as tk) :: l
    | `Token ({ Types.id = "includegraphics"; 
        line = n; args = [`Opt _; `Arg file] } as tk) :: l ->
      let item = get_latex "includegraphics" "" tk.Types.args in
      if LaTeX.Main.mem_item item then (
        let t = LaTeX.Main.get_item item in
        let res = if Sys.file_exists file then res 
          else (`DIALOG_ERROR, Lazy.force Check.LazyFun.pictures file n) :: res
        in loop state (Check.run pkgSet cls state t n res) l
      ) else loop state res l
    (* LaTeX commands. *)
    | `Token { Types.id = id; line = n; args = args } :: l ->
      let item = get_latex id "" args in
      if LaTeX.Main.mem_item item then (
        let t = LaTeX.Main.get_item item in
        loop state (Check.run pkgSet cls state t n res) l
      ) else loop state res l
    | _ :: l -> loop state res l
  in loop init [] lex
