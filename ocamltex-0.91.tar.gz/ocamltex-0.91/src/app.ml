(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let eval ~label f x =
  let tm1 = Unix.gettimeofday () in
  let _ = f x in
  let tm2 = Unix.gettimeofday () in
  Printf.printf "(OCamlTeX) %s: %.3f s.\n%!" label (tm2 -. tm1)

let tm1 =
  let tm1 = Unix.gettimeofday () in
  Printexc.record_backtrace true;
  GMain.init ();
  tm1

let name = "OCamlTeX"
let icon = GdkPixbuf.from_file "data/icon.png"
let logo = GdkPixbuf.from_file "data/logo.png"
let version = "0.91"
let title = name ^ " " ^ version
let authors = [("Edouard Evangelisti", "cacophrene@gmail.com")]
let copyright = "Copyright (C) 2009 Edouard Evangelisti"
let website = "https://sourceforge.net/projects/ocamltex2/"

module Dir =
  struct
    let config = "data/"
    let dictionaries = config ^ "dictionaries/"
    let gui = config ^ "gui/"
    let languages = config ^ "languages/"
    let latex = config ^ "latex/"
    let plugins = config ^ "plugins/"
    let templates = config ^ "templates/"
    let symbols = config ^ "symbols/"
  end

let license = Dir.config ^ "ocamltex-license"

module File =
  struct
    let latex = Filename.concat Dir.config "ocamltex-latex"
    let prefs = Filename.concat Dir.config "ocamltex-prefs"
  end
