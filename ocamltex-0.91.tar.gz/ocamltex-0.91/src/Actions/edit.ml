(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let get_current_source () =
  Project.File.get_source (Project.File.get_current ())

let get_current_buffer () = 
  Project.File.get_buffer (Project.File.get_current ())

let undo =
  FunTable.add "undo" (fun () ->
    let buffer = get_current_buffer () in
    if buffer#can_undo then buffer#undo ()
  )

let redo =
  FunTable.add "redo" (fun () ->
    let buffer = get_current_buffer () in
    if buffer#can_redo then buffer#redo ()
  )

let cut =
  FunTable.add "cut" (fun () ->
    (get_current_buffer ())#cut_clipboard GMain.clipboard
  )

let copy = 
  FunTable.add "copy" (fun () -> 
    (get_current_buffer ())#copy_clipboard GMain.clipboard
  )

let paste = 
  FunTable.add "paste" (fun () ->
    (get_current_buffer ())#paste_clipboard GMain.clipboard
  )

let select_all =
  FunTable.add "select-all" (fun () ->
    let buffer = get_current_buffer () in
    buffer#select_range buffer#start_iter buffer#end_iter
  )

let deselect =
  FunTable.add "deselect" (fun () ->
    let buffer = get_current_buffer () in
    let iter = buffer#get_iter `INSERT in
    buffer#select_range iter iter
  )

let latex_insert = 
  FunTable.add "latex-insert" (fun t ->
    let source = get_current_source () in
    let buffer = source#source_buffer in
    (* LaTeX item is inserted in the source buffer. *)
    buffer#insert (LaTeX.Main.to_insert t);
    (* We can then move the caret at its best place. *)
    let n = LaTeX.Main.backchars t in
    buffer#place_cursor ~where:((buffer#get_iter `INSERT)#backward_chars n);
    (* Finally, the source view grab focus. *)
    source#misc#grab_focus ()
  )

let comment =
  FunTable.add "comment" (fun () ->
    let buffer = get_current_buffer () in
    let start, stop = buffer#selection_bounds in
    for i = start#line to stop#line do
      let li = buffer#get_iter (`LINE i) in
      if li#char <> 37 then buffer#insert ~iter:li "%"
    done 
  )

let uncomment =
  FunTable.add "uncomment" (fun () ->
    let buffer = get_current_buffer () in
    let start, stop = buffer#selection_bounds in
    for i = start#line to stop#line do
      let li = buffer#get_iter (`LINE i) in
      if li#char = 37 then buffer#delete ~start:li ~stop:li#forward_char
    done
  )

let indent =
  FunTable.add "indent" (fun () ->
    let source = get_current_source () in
    let str = if source#insert_spaces_instead_of_tabs then 
      String.make source#indent_width ' ' else "\t" in
    let buffer = source#source_buffer in
    let start, stop = buffer#selection_bounds in
    for i = start#line to stop#line do
      let li = buffer#get_iter (`LINE i) in
      buffer#insert ~iter:li str
    done
  )

let unindent =
  FunTable.add "unindent" (fun () ->
    let source = get_current_source () in
    let buffer = source#source_buffer in
    let start, stop = buffer#selection_bounds in
    for i = start#line to stop#line do
      let start = buffer#get_iter (`LINE i) in
      let stop = 
        if start#char <> 9 then (
          let rec loop iter = function 
            | 0 -> iter
            | i -> if Glib.Unichar.isspace iter#char then
              loop iter#forward_char (i - 1) else iter
          in loop start source#indent_width
        ) else start
      in buffer#delete ~start ~stop
    done
  )
