(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

let notebook = GPack.notebook ()

module Project =
  struct
    let tab_label =
      let hbox = GPack.hbox ~spacing:5 () in
      ignore (GMisc.image ~stock:`EDIT ~icon_size:`MENU ~packing:hbox#add ());
      ignore (GMisc.label
        ~text:(Lang.get "documents")
        ~packing:hbox#add ());
      hbox#coerce

    let vbox = GPack.vbox 
      ~spacing:5 
      ~border_width:5 ()
    let container = vbox#coerce
    
    let scroll = GBin.scrolled_window
      ~hpolicy:`ALWAYS
      ~vpolicy:`ALWAYS
      ~shadow_type:`ETCHED_IN
      ~packing:vbox#add ()

    module Data =
      struct
        let cols = new GTree.column_list
        let icon = cols#add GtkStock.conv
        let name = cols#add Gobject.Data.string
        let oid = cols#add Gobject.Data.uint
        let store = GTree.list_store cols
      end

    module View =
      struct
        let icon = GTree.cell_renderer_pixbuf []
        let name = GTree.cell_renderer_text [`XPAD 5]
        let vcol =
          let vcol = GTree.view_column () in
          vcol#pack ~expand:false icon;
          vcol#add_attribute icon "stock_id" Data.icon;
          vcol#pack name;
          vcol#add_attribute name "text" Data.name;
          vcol
      end

    let view =
      let view = GTree.view
        ~model:Data.store
        ~rules_hint:true
        ~headers_visible:false
        ~packing:scroll#add () in
      view#append_column View.vcol;
      let sel = view#selection in
      sel#connect#changed (FunTable.run_with_arg "doc-changed" sel);
      view

    let append x y ~oid:z =
      let row = Data.store#append () in
      Data.store#set ~row ~column:Data.icon x;
      Data.store#set ~row ~column:Data.name y;
      Data.store#set ~row ~column:Data.oid z;
      view#selection#select_iter row;
      Data.store#get_row_reference (Data.store#get_path row)

    let remove rref = ignore (Data.store#remove rref#iter)
    let select rref = view#selection#select_iter rref#iter
  end

module Symbols =
  struct
    let tab_label =
      let hbox = GPack.hbox ~spacing:5 () in
      ignore (GMisc.image ~stock:`EDIT ~icon_size:`MENU ~packing:hbox#add ());
      ignore (GMisc.label
        ~text:(Lang.get "symbols")
        ~packing:hbox#add ());
      hbox#coerce

    let table_of_array t =
      let n = Array.length t in
      let table = GPack.table 
        ~rows:(n / 5 + if n mod 5 = 0 then 0 else 1)
        ~columns:5
        ~row_spacings:10
        ~col_spacings:10
        ~border_width:10
        ~homogeneous:true () in
      let sym = Lang.get "symbol" in
      Array.iteri (fun i t ->
        let btn = GButton.button 
          ~relief:`NONE 
          ~packing:(table#attach ~left:(i mod 5) ~top:(i / 5)) () in
        btn#connect#clicked (FunTable.run_with_arg "latex-insert" t);
        btn#misc#set_can_focus false;
        GMisc.image 
          ~stock:(LaTeX.Main.get_stock t) 
          ~icon_size:`BUTTON
          ~packing:btn#set_image ();
        ksprintf btn#misc#set_tooltip_markup "%s : %s" 
          sym (LaTeX.Main.to_markup t)
      ) t;
      table

    let tables, strings =
      let htbl = Hashtbl.create 7 in
      let rec loop acc = function
        | [] -> (htbl, List.sort String.compare acc)
        | (id, t) :: l -> let translation = Lang.get id in 
          Hashtbl.add htbl translation (table_of_array t);
          loop (translation :: acc) l
      in loop [] (LaTeX.Main.get_symbol_tables ())

    let vbox = GPack.vbox 
      ~spacing:5 
      ~border_width:5 ()
    let container = vbox#coerce
    
    let all = GEdit.combo_box_text
      ~strings
      ~use_markup:true
      ~packing:(vbox#pack ~expand:false) ()

    let store = fst (snd all)
    let column = snd (snd all)

    let scroll = GBin.scrolled_window
      ~hpolicy:`ALWAYS
      ~vpolicy:`ALWAYS
      ~packing:vbox#add ()

    let display combo () =
      match combo#active_iter with
      | None -> ()
      | Some row -> 
        let name = store#get ~row ~column in
        let table = Hashtbl.find tables name in
        List.iter scroll#remove scroll#children;
        begin match table#coerce#misc#parent with 
          | Some _ -> table#coerce#misc#unparent ()
          | _ -> ()
        end;
        scroll#add_with_viewport table#coerce

    let combo = 
      let combo = fst all in
      combo#connect#changed (display combo);
      combo#set_active 0;
      combo
  end

(* Tabs registration. *)
let _ =
  List.iter2 (fun tab_label x -> notebook#append_page ~tab_label x; ())
    [ Project.tab_label; Symbols.tab_label ] 
    [ Project.container; Symbols.container ]
