(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let notebook = GPack.notebook ~tab_pos:`RIGHT ()

module Log =
  struct
    let tab_label =
      let hbox = GPack.hbox ~spacing:2 () in
      let packing = hbox#add in
      ignore (GMisc.image ~stock:`FILE ~icon_size:`MENU ~packing ());
      ignore (GMisc.label ~text:(Lang.get "bottom-pane-log") ~packing ());
      hbox#coerce

    let container = 
      let vbox = GPack.vbox () in
      ignore (notebook#append_page ~tab_label vbox#coerce);
      vbox

    module Data =
      struct
        let cols = new GTree.column_list
        let icon = cols#add GtkStock.conv
        let text = cols#add Gobject.Data.string
        let store = GTree.list_store cols
      end

    module View =
      struct
        let icon = GTree.cell_renderer_pixbuf []
        let text = GTree.cell_renderer_text []
        let vcol =
          let vcol = GTree.view_column () in
          vcol#pack ~expand:false icon;
          vcol#add_attribute icon "stock_id" Data.icon;
          vcol#pack text;
          vcol#add_attribute text "markup" Data.text;
          vcol
      end

    let scroll = GBin.scrolled_window
      ~hpolicy:`ALWAYS
      ~vpolicy:`ALWAYS
      ~packing:container#add ()

    let view =
      let view = GTree.view
        ~model:Data.store
        ~rules_hint:true
        ~headers_visible:false
        ~packing:scroll#add () in
      view#append_column View.vcol;
      view

    type kind = [ `Info | `Warning | `Error ]

    let clear = Data.store#clear

    let display () =
      (* Go to bottom pane log tab. *)
      notebook#goto_page 0;
      try ignore (Main.vpaned#child2) with _ ->
        (* Display bottom pane if it is currently hidden. *)
        List.iter (function 
          | `CheckItem check -> check#set_active true 
          | _ -> ()
        ) (Main.get "toggle-bottom-pane")
        

    let param_of_kind = function
      | `Info -> (`DIALOG_INFO, 0x267417)
      | `Warning -> (`DIALOG_WARNING, 0xf6c620)
      | `Error -> (`DIALOG_ERROR, 0xb80900)

    let add kind str =
      let row = Data.store#append () in
      let stock, color = param_of_kind kind in
      Data.store#set ~row ~column:Data.icon stock;
      Printf.ksprintf (Data.store#set ~row ~column:Data.text)
        "<span color='#%06X'>%s</span>" color str
  end

module Shell =
  struct
    let tab_label =
      let hbox = GPack.hbox ~spacing:2 () in
      let packing = hbox#add in
      ignore (GMisc.image ~stock:`FILE ~icon_size:`MENU ~packing ());
      ignore (GMisc.label ~text:(Lang.get "bottom-pane-shell") ~packing ());
      hbox#coerce

    let container = 
      let vbox = GPack.vbox () in
      ignore (notebook#append_page ~tab_label vbox#coerce);
      vbox

    let scroll = GBin.scrolled_window
      ~hpolicy:`ALWAYS
      ~vpolicy:`ALWAYS
      ~packing:container#add ()

    let view =
      let view = GSourceView2.source_view
        ~highlight_current_line:true
        ~insert_spaces_instead_of_tabs:true
        ~show_line_numbers:true
        ~packing:scroll#add () in
      view
  end
