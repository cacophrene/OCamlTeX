(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

let tab_label = 
  begin GMisc.label 
    ~text:(Lang.get "prefs-gui") ()
  end#coerce

let vbox = GPack.vbox ~border_width:10 ~spacing:10 ()
let packing = vbox#pack ~expand:false
let container = vbox#coerce

module Languages =
  struct
    let _ = GMisc.label
      ~xalign:0.
      ~markup:(Lang.format "gui-language" "<b>%s</b>")
      ~packing ()

    let hbox = Tools.hbox_with_indent ~packing ()
    let vbox = GPack.vbox ~spacing:10 ~packing:hbox#add ()

    let get_language_files () =
      let t = Sys.readdir App.Dir.languages in
      let rec loop acc = function
        | 0 -> acc
        | i -> let j = i - 1 in
          let file = t.(j) in
          loop (if Filename.check_suffix file ".lang" then 
          (Filename.chop_extension file) :: acc else acc) j
      in loop [] (Array.length t)

    let strings = get_language_files ()

    let get_active () =
      let lang = AppPrefs.get "language" in
      let rec loop n = function
        | [] -> assert false (* OCamlTeX would have previously aborted! *)
        | file :: _ when file = lang -> n
        | _ :: t -> loop (n + 1) t
      in loop 0 strings

    let all = GEdit.combo_box_text 
      ~strings 
      ~active:(get_active ()) 
      ~packing:vbox#add ()

    let combo = fst all
    let store = fst (snd all)
    let column = snd (snd all)

    let _ = GMisc.label
      ~xalign:0.
      ~markup:(Lang.format "gui-lang-warning" "<small>%s</small>")
      ~packing:vbox#add ()
  end

(* Dictionaries. *)
module Dictionaries =
  struct

    let _ = GMisc.label
      ~xalign:0.
      ~markup:(Lang.format "dictionaries" "<b>%s</b>")
      ~packing ()

    let hbox = Tools.hbox_with_indent ~packing:vbox#add ()

    module Data =
      struct
        let cols = new GTree.column_list
        let loaded = cols#add Gobject.Data.boolean
        let text = cols#add Gobject.Data.string
        let store = GTree.list_store cols
      end
    module View =
      struct
        let loaded = GTree.cell_renderer_toggle []
        let text = GTree.cell_renderer_text [`XPAD 5]
        let vcol =
          let vcol = GTree.view_column () in
          vcol#pack ~expand:false loaded;
          vcol#add_attribute loaded "active" Data.loaded;
          vcol#pack text;
          vcol#add_attribute text "text" Data.text;
          vcol
      end
    let scroll = GBin.scrolled_window
      ~hpolicy:`ALWAYS
      ~vpolicy:`ALWAYS
      ~shadow_type:`ETCHED_IN
      ~packing:hbox#add ()
    let view = 
      let view = GTree.view 
        ~model:Data.store
        ~rules_hint:true 
        ~headers_visible:false 
        ~packing:scroll#add () in
      view#append_column View.vcol;
      view

    let import () =
      List.iter (fun dic ->
        let row = Data.store#append () in
        Data.store#set ~row ~column:Data.loaded false;
        Data.store#set ~row ~column:Data.text dic
      ) (AutoComplete.Main.get_dictionaries ())
  end

let import () =
  Dictionaries.import ();
  Languages.combo#set_active (Languages.get_active ())

let export () =
  match Languages.combo#active_iter with
  | Some row -> let lang = Languages.store#get ~row ~column:Languages.column in
    AppPrefs.set "language" (`Str lang)
  | _ -> ()
