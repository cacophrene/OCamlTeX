(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let factory = GtkStock.make_icon_factory ~default:true ()

let get_size = function
  | 32 -> `BUTTON
  | 24 -> `LARGE_TOOLBAR
  | _  -> `MENU

let icon_set file =
  let rec loop acc = function
    | 8 -> GtkStock.make_icon_set acc
    | n -> let pixbuf = GdkPixbuf.from_file_at_size file ~width:n ~height:n in
      let source = GtkStock.make_icon_source ~pixbuf ~size:(get_size n) () in
      loop (source :: acc) (n - 8)
  in loop [] 32

let add str =
  let file = Filename.concat App.Dir.symbols str in
  if Sys.file_exists file then (
    let id = Filename.chop_extension (Filename.basename str) in
    GtkStock.Icon_factory.add factory id (icon_set file);
    `STOCK id
  ) else `STOCK str
