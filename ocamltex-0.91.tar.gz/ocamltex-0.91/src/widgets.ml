(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let run ~doc =
  List.iter2 (fun var dat -> Unix.putenv var (AppPrefs.get dat ^ " %s"))
    ["TEXDOCVIEW_ps"; "TEXDOCVIEW_dvi"; "TEXDOCVIEW_pdf"; "TEXDOCVIEW_html";
     "TEXDOCVIEW_text"]
    ["ps-viewer"; "dvi-viewer"; "pdf-viewer"; "html-viewer"; "text-viewer"];
  Unix.create_process "texdoc" [|"texdoc"; doc|] Unix.stdin Unix.stdout 
    Unix.stderr

class texdoc ~packing =
  object (self)
    val hbox = GPack.hbox ~spacing:5 ~packing ()
    val stock = GMisc.image ~stock:`HELP ()
    val entry = GEdit.entry ()

    initializer
      entry#event#connect#key_release self#may_show_doc;
      List.iter hbox#add [stock#coerce; entry#coerce]
 
   method private may_show_doc t =
      if GdkEvent.Key.keyval t = 65293 then ignore (run ~doc:entry#text);
      false
    method entry = entry
  end
