(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

type dat = {
  mutable file : string;
  mutable is_saved : bool;
  mutable is_blank : bool
}
type tab = { 
  label : GMisc.label; 
  image : GMisc.image;
  close : GButton.button
}
type page = { 
  widget : GObj.widget; 
  source : GSourceView2.source_view 
}
type gtk = { 
  tab : tab; 
  page : page; 
  rref : GTree.row_reference;
  signals : GtkSignal.id list
}
type t = { dat : dat; gtk : gtk } 

let undo_items = lazy (GUI.Main.get "undo")
let redo_items = lazy (GUI.Main.get "redo")

let process l x () =
  List.iter (function
    | `ToolButton btn -> btn#misc#set_sensitive x
    | `ImageItem btn  -> btn#misc#set_sensitive x
    | _ -> ()
  ) (Lazy.force l)

module Storage =
  struct
    let htbl = Hashtbl.create 7
    let add widget = Hashtbl.add htbl widget#get_oid
    let mem widget = Hashtbl.mem htbl widget#get_oid
    let rem widget = Hashtbl.remove htbl widget#get_oid
    let get widget = Hashtbl.find htbl widget#get_oid
  end

let current = ref (Obj.magic ())
let get_current () = !current
let set_current widget = current := Storage.get widget

let is_blank t = t.dat.is_blank
let is_saved t = t.dat.is_saved

module Get =
  struct
    let dir t = Filename.dirname t.dat.file
    let name t = Filename.basename t.dat.file
    let file t = t.dat.file
    let source t = t.gtk.page.source
    let buffer t = t.gtk.page.source#source_buffer
    let contents t = t.gtk.page.source#source_buffer#get_text ()
    let icon t = t.gtk.tab.image#stock
    let focus t = t.gtk.page.source#misc#grab_focus ()
  end

module Set =
  struct
    let file t x = t.dat.file <- x
    let saved t x = t.dat.is_saved <- x
    let contents t = t.gtk.page.source#source_buffer#set_text
  end

module Update =
  struct
    let label t = t.gtk.tab.label#set_text 
      (Filename.basename t.dat.file)
    let image t = t.gtk.tab.image#set_stock 
      (if t.dat.is_saved then `FILE else `FLOPPY)
  end

module Aux =
  struct
    let uniq =
      let n = ref 0 and doc = Lang.get "document" in
      fun () -> incr n; sprintf "%s-%d.tex" doc !n
    let read file =
      let ich = open_in file in
      let len = in_channel_length ich in
      let str = String.create len in
      really_input ich str 0 len;
      close_in ich;
      str
    let write file (buf : GSourceView2.source_buffer) =
      let och = open_out file in
      output_string och (buf#get_text ());
      close_out och
  end

let update_title t =
  let f = GUI.Main.window#set_title in
  begin
    if t.dat.is_saved then ksprintf f "%s (%s) - %s" (Get.name t) (Get.dir t)
    else ksprintf f "%s - %s" (Get.name t)
  end App.title

let create =
  FunTable.add "new" (fun () ->
    let file = Aux.uniq () in
    let source, widget = Display.source () in
    let _ = AutoComplete.Code.add source in
    let tab_label, label, image, close = Display.tab_label `FLOPPY file in
    let t = {
      dat = { file = file; is_saved = false; is_blank = true };
      gtk = {
        tab = { label = label; image = image; close = close };
        page = { widget = widget; source = source };
        rref = GUI.SidePane.Project.append `FILE file;
        signals = [] }
    } in
    close#connect#clicked (FunTable.run_with_arg "close" t);
    Storage.add widget t;
    set_current widget;
    let n = GUI.Main.opened_files#append_page ~tab_label widget in
    GUI.Main.opened_files#goto_page n;
    Get.focus t
  )

let save_as t =
  match Dialog.SaveAs.show ~file:(Get.file t) with
  | None -> () (* Action has been cancelled. *)
  | Some file -> 
    Set.file t file; Set.saved t true;
    Update.label t; Update.image t;
    Aux.write file (Get.buffer t);
    update_title t

let save t =
  if t.dat.is_saved then (
    if Sys.file_exists t.dat.file then (
      Set.saved t true; Update.image t;
      Aux.write t.dat.file (Get.buffer t)
    ) else save_as t
  ) else save_as t

let close t =
  match t.dat.is_saved with
  | true
  | false when is_blank t -> let widget = t.gtk.page.widget in
    GUI.Main.opened_files#remove_page (GUI.Main.opened_files#page_num widget);
    GUI.SidePane.Project.remove t.gtk.rref;
    Storage.rem widget
  | _ -> ()

let load =
  FunTable.add "open" (fun () ->
    List.iter (fun file ->
      if is_blank !current then close !current;
      let source, widget = Display.source () in
      let _ = AutoComplete.Code.add source in
      let name = Filename.basename file in
      let tab_label, label, image, close = Display.tab_label `FILE name in
      let t = {
        dat = { file = file; is_saved = true; is_blank = false };
        gtk = {
          tab = { label = label; image = image; close = close };
          page = { widget = widget; source = source };
          rref = GUI.SidePane.Project.append `FILE name;
          signals = [] }
      } in
      source#source_buffer#set_text (Aux.read file);
      close#connect#clicked (FunTable.run_with_arg "close" t);
      Storage.add widget t;
      set_current widget;
      let n = GUI.Main.opened_files#append_page ~tab_label widget in
      GUI.Main.opened_files#goto_page n;
      Get.focus t
    ) (Dialog.Open.show ~dir:".")
  )

let iter f = Hashtbl.iter (fun _ -> f) Storage.htbl
