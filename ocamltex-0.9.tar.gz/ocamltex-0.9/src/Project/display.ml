(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let latex = GUI.Main.source_manager#language "latex"

let source () =
  let scroll = GBin.scrolled_window
    ~hpolicy:`ALWAYS
    ~vpolicy:`ALWAYS
    ~border_width:5
    ~shadow_type:`ETCHED_IN () in
  let draw_spaces = 
    if AppPrefs.get_bool "draw-spaces" then [`NEWLINE; `SPACE] 
    else [] in
  let source = GSourceView2.source_view
    ~draw_spaces
    ~auto_indent:true
    ~highlight_current_line:(AppPrefs.get_bool "highlight-current-line")
    ~indent_on_tab:true
    ~indent_width:2
    ~insert_spaces_instead_of_tabs:true
    ~right_margin_position:(AppPrefs.get_int "right-margin-position")
    ~show_line_numbers:(AppPrefs.get_bool "show-line-numbers")
    ~show_right_margin:(AppPrefs.get_bool "show-right-margin")
    ~packing:scroll#add () in
  source#misc#modify_font_by_name "Bitstream Vera Sans Mono 10";
  let buf = source#source_buffer in
  buf#set_highlight_syntax (AppPrefs.get_bool "highlight-syntax");
  buf#set_language latex;
  let id = AppPrefs.get "style-scheme" in
  buf#set_style_scheme (GUI.Main.scheme_manager#style_scheme id);
  (source, scroll#coerce)

let tab_label ~stock text =
  let hbox = GPack.hbox ~spacing:5 () in
  let packing = hbox#pack ~expand:false in
  let image = GMisc.image ~stock ~icon_size:`MENU ~packing () in
  let label = GMisc.label ~text ~packing () in
  let close_button = GButton.button ~relief:`NONE ~packing () in
  close_button#misc#set_can_focus false;
  GMisc.image 
    ~stock:`CLOSE
    ~icon_size:`MENU
    ~packing:close_button#set_image ();
  (hbox#coerce, label, image, close_button)
