(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type arg = [ `Arg of string | `Opt of string | `Par of string ]

type flag = [
  | `Stock
  | `Preamble
  | `MathMode 
  | `Verbatim
  | `UsePackg of string
]

type latex_item = {
  tex_kind : bool;
  tex_name : string;
  tex_args : arg list;
  tex_flag : flag list
}

let add_gen = ref (Obj.magic ())
let add_lex = ref (Obj.magic ())
let add_grp = ref (Obj.magic ())
let add_sym = ref (Obj.magic ())

module IconPattern =
  struct
    let var pat id =
      let buf = Buffer.create 16 in
      Buffer.add_substitute buf (function "id" -> id | _-> "?") pat;
      Symbols.add (Buffer.contents buf)

    let get opt =
      let rec loop = function
        | [] -> None 
        | ("icon_pattern", `Str pat) :: _ -> Some (var pat)
        | _ :: t -> loop t
      in loop opt
  end

(* Get flag list from option list. *)
let flag_list l =
  let rec loop x acc = function
    | [] -> (x, acc)
    | ("mathmode", `Bln true) :: t -> loop x (`MathMode :: acc) t
    | ("verbatim", `Bln true) :: t -> loop x (`Verbatim :: acc) t
    | ("preamble", `Bln true) :: t -> loop x (`Preamble :: acc) t
    | ("usepackg", `Str pckg) :: t -> loop x (`UsePackg pckg :: acc) t
    | ("icon", `Str path) :: t -> Symbols.add path; loop false (`Stock :: acc) t
    | _ :: t -> loop x acc t in
  loop true [] l 

let get_bool ?(def = false) id opt =
  try
    match List.assoc id opt with 
    | `Bln bln -> bln
    | _ -> def
  with Not_found -> def

let rev_concat l = String.concat "-" (List.rev l)

(* LaTeX groups, commands and environments. *)
let rec parse_latex l =
  let rec loop ?(auto_complete = true) ?pat buf = function
    | [] -> []
    | `Node ("Group", `Str id, opt, contents) :: t ->
      let buf' = id :: buf in
      let pat = match IconPattern.get opt with
        | None -> pat
        | some -> some in
      let cmpl = get_bool ~def:auto_complete "auto_complete" opt in
      let l = loop ~auto_complete:cmpl ?pat buf' contents in
      let id = rev_concat buf' and tbl = Array.of_list l in
      if get_bool "symbols" opt then !add_sym id tbl;
      !add_grp id tbl;
      l @ loop ~auto_complete ?pat buf t
    | `Node (str, `Str id, opt, args) :: t ->
      let bln, flags = flag_list opt in
      let cmd = {
        tex_kind = str = "Environment"; 
        tex_name = id;
        tex_args = parse_args args;
        tex_flag = 
          if bln then (
            match pat with 
              | Some f -> f id; `Stock :: flags
              | _ -> flags
          ) else flags
      } in !add_gen cmd; 
      if auto_complete then !add_lex cmd;
      cmd :: loop ~auto_complete ?pat buf t
    | `Leaf ("Include", `Str x, opt) :: t ->
      let buf' = x :: buf in
      let pat = match IconPattern.get opt with
        | None -> pat
        | some -> some in
      let cmpl = get_bool ~def:auto_complete "auto_complete" opt in
      let token_list = Sexpr.from_file (Filename.concat App.Dir.latex x) in
      let l = loop ~auto_complete:cmpl ?pat buf' token_list in
      let id = rev_concat buf' and tbl = Array.of_list l in
      if get_bool "symbols" opt then !add_sym id tbl;
      !add_grp id tbl;
      l @ loop ~auto_complete ?pat buf t
    | `Leaf (str, `Str id, opt) :: t ->
      let bln, flags = flag_list opt in
      let cmd = {
        tex_kind = str = "Environment"; 
        tex_name = id;
        tex_args = [];
        tex_flag =
          if bln then (
            match pat with 
              | Some f -> f id; `Stock :: flags
              | _ -> flags
          ) else flags
      } in !add_gen cmd; 
      if auto_complete then !add_lex cmd;
      cmd :: loop ~auto_complete ?pat buf t
    | _ :: t -> loop ~auto_complete ?pat buf t 
  in ignore (loop [] l)

(* LaTeX arguments. *)
and parse_args = function
  | [] -> []
  | `Leaf ("Arg", `Str id, _) :: t -> `Arg id :: parse_args t
  | `Leaf ("Opt", `Str id, _) :: t -> `Opt id :: parse_args t
  | `Leaf ("Par", `Str id, _) :: t -> `Par id :: parse_args t
  | _ -> invalid_arg "LaTeX.Builder.parse_args"

let from_config ~main_storing:f ~trie_storing:g ~group_storing:h ~symbol_storing:i =
  add_gen := f; add_lex := g; add_grp := h; add_sym := i;
  App.eval "LaTeX build" parse_latex (Sexpr.from_file App.File.latex)
