(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

(* This type is defined to prevent use of internal representation of 
 * Builder.latex_item outside of LaTeX module. *)
type t = Builder.latex_item

let is_verbatim t = List.mem `Verbatim t.Builder.tex_flag
let is_environment t = t.Builder.tex_kind

let require_preamble t = List.mem `Preamble t.Builder.tex_flag
let require_mathmode t = List.mem `MathMode t.Builder.tex_flag

let get_id t = t.Builder.tex_name
let get_stock t =
  if List.mem `Stock t.Builder.tex_flag then `STOCK t.Builder.tex_name
  else `OPEN

let rec get_package t =
  let rec loop = function
    | [] -> None
    | `UsePackg str :: _ -> Some str
    | _ :: t -> loop t
  in loop t.Builder.tex_flag

(* Markup conversion. *)
module Markup =
  struct
    let string_of_args buf l =
      List.iter (function
        | `Arg str -> bprintf buf "{<i>%s</i>}" str
        | `Opt str -> bprintf buf "[<i>%s</i>]" str
        | `Par str -> bprintf buf "{<i>%s</i>}" str (* FIXME *)
      ) l
    let of_environment buf env =
      bprintf buf "<b>\\begin</b>{%s}" env.Builder.tex_name;
      match env.Builder.tex_args with
        | [] -> ()
        | al -> string_of_args buf al
    let of_command buf cmd =
      bprintf buf "<b>\\%s</b>" cmd.Builder.tex_name;
      match cmd.Builder.tex_args with
        | [] -> ()
        | al -> string_of_args buf al
    let of_item t = 
      let buf = Buffer.create 16 in
      Buffer.add_string buf "<tt><small>";
      (if t.Builder.tex_kind then of_environment else of_command) buf t;
      Buffer.add_string buf "</small></tt>";
      Buffer.contents buf
  end

(* String conversion. *)
module String =
  struct
    let string_of_args buf l =
      List.iter (function
        | `Arg _ -> Buffer.add_string buf "{}"
        | `Opt _ -> Buffer.add_string buf "[]"
        | `Par _ -> Buffer.add_string buf "{}" (* FIXME *)
      ) l
    let of_environment buf env =
      bprintf buf "\\begin{%s}" env.Builder.tex_name;
      match env.Builder.tex_args with
        | [] -> ()
        | al -> string_of_args buf al
    let of_command buf cmd =
      bprintf buf "\\%s" cmd.Builder.tex_name;
      match cmd.Builder.tex_args with
        | [] -> ()
        | al -> string_of_args buf al
    let of_item t = 
      let buf = Buffer.create 16 in
      (if t.Builder.tex_kind then of_command else of_command) buf t;
      Buffer.contents buf
  end

module Insert =
  struct
    let string_of_args buf l =
      List.iter (function
        | `Arg _ -> Buffer.add_string buf "{}"
        | `Opt _ -> Buffer.add_string buf "[]"
        | `Par _ -> Buffer.add_string buf "{}" (* FIXME *)
      ) l
    let of_environment buf env =
      bprintf buf "\\begin{%s}" env.Builder.tex_name;
      begin match env.Builder.tex_args with
        | [] -> ()
        | al -> string_of_args buf al end;
      bprintf buf "\n\n\\end{%s}" env.Builder.tex_name
    let of_command buf cmd =
      bprintf buf "\\%s" cmd.Builder.tex_name;
      match cmd.Builder.tex_args with
        | [] -> ()
        | al -> string_of_args buf al
    let of_item t = 
      let buf = Buffer.create 16 in
      (if t.Builder.tex_kind then of_environment else of_command) buf t;
      Buffer.contents buf
  end

let to_string = String.of_item
let to_markup = Markup.of_item
let to_insert = Insert.of_item

let backchars t =
  begin match List.length (t.Builder.tex_args) with
    | 0 -> 0
    | n -> n lsl 1 - if t.Builder.tex_kind then 0 else 1
  end + if t.Builder.tex_kind then Glib.Utf8.length t.Builder.tex_name + 7 
  else 0

(* Storing. *)
module Storing =
  struct
    let trie = ref Trie.ASCII.empty
    let main = Hashtbl.create 7 
    let groups = Hashtbl.create 7
    let symbols = Hashtbl.create 7
  end

let from_trie_id = Hashtbl.find Storing.main

let get_prefix x = 
  try Some (Trie.ASCII.sub x !Storing.trie) with 
  | Not_found -> None

let get_item id = 
  try Hashtbl.find Storing.main id with 
    | Not_found -> eprintf "(OCamlTeX) Error: Unkown LaTeX item %S.\n%!" id;
      exit 2
let get_group id = 
  try Hashtbl.find Storing.groups id with
    | Not_found -> eprintf "(OCamlTeX) Error: Unkown LaTeX group %S.\n%!" id;
      [||]
let get_symbols id = 
  try Hashtbl.find Storing.symbols id with
    | Not_found -> eprintf "(OCamlTeX) Error: Unkown symbol table %S.\n%!" id;
      [||]

let get_symbol_tables () =
  Hashtbl.fold (fun x y l -> (x, y) :: l) Storing.symbols []

let init () = 
  let main_storing t = Hashtbl.add Storing.main (to_string t) t
  and trie_storing t = Storing.trie := Trie.ASCII.add (to_string t) !Storing.trie
  and group_storing = Hashtbl.add Storing.groups
  and symbol_storing = Hashtbl.add Storing.symbols in
  Builder.from_config ~main_storing ~trie_storing ~group_storing ~symbol_storing
