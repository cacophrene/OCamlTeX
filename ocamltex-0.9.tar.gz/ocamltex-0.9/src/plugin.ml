(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

type t = string

module ID =
  struct
    let main x = x
    let about x = sprintf "about-%s" x
    let configure x = sprintf "configure-%s" x
    let title x = sprintf "%s-title" x
    let description x = sprintf "%s-description" x
  end

module Action =
  struct
    let show_about x = FunTable.run (ID.about x) ()
    let show_configure x = FunTable.run (ID.configure x) ()
  end

let plugins : t list ref = ref []

let get_list () = !plugins

let init () =
  let dir_contents = Sys.readdir App.Dir.plugins in
  let rec loop acc = function
    | 0 -> plugins := List.sort String.compare acc
    | i -> let j = i - 1 in
      let file = Array.unsafe_get dir_contents j in
      if Filename.check_suffix file ".cmxs" then (
        try 
          Dynlink.loadfile (Filename.concat App.Dir.plugins file);
          loop (Filename.chop_extension file :: acc) j
        with _ (* anything goes wrong. *) -> loop acc j 
      ) else loop acc j
  in loop [] (Array.length dir_contents)
