(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let _ =
  AppPrefs.init ();
  Lang.init ();
  LaTeX.Main.init ()

let accel_group = GtkData.AccelGroup.create ()

let window =
  let wnd = GWindow.window
    ~title:App.title
    ~icon:App.icon
    ~position:`CENTER
    ~height:620 ~width:1000 () in
  wnd#connect#destroy GMain.quit;
  wnd#add_accel_group accel_group;
  wnd

let latex_filter = GFile.filter
  ~name:(Lang.get "latex-files")
  ~patterns:["*.tex"; "*.bib"] ()
let source_manager = GSourceView2.source_language_manager ~default:true
let scheme_manager = GSourceView2.source_style_scheme_manager ~default:true

let status_icon = GMisc.status_icon_from_pixbuf App.icon
let container = GPack.vbox ~packing:window#add ()
let packing = container#pack ~expand:false
let bars = GPack.vbox ~packing ()

let items = Hashtbl.create 20

let add id item = 
  try
    let lst = Hashtbl.find items id in
    lst := item :: !lst
  with Not_found -> Hashtbl.add items id (ref [item])

let get id = try !(Hashtbl.find items id) with Not_found -> []

(* Panes. *)
let hpaned = 
  let hpaned = GPack.paned `HORIZONTAL 
    ~border_width:5
    ~packing:container#add () in
  hpaned#set_position 225;
  hpaned

let vpaned =
  let vpaned = GPack.paned `VERTICAL 
    ~packing:(hpaned#pack2 ~shrink:false) () in
  vpaned#set_position 400;
  vpaned

let opened_files = 
  let notebook = GPack.notebook ~packing:(vpaned#pack1 ~shrink:false) () in
  notebook#connect#switch_page (fun n -> 
    FunTable.run_with_arg "switch-page" n ()
  );
  notebook

let status = GMisc.statusbar ~packing ()
let context = status#new_context ~name:"main"
let print fmt = Printf.ksprintf (fun msg -> ignore (context#push msg)) fmt

let init () = Builder.from_config 
  ~accels:accel_group 
  ~packing:bars#add 
  ~storing:add;
