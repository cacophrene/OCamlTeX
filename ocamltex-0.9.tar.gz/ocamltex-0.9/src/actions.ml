(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let init () = ()

module GUI =
  struct
    let quit = FunTable.add "quit" GUI.Main.window#destroy

    let toggle_fullscreen =
      let f =
        let switch = ref false in
        fun () ->
          switch := not !switch;
          if !switch then GUI.Main.window#fullscreen ()
          else GUI.Main.window#unfullscreen ()
      in FunTable.add "toggle-fullscreen" f

    let toggle_side_pane =
      let f =
        let switch = ref false in
        fun () ->
          switch := not !switch;
          if !switch then GUI.Main.hpaned#pack1 ~shrink:false 
            GUI.SidePane.notebook#coerce    
          else GUI.Main.hpaned#remove GUI.Main.hpaned#child1;
      in FunTable.add "toggle-side-pane" f

    let toggle_bottom_pane =
      let f =
        let switch = ref false in
        fun () ->
          switch := not !switch;
          if !switch then GUI.Main.vpaned#pack2 ~shrink:false 
            GUI.BottomPane.notebook#coerce    
          else GUI.Main.vpaned#remove GUI.Main.vpaned#child2;
      in FunTable.add "toggle-bottom-pane" f

    let switch_page =
      let f n =
        Project.File.set_current (GUI.Main.opened_files#get_nth_page n);
        Project.File.update_title (Project.File.get_current ())
      in FunTable.add "switch-page" f

    let go_back = FunTable.add "go-back" GUI.Main.opened_files#previous_page
    let go_forward = FunTable.add "go-forward" GUI.Main.opened_files#next_page
  end


module Edit =
  struct
    let get_current_source () =
      Project.File.Get.source (Project.File.get_current ())
    let get_current_buffer () = 
      Project.File.Get.buffer (Project.File.get_current ())

    let undo =
      FunTable.add "undo" (fun () ->
        let buffer = get_current_buffer () in
        if buffer#can_undo then buffer#undo ()
      )

    let redo =
      FunTable.add "redo" (fun () ->
        let buffer = get_current_buffer () in
        if buffer#can_redo then buffer#redo ()
      )

    let cut =
      FunTable.add "cut" (fun () ->
        (get_current_buffer ())#cut_clipboard GMain.clipboard
      )

    let copy = 
      FunTable.add "copy" (fun () -> 
        (get_current_buffer ())#copy_clipboard GMain.clipboard
      )

    let paste = 
      FunTable.add "paste" (fun () ->
        (get_current_buffer ())#paste_clipboard GMain.clipboard
      )

    let select_all =
      FunTable.add "select-all" (fun () ->
        let buffer = get_current_buffer () in
        buffer#select_range buffer#start_iter buffer#end_iter
      )

    let deselect =
      FunTable.add "deselect" (fun () ->
        let buffer = get_current_buffer () in
        let iter = buffer#get_iter `INSERT in
        buffer#select_range iter iter
      )

    let latex_insert = 
      FunTable.add "latex-insert" (fun t ->
        let source = get_current_source () in
        let buffer = source#source_buffer in
        (* LaTeX item is inserted in the source buffer. *)
        buffer#insert (LaTeX.Main.to_insert t);
        (* We can then move the caret at its best place. *)
        let n = LaTeX.Main.backchars t in
        buffer#place_cursor ~where:((buffer#get_iter `INSERT)#backward_chars n);
        (* Finally, the source view grab focus. *)
        source#misc#grab_focus ()
      )

    let comment =
      FunTable.add "comment" (fun () ->
        let buffer = get_current_buffer () in
        let start, stop = buffer#selection_bounds in
        for i = start#line to stop#line do
          let li = buffer#get_iter (`LINE i) in
          if li#char <> 37 then buffer#insert ~iter:li "%"
        done 
      )

    let uncomment =
      FunTable.add "uncomment" (fun () ->
        let buffer = get_current_buffer () in
        let start, stop = buffer#selection_bounds in
        for i = start#line to stop#line do
          let li = buffer#get_iter (`LINE i) in
          if li#char = 37 then buffer#delete ~start:li ~stop:li#forward_char
        done
      )

    let indent =
      FunTable.add "indent" (fun () ->
        let source = get_current_source () in
        let str = if source#insert_spaces_instead_of_tabs then 
          String.make source#indent_width ' ' else "\t" in
        let buffer = source#source_buffer in
        let start, stop = buffer#selection_bounds in
        for i = start#line to stop#line do
          let li = buffer#get_iter (`LINE i) in
          buffer#insert ~iter:li str
        done
      )

    let unindent =
      FunTable.add "unindent" (fun () ->
        let source = get_current_source () in
        let buffer = source#source_buffer in
        let start, stop = buffer#selection_bounds in
        for i = start#line to stop#line do
          let start = buffer#get_iter (`LINE i) in
          let stop = 
            if start#char <> 9 then (
              let rec loop iter = function 
                | 0 -> iter
                | i -> if Glib.Unichar.isspace iter#char then
                  loop iter#forward_char (i - 1) else iter
              in loop start source#indent_width
            ) else start
          in buffer#delete ~start ~stop
        done
      )
  end


module Source =
  struct
    let highlight_current_line =
      FunTable.add "highlight-current-line" (fun x ->
        Project.File.iter (fun t ->
          (Project.File.Get.source t)#set_highlight_current_line x
      ))

    let highlight_syntax =
      FunTable.add "highlight-syntax" (fun x ->
        Project.File.iter (fun t ->
          (Project.File.Get.buffer t)#set_highlight_syntax x
      ))

    let set_style_scheme =
      FunTable.add "style-scheme" (fun x ->
        Project.File.iter (fun t ->
          (Project.File.Get.buffer t)#set_style_scheme x
      ))

    let show_line_numbers =
      FunTable.add "show-line-numbers" (fun x ->
        Project.File.iter (fun t ->
          (Project.File.Get.source t)#set_show_line_numbers x
      ))

    let draw_spaces =
      let l = [`NEWLINE; `SPACE] in
      FunTable.add "draw-spaces" (fun bln ->
        Project.File.iter (fun t ->
          (Project.File.Get.source t)#set_draw_spaces (if bln then l else [])
      ))

    let show_right_margin =
      FunTable.add "show-right-margin" (fun x ->
        Project.File.iter (fun t ->
          (Project.File.Get.source t)#set_show_right_margin x
      ))

    let right_margin_position =
      FunTable.add "right-margin-position" (fun n ->
        Project.File.iter (fun t ->
          (Project.File.Get.source t)#set_right_margin n
      ))

    let highlight_matching_brackets =
      FunTable.add "highlight-matching-brackets" (fun x ->
        Project.File.iter (fun t ->
          (Project.File.Get.buffer t)#set_highlight_matching_brackets x
      ))
  end


module File =
  struct
    let save_as =
      FunTable.add "save-as" (fun () ->
        Project.File.save_as (Project.File.get_current ())
      )
    let save =
      FunTable.add "save" (fun () ->
        Project.File.save (Project.File.get_current ())
      )
    let save_all =
      FunTable.add "save-all" (fun () ->
        Project.File.iter Project.File.save
      )
    let close =
      FunTable.add "close" (fun () ->
        Project.File.close (Project.File.get_current ())
      )
    let close_all =
      FunTable.add "close-all" (fun () -> 
        Project.File.iter Project.File.close
      )
    let load_template =
      FunTable.add "load-template" (fun name ->
        Project.File.create ();
        let t = Project.File.get_current () in
        match Templates.get_contents name with
        | Some text -> Project.File.Set.contents t text
        | _ -> () (* Unknown template file. *)
      )
    let build =
      FunTable.add "build" (fun () ->
        let t = Project.File.get_current () in
        let file = Project.File.Get.file t in
        if Project.File.is_saved t then Build.run ~file
      )
  end
