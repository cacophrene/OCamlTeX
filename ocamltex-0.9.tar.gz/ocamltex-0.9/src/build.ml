(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

module Pat =
  struct
    let latex_warning = Str.regexp "^LaTeX Warning[^\n]+$"
    let overfull = Str.regexp "^Overfull[^\n]+$"
    let underfull = Str.regexp "^Underfull[^\n]+$"
    let output = Str.regexp "^Output written[^\n]+$"
  end

type element = [ 
  | `Overfull 
  | `Underfull 
  | `Warning
  | `Output
]

let pat_of_element = function
  | `Underfull -> Pat.underfull
  | `Overfull -> Pat.overfull
  | `Warning -> Pat.latex_warning
  | `Output -> Pat.output

let find_all elt str =
  let pat = pat_of_element elt in
  let rec loop acc i =
    try
      ignore (Str.search_forward pat str i);
      loop (Str.matched_group 0 str :: acc) (Str.match_end ())
    with Not_found -> acc
  in loop [] 0

let parse log =
  let l1 = find_all `Underfull log in
  let l2 = find_all `Overfull log in
  let l3 = find_all `Warning log in
  let l4 = find_all `Output log in
  GUI.BottomPane.Log.clear ();
  List.iter (GUI.BottomPane.Log.add `Error) (l1 @ l2);
  List.iter (GUI.BottomPane.Log.add `Warning) l3;
  List.iter (GUI.BottomPane.Log.add `Info) l4;
  GUI.BottomPane.Log.display ()

let read log =
  let ich = open_in log in
  let len = in_channel_length ich in
  let str = String.create len in
  really_input ich str 0 len;
  close_in ich;
  str

let run ~file =
  let path = Filename.dirname file 
  and name = Filename.basename file in
  Printf.ksprintf Sys.command
    "cd \"%s\" && pdflatex -interaction=nonstopmode \"%s\"" path name;
  let str = read (Filename.chop_extension file ^ ".log") in
  parse str
