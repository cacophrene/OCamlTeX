(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

module type CHAR =
  sig
    type t
    val compare : t -> t -> int
    val length : string -> int
    val explode : string -> t list
    val rev_implode : t list -> string
  end

module type LEXICON =
  sig
    type t
    val empty : t
    val is_empty : t -> bool
    val add : string -> t -> t
    val mem : string -> t -> bool
    val mem_prefix : string -> t -> bool
    val remove : string -> t -> t
    val length : t -> int
    val sub : string -> t -> t
    val iter : (string -> unit) -> t -> unit
    val iteri : (int -> string -> unit) -> t -> unit
    val fold : (string -> 'a -> 'a) -> t -> 'a -> 'a
    val complete : ?min_size:int -> string -> t -> string option
    val of_list : string list -> t
    val to_list : t -> string list
  end

module Make (Char : CHAR) : LEXICON =
  struct
    module CharMap = Map.Make (Char)

    type t = { flag : bool; cmap : t CharMap.t }

    let empty = { flag = false; cmap = CharMap.empty }
    let is_empty lex = not lex.flag && CharMap.is_empty lex.cmap

    (* Ajout d'un mot dans un lexique. *)
    let add str lex =
      let rec loop lex = function
        | [] -> { lex with flag = true }
        | chr :: t -> 
          let res = loop (try CharMap.find chr lex.cmap with _ -> empty) t in
          { lex with cmap = CharMap.add chr res lex.cmap }
      in loop lex (Char.explode str)

    (* Teste l'appartenance d'un mot à un lexique. *)
    let mem str lex =
      let rec loop lex = function
        | [] -> lex.flag
        | chr :: t when CharMap.mem chr lex.cmap -> 
          loop (CharMap.find chr lex.cmap) t
        | _ -> false
      in loop lex (Char.explode str)

    (* Teste l'existence d'un préfixe (et non d'un mot !) dans un lexique. *)
    let mem_prefix str lex =
      let rec loop lex = function
        | [] -> true
        | chr :: t when CharMap.mem chr lex.cmap -> 
          loop (CharMap.find chr lex.cmap) t
        | _ -> false
      in loop lex (Char.explode str)

    (* Retire un mot d'un lexique. *)
    let remove str lex =
      let rec loop lex = function
        | [] -> { lex with flag = false }
        | chr :: t when CharMap.mem chr lex.cmap -> 
          let res = loop (CharMap.find chr lex.cmap) t in
          { lex with cmap = 
            if is_empty res then CharMap.remove chr lex.cmap
            else CharMap.add chr res lex.cmap }
        | _ -> lex
      in loop lex (Char.explode str)

    (* Compte le nombre de mots d'un lexique. *)
    let length lex =
      let rec loop lex n = 
        CharMap.fold (fun _ -> loop) lex.cmap (n + if lex.flag then 1 else 0)
      in loop lex 0

    (* Extrait tous les mots d'un lexique qui possèdent un préfixe donné. *)
    let sub str lex =
      let rec loop lex = function
        | [] -> lex
        | chr :: t when CharMap.mem chr lex.cmap ->
          let res = loop (CharMap.find chr lex.cmap) t in
          { flag = false; cmap = CharMap.add chr res CharMap.empty}
        | _ -> raise Not_found 
      in loop lex (Char.explode str)
      
    (* Parcours ordonné des mots du lexique. *)
    let iter f =
      let rec loop seq lex =
        if lex.flag then f (Char.rev_implode seq);
        CharMap.iter (fun chr -> loop (chr :: seq)) lex.cmap
      in loop []

    (* Parcours ordonné des mots du lexique. *)
    let iteri f =
      let i = ref 0 in
      let rec loop seq lex =
        if lex.flag then (f !i (Char.rev_implode seq); incr i);
        CharMap.iter (fun chr -> loop (chr :: seq)) lex.cmap
      in loop []

    (* Calcul à partir des mots du lexique. *)
    let fold f =
      let rec loop seq lex acc =
        CharMap.fold (fun chr -> loop (chr :: seq)) lex.cmap
        (if lex.flag then f (Char.rev_implode seq) acc else acc)
      in loop []

    let complete ?(min_size = 8) str lex =
      try
        let rec loop seq lex wd1 =
          let word =
            if lex.flag then (
              let wd2 = Char.rev_implode seq in
              let ln1 = Char.length wd1 in
              let ln2 = Char.length wd2 in
              if (ln1 = 0 && ln2 >= min_size) || ln2 >= min_size && ln2 < ln1 then wd2 else wd1
            ) else wd1 in
          CharMap.fold (fun chr lex -> loop (chr :: seq) lex) lex.cmap word in
        let res = loop [] (sub str lex) "" in
        if Char.length res > 0 then Some res else None
      with Not_found -> None

    (* Création d'un lexique à partir d'une liste de mots. *)
    let of_list = List.fold_left (fun lex str -> add str lex) empty

    (* Récupération des mots sous forme de liste ordonnée. *)
    let to_list lex =
      let rec loop seq lex acc =
        CharMap.fold (fun chr -> loop (chr :: seq)) lex.cmap
        (if lex.flag then seq :: acc else acc)
      in List.rev_map Char.rev_implode (loop [] lex [])
  end

(* Exemple d'application du foncteur. *)
module ASCII : LEXICON = Make (
  struct
    type t = char
    let compare = Char.compare
    let length = String.length
    let explode str =
      let rec loop acc = function
        | 0 -> acc
        | i -> let j = i - 1 in loop (str.[j] :: acc) j
      in loop [] (String.length str)
    let rev_implode = 
      List.fold_left (fun str chr -> Printf.sprintf "%c%s" chr str) ""
  end )

(* Autre exemple pour UTF-8 avec Glib. *)
module UTF_8 : LEXICON = Make (
  struct
    type t = Glib.unichar
    let compare = compare
    let length = Glib.Utf8.length
    let explode str = Array.to_list (Glib.Utf8.to_unistring str)
    let rev_implode l = Glib.Utf8.from_unistring (Array.of_list (List.rev l))
  end )

let read () =
  let ich = open_in "config/dictionaries/french.dic" in
  let res = input_value ich in
  close_in ich;
  (res : UTF_8.t)
