(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let eval ~label f x =
  let tm1 = Unix.gettimeofday () in
  let _ = f x in
  let tm2 = Unix.gettimeofday () in
  Printf.printf "(OCamlTeX) %s: %.3f s.\n%!" label (tm2 -. tm1)

let tm1 =
  let tm1 = Unix.gettimeofday () in
  Printexc.record_backtrace true;
  GMain.init ();
  tm1

let name = "OCamlTeX"
let icon = GdkPixbuf.from_file "config/icon.png"
let version = "0.7"
let title = name ^ " " ^ version
let authors = [("Edouard Evangelisti", "cacophrene@gmail.com")]
let license = "GNU General Public License version 3"
let copyright = "Copyright (C) 2009 Edouard Evangelisti"
let website = "http://sourceforge.net/projects/ocamltex/"

module Dir =
  struct
    let config = "config/"
    let gui = config ^ "gui/"
    let languages = config ^ "languages/"
    let plugins = config ^ "plugins/"
    let dictionaries = config ^ "dictionaries/"
  end

module File =
  struct
    let latex = Filename.concat Dir.config "ocamltex-latex"
    let prefs = Filename.concat Dir.config "ocamltex-prefs"
  end
