(* OCamlTeX - Hello plugin.
 * Compilation:
 * ocamlopt -w s -g -shared -I +lablgtk2 -I ../../_build hello.ml -o hello.cmxs
 *)

let _ = GMain.init ()

let main () =
  let name = String.capitalize (Unix.getenv "USER") in
  let dialog = GWindow.message_dialog
    ~message:(Printf.sprintf "<big><b>Bonjour %s !</b>\n\n Je suis un \
      petit greffon pour OCamlTeX.</big>" name)
    ~use_markup:true
    ~message_type:`INFO
    ~buttons:GWindow.Buttons.ok
    ~parent:GUI.Main.window           (* This is OCamlTeX main window. *)
    ~destroy_with_parent:true
    ~title:"Greffon OCamlTeX" () in
  dialog#run ();
  dialog#destroy ()

let show_about () =
  let dialog = GWindow.about_dialog
    ~name:"Hello world!"
    ~comments:"Hello world! pour OCamlTeX"
    ~parent:GUI.Main.window
    ~destroy_with_parent:true
    ~authors:["Edouard Evangelisti"] () in
  dialog#run ();
  dialog#destroy ()

let _ = 
  Lang.add "hello-title" "Hello world!";
  Lang.add "hello-description" "Un exemple de greffon pour OCamlTeX";
  FunTable.add "about-hello" show_about;
  FunTable.add "hello" main
