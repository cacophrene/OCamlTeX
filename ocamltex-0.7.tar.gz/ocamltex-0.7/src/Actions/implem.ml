(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

module GUI =
  struct
    let quit = GUI.Main.window#destroy

    let toggle_fullscreen =
      let switch = ref false in
      fun () ->
        switch := not !switch;
        if !switch then GUI.Main.window#fullscreen ()
        else GUI.Main.window#unfullscreen ()

    let toggle_side_pane =
      let switch = ref false in
      fun () ->
        switch := not !switch;
        if !switch then GUI.Main.hpaned#pack1 ~shrink:false 
          GUI.SidePane.notebook#coerce    
        else GUI.Main.hpaned#remove GUI.Main.hpaned#child1

    let toggle_bottom_pane =
      let switch = ref false in
      fun () ->
        switch := not !switch;
        if !switch then GUI.Main.vpaned#pack2 ~shrink:false 
          GUI.BottomPane.notebook#coerce    
        else GUI.Main.vpaned#remove GUI.Main.vpaned#child2

    let switch_page n =
      Project.File.set_current (GUI.Main.opened_files#get_nth_page n)

    let go_back = GUI.Main.opened_files#previous_page
    let go_forward = GUI.Main.opened_files#next_page
  end

module Edit =
  struct
    let get_current_buffer () = 
      Project.File.get_buffer (Project.File.get_current ())

    let undo () =
      let buffer = get_current_buffer () in
      if buffer#can_undo then buffer#undo ()

    let redo () =
      let buffer = get_current_buffer () in
      if buffer#can_redo then buffer#redo ()

    let cut () = (get_current_buffer ())#cut_clipboard GMain.clipboard
    let copy () = (get_current_buffer ())#copy_clipboard GMain.clipboard
    let paste () = (get_current_buffer ())#paste_clipboard GMain.clipboard

    let select_all () =
      let buffer = get_current_buffer () in
      buffer#select_range buffer#start_iter buffer#end_iter

    let latex_insert t = (get_current_buffer ())#insert (LaTeX.Main.to_insert t)

    let comment () =
      let buffer = get_current_buffer () in
      let start, stop = buffer#selection_bounds in
      for i = start#line to stop#line do
        let li = buffer#get_iter (`LINE i) in
        if li#char <> 37 then buffer#insert ~iter:li "%"
      done 

    let uncomment () =
      let buffer = get_current_buffer () in
      let start, stop = buffer#selection_bounds in
      for i = start#line to stop#line do
        let li = buffer#get_iter (`LINE i) in
        if li#char = 37 then buffer#delete ~start:li ~stop:li#forward_char
      done 
  end
