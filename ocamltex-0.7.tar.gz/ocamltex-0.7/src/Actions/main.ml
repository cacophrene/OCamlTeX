(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

module Funs =
  struct
    let gui = 
      let module IG = Implem.GUI in
      ["quit", IG.quit; "toggle-fullscreen", IG.toggle_fullscreen;
       "toggle-side-pane", IG.toggle_side_pane; "go-back", IG.go_back;
       "toggle-bottom-pane", IG.toggle_bottom_pane; "go-forward", IG.go_forward]
    let file = ["new", Project.File.create]
    let edit = 
      let module IE = Implem.Edit in
      ["undo", IE.undo; "redo", IE.redo; "cut", IE.cut; "copy", IE.copy; 
       "paste", IE.paste; "select-all", IE.select_all; "comment", IE.comment; 
       "uncomment", IE.uncomment]
  end

let register_aux = List.iter (fun (id, f) -> FunTable.add id f)

let register () =
  List.iter register_aux [Funs.gui; Funs.file; Funs.edit];
  FunTable.add "latex-insert" Implem.Edit.latex_insert;
  FunTable.add "switch-page" Implem.GUI.switch_page
