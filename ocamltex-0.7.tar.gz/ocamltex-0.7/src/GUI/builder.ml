(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

type combo = {
  combo : GEdit.combo_box;
  store : GTree.list_store;
  texts : string GTree.column;
  icons : GtkStock.id GTree.column
}

type item = [
  | `Combo      of combo
  | `Menu       of GMenu.menu
  | `TeXDoc     of Widgets.texdoc
  | `Toolbar    of GButton.toolbar
  | `Menubar    of GMenu.menu_shell
  | `ToolButton of GButton.tool_button
  | `MenuButton of GButton.menu_tool_button
  | `ImageItem  of GMenu.image_menu_item
  | `CheckItem  of GMenu.check_menu_item
]

(* Some global variables. They are all updated before being used, so don't
 * worry about these ugly Obj.magic calls. *)
let add = ref (Obj.magic ())
let accels = ref (Obj.magic ())

(* This module provides functions to find, format and register accelerators. *)
module Accel =
  struct
    let format =
      let buf = Buffer.create 16 and pat = Str.regexp "+" in
      let add = Buffer.add_string buf in
      fun str ->
        Buffer.clear buf;
        List.iter (fun str -> add (
          match str with 
          |"Ctrl"  -> "<control>"
          | "Shift" -> "<shift>"
          | _ -> str
        )) (Str.split pat str);
        Buffer.contents buf
    let may opt =
      try 
        match List.assoc "accel" opt with
        | `Str str -> Some (format str)
        | _ -> None
      with Not_found -> None
    let add =
      let flags = [`VISIBLE] in
      fun (item : #GMenu.menu_item_skel) opt ->
        match may opt with
        | Some str -> let key, modi = GtkData.AccelGroup.parse str in
          item#add_accelerator ~group:!accels ~modi ~flags key
        | _ -> ()
  end

(* This module provides functions to find and load icons. *)
module Icon =
  struct
    let may opt =
      try
        match List.assoc "icon" opt with
        | `Str x -> Some (`STOCK x)
        | _ -> None
      with Not_found -> None
  end

(* This module provides functions to manipulate combo boxes. *)
module Combo =
  struct
    (* Combo box builder. *)
    let make ~packing () =
      let cols = new GTree.column_list in
      let texts = cols#add Gobject.Data.string in
      let icons = cols#add GtkStock.conv in
      let store = GTree.list_store cols in
      let combo = GEdit.combo_box ~width:200 ~model:store ~packing () in
      let cell_icons = GTree.cell_renderer_pixbuf [] in
      let cell_texts = GTree.cell_renderer_text [`XPAD 5] in
      combo#pack cell_icons;
      combo#add_attribute cell_icons "stock_id" icons;
      combo#pack cell_texts;
      combo#add_attribute cell_texts "markup" texts;
      { combo = combo; store = store; texts = texts; icons = icons }

    (* Feeding combo box. *)
    let feed combo id =
      Array.iter (fun t ->
        let markup = LaTeX.Main.to_markup t in
        let row = combo.store#append () in
        combo.store#set ~row ~column:combo.icons (LaTeX.Main.get_stock t);
        combo.store#set ~row ~column:combo.texts markup
      ) (LaTeX.Main.get_group id);
      combo.combo#set_active 0
  end

module PluginTools =
  struct
    let feed item =
      List.iter (fun name ->
        let item = GMenu.menu_item
          ~label:(Lang.get (Plugin.ID.title name))
          ~packing:item#add () in
        item#connect#activate (FunTable.run (Plugin.ID.main name)); ()
      ) (Plugin.get_list ())
  end

(* This module let us know whether a check menu item is active or not. *)
module Check =
  struct
    let is_active opt =
      try
        match List.assoc "init" opt with
        | `Bln b -> b
        | _ -> false
      with Not_found -> false
  end

module IconPattern =
  struct
    let var pat id =
      let buf = Buffer.create 16 in
      Buffer.add_substitute buf (function "id" -> id | _-> "?") pat;
      `STOCK (Buffer.contents buf)

    let get opt =
      let rec loop = function
        | [] -> None 
        | ("icon_pattern", `Str pat) :: _ -> Some (var pat)
        | _ :: t -> loop t
      in loop opt
  end

module LaTeXSubMenu =
  struct
    let build ~packing id =
      Array.iter (fun t ->
        let id = LaTeX.Main.get_id t in
        let item = GMenu.image_menu_item ~packing () in
        (* GtkLabel - Allows us to add markup. *)
        GMisc.label 
          ~xalign:0.
          ~markup:(Lang.get id ^ " - " ^ LaTeX.Main.to_markup t)
          ~packing:item#add ();
        GMisc.image ~stock:`OPEN ~icon_size:`MENU ~packing:item#set_image ();
        item#connect#activate (FunTable.run_with_arg "latex-insert" t);
        !add id (`ImageItem item)
      ) (LaTeX.Main.get_group id)
  end

let set_stock packing stock = 
  GMisc.image ~stock ~icon_size:`MENU ~packing (); () 

(* Toolbar and menubar builder. *)
let rec bar ~packing = function
  | `Node ("Toolbar", `Str id, opt, contents) ->
    let item = GButton.toolbar
      ~orientation:`HORIZONTAL
      ~style:`ICONS
      ~packing:(GBin.handle_box ~packing ())#add () in
    !add id (`Toolbar item);
    let icon_pattern = IconPattern.get opt in
    List.iter (toolitem ?icon_pattern ~packing:item#insert) contents
  | `Node ("Menubar", `Str id, _, contents) ->
    let item = GMenu.menu_bar ~packing () in
    !add id (`Menubar item);
    List.iter (menu ~packing:item#add) contents;
  | _ -> eprintf "(OCamlTeX) Warning: Unknown bar.\n%!"

(* Menu builder. *)
and menu ~packing = function
  | `Flag ("Plugins") ->
    let label = GMenu.menu_item 
      ~label:(Lang.get "plugins") 
      ~use_mnemonic:true
      ~packing () in
    let item = GMenu.menu ~packing:label#set_submenu () in
    PluginTools.feed item
  | `Node ("Menu", `Str id, opt, contents) ->
    let label = GMenu.menu_item 
      ~label:(Lang.get id) 
      ~use_mnemonic:true
      ~packing () in
    let item = GMenu.menu ~packing:label#set_submenu () in
    !add id (`Menu item);
    let icon_pattern = IconPattern.get opt in
    List.iter (menuitem ?icon_pattern ~packing:item#add) contents
  | _ -> eprintf "(OCamlTeX) Warning: Unknown menubar item.\n%!"

(* Toolitem builder. Separators are not saved. *)
and toolitem ?icon_pattern ~packing = function
  | `Flag "Separator" -> ignore (GButton.separator_tool_item ~packing ())
  | `Leaf ("Image", `Str id, opt) ->    
    let stock = match Icon.may opt with
      | None -> (match icon_pattern with Some f -> Some (f id) | _ -> None)
      | some -> some in
    let item = GButton.tool_button ?stock ~packing () in
    item#misc#set_tooltip_text (Lang.get id);
    item#connect#clicked ~callback:(FunTable.run id);
    !add id (`ToolButton item)
  | `Leaf ("LaTeX", `Str id, _) ->
    let item = GButton.tool_item ~packing () in
    let combo = Combo.make ~packing:item#add () in
    Combo.feed combo id;
    !add id (`Combo combo)
  | `Flag "Plugins" ->
    let menu = GMenu.menu () in
    PluginTools.feed menu;
    let item = GButton.menu_tool_button
      ~menu
      ~stock:`PROPERTIES
      ~use_underline:true
      ~packing () in
    item#connect#clicked (FunTable.run_with_arg "preferences" (Some 4));
    !add "Plugins" (`MenuButton item)
  | `Flag "LaTeXDoc" ->
    let item = new Widgets.texdoc ~packing in
    !add "texdoc" (`TeXDoc item)
  | _ -> eprintf "(OCamlTeX) Warning: Unknown toolitem.\n%!"

(* Menuitem builder. Separators and tearoffs are not saved. *)
and menuitem ?icon_pattern ~packing = function
  | `Flag "Tearoff" -> ignore (GMenu.tearoff_item ~packing ())   
  | `Flag "Separator" -> ignore (GMenu.separator_item ~packing ())
  | `Leaf ("Image", `Str id, opt) ->
    let item = GMenu.image_menu_item
      ~label:(Lang.get id)
      ~packing () in
    let g = set_stock item#set_image in
    begin match Icon.may opt with 
      | Some id -> g id
      | _ -> Option.may (fun f -> g (f id)) icon_pattern
    end;
    item#connect#activate ~callback:(FunTable.run id);
    Accel.add item opt;
    !add id (`ImageItem item)
  | `Leaf ("Check", `Str id, opt) ->
    let item = GMenu.check_menu_item
      ~label:(Lang.get id)
      ~packing () in
    item#connect#toggled ~callback:(FunTable.run id);
    item#set_active (Check.is_active opt);
    Accel.add item opt;
    !add id (`CheckItem item)
  | `Flag ("Plugins") as mnu -> menu ~packing mnu 
  | `Node ("Menu", `Str _, _, _) as mnu -> menu ~packing mnu 
  | `Leaf ("LaTeX", `Str id, _) -> LaTeXSubMenu.build ~packing id
  | _ -> eprintf "(OCamlTeX) Warning: Unknown menuitem.\n%!"

(* GUI Builder. *)
let from_config ~accels:group ~packing ~storing:f = 
  add := f;
  accels := group;
  try
    let file = Filename.concat App.Dir.gui (AppPrefs.get "gui-file") in
    List.iter (bar ~packing) (Sexpr.from_file file)
  with _ -> eprintf "(OCamlTeX) Error: GUI loading failure.\n%!"; exit 2
