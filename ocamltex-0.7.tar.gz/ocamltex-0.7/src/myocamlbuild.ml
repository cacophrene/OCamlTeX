(* OCamlTeX - Compilation script *)

open Ocamlbuild_pack
open Ocamlbuild_plugin

let set_fixed_options () =
  let dirs = ["-I"; "+lablgtk2"] in
  Options.ocaml_libs := ["lablgtk"; "lablgtksourceview2"; "str"; "unix"; "dynlink"];
  Options.ocaml_cflags := dirs @ ["-w"; "s"; "-g"];
  Options.ocaml_lflags := dirs @ ["-g"];
  (* Disable logging for significant speedup. *)
  Log.level := 0

let _ =
  dispatch begin function 
    | After_options -> set_fixed_options () 
    | _ -> ()
  end
