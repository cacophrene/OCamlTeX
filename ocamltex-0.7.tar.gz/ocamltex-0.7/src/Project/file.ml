(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type file_flag = [
  | `BLANK
  | `SAVED
]


(* File-related data. *)
type dat = {
  mutable path : string;
  mutable saved : bool;
}

(* GUI-related data. *)
type gtk = {
  widget : GObj.widget;
  source : GSourceView2.source_view;
  signal : GtkSignal.id list;
}

type t = { dat : dat; gtk : gtk } 

let get_dir t = Filename.dirname t.dat.path
let get_base t = Filename.basename t.dat.path

let get_source t = t.gtk.source
let get_buffer t = t.gtk.source#source_buffer

module Storage =
  struct
    let htbl = Hashtbl.create 7
    let add = Hashtbl.add htbl
    let mem = Hashtbl.mem htbl
    let rem = Hashtbl.remove htbl
    let get = Hashtbl.find htbl
  end

let current = ref (Obj.magic ())
let get_current () = !current

let set_current widget =
  current := Storage.get widget#get_oid


(* Some auxiliary functions. *)
module Aux =
  struct
    let uniq =
      let n = ref 0 and doc = Lang.get "document" in
      fun () -> incr n; Printf.sprintf "%s-%d.tex" doc !n

    let read file =
      let ich = open_in file in
      let len = in_channel_length ich in
      let str = String.create len in
      really_input ich str 0 len;
      close_in ich;
      str  

    let get_focus t = 
      current := t;
      t.gtk.source#misc#grab_focus ()
  end

let create () =
  let path = Aux.uniq () in
  let source, widget = Display.source () in
  let tab_label = Display.tab_label path in
  let t = {
    dat = { path = path; saved = false };
    gtk = { widget = widget; source = source; signal = [] }
  } in
  Storage.add widget#get_oid t;
  let n = GUI.Main.opened_files#append_page ~tab_label widget in
  GUI.Main.opened_files#goto_page n;
  Aux.get_focus t
