(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

let prefs = Hashtbl.create 7

let add = Hashtbl.add prefs

let get id =
  try
    match Hashtbl.find prefs id with
    | `Str x -> x
    | _ -> Print.warning id "ID %S is not a string" id
  with Not_found -> Print.warning id "Unknown ID %S" id

let get_bool id =
  try
    match Hashtbl.find prefs id with
    | `Bln x -> x
    | _ -> Print.warning false "ID %S is not a boolean" id
  with Not_found -> Print.warning false "Unknown ID %S" id

let get_list id =
  try
    match Hashtbl.find prefs id with
    | `Lst x -> List.rev_map Sexpr.string_of_value x
    | _ -> Print.warning [] "ID %S is not a list" id
  with Not_found -> Print.warning [] "Unknown ID %S" id

let set ~id x = Hashtbl.replace prefs id (`Str x)

let parse_prefs = function
  | `Assc ("Set", `Str id, dat) -> add id dat
  | _ -> Print.warning () "Unknown preference"

let init () = 
  try List.iter parse_prefs (Sexpr.from_file App.File.prefs) with
    | _ -> Print.failure 4 "Preference file %S not found" App.File.prefs

module SaveAtExit =
  struct
    let header = "(* OCamlTeX - Preferences File.\n \
      * Caution: This file is part of OCamlTeX and thus should be edited \
        carefully.\n *)\n\n"
    let compare_couples (x, _) (y, _) = String.compare x y
    let export =
      let export () =
        let l = Hashtbl.fold (fun key x l -> (key, Sexpr.string_of_value x) :: l) prefs [] in
        let l = List.sort compare_couples l in
        let och = open_out App.File.prefs in
        Printf.fprintf och "%s" header;
        let key, dat = List.split l in
        List.iter2 (Printf.fprintf och "(Set \"%s\" = %s)\n") key dat;
        close_out och
      in at_exit export; export
  end
