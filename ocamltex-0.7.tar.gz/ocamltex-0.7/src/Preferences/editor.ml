(* 
    OCamlTeX - The OCaml LaTeX Editor
    Copyright (C) 2009  Edouard Evangelisti (cacophrene@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Printf

let tab_label = 
  begin GMisc.label 
    ~text:(Lang.get "editor") ()
  end#coerce

let vbox = GPack.vbox ~border_width:10 ~spacing:10 ()
let packing = vbox#pack ~expand:false
let container = vbox#coerce

module MainOptions =
  struct
    let label = GMisc.label
      ~xalign:0.
      ~markup:(sprintf "<b>%s</b>" (Lang.get "main-options"))
      ~packing ()

    let hbox = Tools.hbox_with_indent ~packing ()
    let vbox = GPack.vbox ~spacing:5 ~packing:hbox#add ()
    let packing = vbox#pack ~expand:false

    let highlight_syntax = GButton.check_button
      ~active:true
      ~label:(Lang.get "highlight-syntax")
      ~packing ()

    let highlight_current_line = GButton.check_button
      ~active:true
      ~label:(Lang.get "highlight-current-line")
      ~packing ()

    let show_line_numbers = GButton.check_button
      ~active:true
      ~label:(Lang.get "show-line-numbers")
      ~packing ()

    let draw_spaces = GButton.check_button
      ~active:true
      ~label:(Lang.get "draw-spaces")
      ~packing ()
  end

module RightMargin =
  struct
    let label = GMisc.label
      ~xalign:0.
      ~markup:(sprintf "<b>%s</b>" (Lang.get "right-margin"))
      ~packing ()

    let hbox = Tools.hbox_with_indent ~packing ()
    let vbox = GPack.vbox ~spacing:5 ~packing:hbox#add ()
    let packing = vbox#pack ~expand:false

    let show_right_margin = GButton.check_button
      ~active:true
      ~label:(Lang.get "show-right-margin")
      ~packing ()

    let hbox = GPack.hbox ~spacing:10 ~packing ()
    let packing = hbox#pack ~expand:false
    let _ = GMisc.label 
      ~text:(Lang.get "right-margin-position")
      ~packing ()
    let spin = GEdit.spin_button
      ~adjustment:(GData.adjustment ~lower:20. ~upper:100. ~value:80. ())
      ~value:80.
      ~snap_to_ticks:true
      ~packing ()
  end

module AutoSave =
  struct
    let label = GMisc.label
      ~xalign:0.
      ~markup:(sprintf "<b>%s</b>" (Lang.get "autosave"))
      ~packing ()

    let hbox = Tools.hbox_with_indent ~packing ()
    let vbox = GPack.vbox ~spacing:5 ~packing:hbox#add ()
    let packing = vbox#pack ~expand:false

    let autosave = GButton.check_button
      ~active:true
      ~label:(Lang.get "autosave-active-document")
      ~packing ()
    let hbox = GPack.hbox ~spacing:10 ~packing ()
    let packing = hbox#pack ~expand:false
    let _ = GMisc.label 
      ~text:(Lang.get "autosave-delay")
      ~packing ()
    let spin = GEdit.spin_button
      ~adjustment:(GData.adjustment ~lower:1. ~upper:20. ~value:2. ())
      ~value:2.
      ~snap_to_ticks:true
      ~packing ()
  end
