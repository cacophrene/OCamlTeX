(* oCamlTeX.ml *)

let _ =
  (* Plugins. *)
  Plugin.init ();
  (* Registering functions. *)
  Actions.Main.register ();
  (* Now it's time to create the GUI. *)
  GUI.Main.init ();
  (* Cleanup needed below! *)
  Preferences.Main.init ();
  Project.Main.init ();
  Dialog.Main.init ();
  GUI.Main.window#show ();
  let tm2 = Unix.gettimeofday () in
  Printf.printf "(OCamlTeX) Loading time: %.3f s.\n%!" (tm2 -. App.tm1);
  GMain.main ()
